#ifndef LKG_CUDAQUIET_H_
#define LKG_CUDAQUIET_H_

#pragma GCC system_header

#include "cuda.h"
#include "cuda_runtime.h"
#include "curand_kernel.h"

#endif

