#include "mtbddpeel.h"
#include "family.h"
#include "cuddutil.h"
#include "peel.h"
#include "options.h"

#include <iostream>
#include <map>

ADD &ActiveFunction::sub(ActiveFunction &larger, Uint i) {
  vector<Uint> drop_bits;
  larger.findDropBits(drop_bits, *this);
  return x[dropBits(drop_bits, i)];
}

void ActiveFunction::reduceTo(ActiveFunction &smaller) {
  vector<Uint> drop_bits;
  findDropBits(drop_bits, smaller);

  for (Uint i = 0; i < Uint(smaller.x.count()); i++)
    smaller.x[i] = x[0].manager()->addZero();

  for (Uint i = 0; i < Uint(x.count()); i++)
    smaller.x[dropBits(drop_bits, i)] += x[i];
}

// debug utility
void print(const set<Person *> &ppl) {
  for (set<Person *>::const_iterator i = ppl.begin(); i != ppl.end(); i++) {
    if (i != ppl.begin()) cout << " ";
    cout << (*i)->id;
  }
  cout << endl;
}

Uint PStep::numBitsPeeled(const set<Person *> &remaining) const {
  Uint n = 0;
  for (set<Person *>::const_iterator pi = peeled.begin(); pi != peeled.end();
       pi++) {
    Person *p = *pi;
    if (remaining.count(p) == 0)
      continue;
    if (p->patbitlevel != Person::FIXEDBIT && peeled.count(p->father))
      n++;
    if (p->matbitlevel != Person::FIXEDBIT && peeled.count(p->mother))
      n++;
  }
  return n;
}

void PStep::getPeeledBits(vector<IV> &peeled_bits,
                          const set<Person *> &remaining) {
  for (set<Person *>::const_iterator pi = peeled.begin(); pi != peeled.end();
       pi++) {
    Person *p = *pi;
     if (remaining.count(p) == 0)
      continue;
   if (p->patbitlevel != Person::FIXEDBIT && peeled.count(p->father))
      peeled_bits.push_back(p->patbitlevel);
   if (p->matbitlevel != Person::FIXEDBIT && peeled.count(p->mother))
     peeled_bits.push_back(p->matbitlevel);
  }
}

double PStep::cost(IV prob_size, Uint num_bits_remaining,
                   const set<Person *> &active_before,
                   const set<Person *> &remaining_before) const {
//   if (num_bits_peeled == 0) return .0;

  set<Person *> active(active_after.begin(), active_after.end());
  active.insert(active_before.begin(), active_before.end());

  const Uint num_bits_peeled = numBitsPeeled(remaining_before);
//   const double ps =
//     min(prob_size*double(num_bits_remaining - num_bits_peeled)/
//         double(num_bits_remaining),
//         double(IV(1) << (num_bits_remaining - num_bits_peeled)));

//   return ((IV(1) << num_bits_peeled) + ps)*
//     ((IV(1) << 2*active.size()) - (IV(1) << active.size()));
  return (IV(1) << num_bits_peeled)*double(prob_size)*
    (IV(1) << (2*active.size()));
}

void PPeeler::setup(Family *fam, Cudd &mgr, Trait *trait) {
  Uint num_bits = 0;
  for (Person *p = fam->firstdescendant; p != 0; p = p->next)
    if (p->hasphenotypeddescendants(false)) {
      initial_remaining.insert(p);
      if (p->patbitlevel != Person::FIXEDBIT) num_bits++;
      if (p->matbitlevel != Person::FIXEDBIT) num_bits++;
    }

  vector<set<Person *> > initial_active;
  for (Person *p = fam->first; p != 0; p = p->next) {
    if (p->children != 0) {
//       map<Person *, Uint> spouses;
      bool has_remaining_children = false;
      for (Plist *c = p->children; c != 0; c = c->next) {
//         spouses[c->p->mother]++;
        if (initial_remaining.count(c->p))
          has_remaining_children = true;
      }
      if (has_remaining_children) {
//         if (p->sex == MALE)
//           for (map<Person *, Uint>::const_iterator si = spouses.begin();
//                si != spouses.end(); si++)
//             if (si->second > 4 || p->founder() && si->first->founder()) {
//               initial_active.push_back(set<Person *>());
//               initial_active.back().insert(p);
//               initial_active.back().insert(si->first);
//             }
        initial_active.push_back(set<Person *>());
        initial_active.back().insert(p);
      }
    }
  }

  double lowest_total_cost = 1e300;
  for (vector<set<Person *> >::const_iterator ia = initial_active.begin();
       ia != initial_active.end(); ia++) {
#ifdef DEBUG_OUTPUT
    cout << (*ia->begin())->id << "\t" << ia->size() << endl;
#endif // DEBUG_OUTPUT
    set<Person *> active(*ia);
    set<Person *> remaining(initial_remaining);

    IV prob_size = IV(1) << min(Uint(25), (num_bits*3)/4);
    Uint num_bits_peeled = 0;
    double total_cost = .0;
    vector<PStep> order;
    while (num_bits_peeled != num_bits) {
      assertinternal(!active.empty() && !remaining.empty());

      PStep best_step;
      double lowest_cost = 1e300;
      for (set<Person *>::const_iterator ai = active.begin();
           ai != active.end(); ai++) {
        const bool has_remaining_parents = remaining.count(*ai);
        bool has_remaining_children = false;
        for (Plist *c = (*ai)->children; c != 0; c = c->next)
          if (remaining.count(c->p)) {
            has_remaining_children = true;
            break;
          }

        assertinternal(has_remaining_parents || has_remaining_children);

        if (has_remaining_parents) {
          // completeley peel out proband's up branch
          PStep full_expand = peelUp(*ai, active, remaining);
          tryStep(best_step, lowest_cost, full_expand, prob_size,
                  num_bits - num_bits_peeled, active, remaining);

          // add parents to active and peel out proband
          set<Person *> parents_active(active);
          parents_active.insert((*ai)->father);
          parents_active.insert((*ai)->mother);
          PStep peel_proband = peelSingle(*ai, parents_active, remaining);
          tryStep(best_step, lowest_cost, peel_proband, prob_size,
                  num_bits - num_bits_peeled, parents_active, remaining);

          // add parents to active and peel out proband and his down branch
          PStep peel_proband_down = peelDown(*ai, parents_active, remaining,
                                             true);
          tryStep(best_step, lowest_cost, peel_proband_down, prob_size,
                  num_bits - num_bits_peeled, parents_active, remaining);

          // add sibling to active and peel out proand's up branch
          set<Person *> sibs;
          for (Plist *ps = (*ai)->father->children; ps != 0; ps = ps->next)
            sibs.insert(ps->p);
          for (Plist *ms = (*ai)->mother->children; ms != 0; ms = ms->next)
            sibs.insert(ms->p);
          for (set<Person *>::const_iterator si = sibs.begin();
               si != sibs.end(); si++)
            if (active.count(*si) == 0 && remaining.count(*si)) {
              set<Person *> sib_active(active);
              sib_active.insert(*si);
              PStep peel_to_sib = peelUp(*ai, sib_active, remaining);
              tryStep(best_step, lowest_cost, peel_to_sib, prob_size,
                      num_bits - num_bits_peeled, sib_active, remaining);
           }
        }
        if (has_remaining_children) {
          // completecly peel out proband's down branch
          PStep full_expand = peelDown(*ai, active, remaining);
          tryStep(best_step, lowest_cost, full_expand, prob_size,
                  num_bits - num_bits_peeled, active, remaining);

          for (Plist *c = (*ai)->children; c != 0; c = c->next) {
            if (remaining.count(c->p) == 0) continue;
            // add spouse to active and completely peel out child's down branch
            set<Person *> spouse_active(active);
            Person *spouse = c->p->father == *ai ? c->p->mother : c->p->father;
            spouse_active.insert(spouse);
            PStep peel_child_branch = peelDown(c->p, spouse_active, remaining,
                                               true);
            tryStep(best_step, lowest_cost, peel_child_branch, prob_size,
                    num_bits - num_bits_peeled, spouse_active, remaining);

            // add spouse to active and completely peel out couples children
            PStep peel_children = peelChildren(*ai, spouse, spouse_active,
                                               remaining);
            tryStep(best_step, lowest_cost, peel_children, prob_size,
                    num_bits - num_bits_peeled, spouse_active, remaining);

            if (active.count(c->p) == 0) {
              // add child to active and do a full down expand from proband
              set<Person *> child_active(active);
              child_active.insert(c->p);
              bool has_remaining_inactive_children = false;
              for (Plist *cc = (*ai)->children; cc != 0; cc = cc->next)
                if (remaining.count(cc->p) && child_active.count(cc->p) == 0)
                  has_remaining_inactive_children = true;
              if (has_remaining_inactive_children) {
                PStep peel_to_child = peelDown(*ai, child_active, remaining);
                tryStep(best_step, lowest_cost, peel_to_child, prob_size,
                        num_bits - num_bits_peeled, child_active, remaining);
              }

              // add spouse and child to active and peel out child
              spouse_active.insert(c->p);
              PStep peel_child = peelSingle(c->p, spouse_active, remaining);
              tryStep(best_step, lowest_cost, peel_child, prob_size,
                      num_bits - num_bits_peeled, spouse_active,
                      remaining);
            }
          }
        }
      }

      const Uint old_nbr = num_bits - num_bits_peeled;
      num_bits_peeled += best_step.numBitsPeeled(remaining);
      const Uint nbr = num_bits - num_bits_peeled;
      active = best_step.active_after;
      remaining = best_step.remaining_after;
      order.push_back(best_step);
      total_cost += lowest_cost;
      prob_size =
        IV(rint(min(prob_size*double(nbr)/double(old_nbr),
                    double(IV(1) << nbr))));
    }

    if (total_cost < lowest_total_cost) {
      lowest_total_cost = total_cost;
      peel_order = order;
    }
  }

  // Calculate peeling probabilites and store them in L
  set<Person *> active_before;
  set<Person *> remaining_before(initial_remaining);
  for (Uint i = 0; i < peel_order.size(); i++) {
#ifdef DEBUG_OUTPUT
    peel_order[i].print();
#endif // DEBUG_OUTPUT
    peel_order[i].calcPeelProb(active_before, remaining_before, mgr, trait,
                               initial_remaining);

    active_before = peel_order[i].active_after;
    remaining_before = peel_order[i].remaining_after;
  }
}

DdNode *sumProd(DdManager *man, DdNode *p, DdNode *L, int *levels);

DdNode *sumProd_util(DdManager *man, DdNode *p, DdNode *L, int *levels) {
  const int level = min(cuddI(man, p->index), cuddI(man, L->index));
  Uint i = 0;
  double fac = 1.;
  while (level > levels[i]) {
    i++;
    fac *= 2.;
  }
  DdNode *const tmp = sumProd(man, p, L, levels + i);
  cuddRef(tmp);
  DdNode *N;
  if (fac == 1.)
    N = tmp;
  else {
    DdNode *fac_node = cuddUniqueConst(man, fac);
    cuddRef(fac_node);
    N = Cudd_addApply(man, Cudd_addTimes, tmp, fac_node);
    cuddRef(N);
    Cudd_RecursiveDeref(man, tmp);
    Cudd_RecursiveDeref(man, fac_node);
  }

  return N;
}

DdNode *sumProd(DdManager *man, DdNode *p, DdNode *L, int *levels) {
  if (p == DD_ZERO(man) || L == DD_ZERO(man)) return DD_ZERO(man);
  if (cuddIsConstant(p) && cuddIsConstant(L))
    return cuddUniqueConst(man, cuddV(p)*cuddV(L));

  DD_CTFP cacheOp = (DD_CTFP)sumProd;
  DdNode *res = cuddCacheLookup2(man, cacheOp, p, L);
  if (res != 0) return res;

    // recursive step
  const unsigned int p_level = cuddI(man, p->index);
  const unsigned int L_level = cuddI(man, L->index);
  int index, level;
  DdNode *pv, *pvn, *Lv, *Lvn;
  if (p_level <= L_level) {
    level = p_level;
    index = p->index;
    pv = cuddT(p);
    pvn = cuddE(p);
  } else {
    level = L_level;
    index = L->index;
    pv = pvn = p;
  }
  if (L_level <= p_level) {
    Lv = cuddT(L);
    Lvn = cuddE(L);
  } else {
    Lv = Lvn = L;
  }

  assertinternal(int(level) <= *levels);
  int *next_levels = int(level) == *levels ? levels + 1 : levels;

  // build T
  DdNode *T = sumProd_util(man, pv, Lv, next_levels);

  // build E
  DdNode *E = sumProd_util(man, pvn, Lvn, next_levels);

//   assertinternal(Cudd_DebugCheck(man) == 0);

  // build res
  if (*levels == level) {
    res = Cudd_addApply(man, Cudd_addPlus, T, E);
    if (T == res) cuddDeref(T);
    else Cudd_RecursiveDeref(man, T);
    if (E == res) cuddDeref(E);
    else Cudd_RecursiveDeref(man, E);
  } else {
    res = (T == E) ? T : cuddUniqueInter(man, (int) index, T, E);
    cuddDeref(T);
    cuddDeref(E);
  }
//   cuddRef(res);
//  assertinternal(Cudd_DebugCheck(man) == 0);
//   cuddDeref(res);

  cuddCacheInsert2(man, cacheOp, p, L, res);

  return res;
}

ADD PPeeler::sumProd(ADD &p, ADD &L, const vector<IV> &peeled_bits) {
  DdManager *man = p.manager()->getManager();

  vector<int> levels;
  for (vector<IV>::const_iterator pb = peeled_bits.begin();
       pb != peeled_bits.end(); pb++)
    levels.push_back(cuddI(man, *pb));
  levels.push_back(CUDD_CONST_INDEX);
  sort(levels.begin(), levels.end());

  const int lvl = min(cuddI(man, p.getNode()->index),
                      cuddI(man, L.getNode()->index));

  double fac = 1.;
  unsigned int i = 0;
  while (levels[i] < lvl) {
    fac *= 2.;
    i++;
  }

  DdNode *res = ::sumProd(man, p.getNode(), L.getNode(), &levels[i]);
  if (fac > 1.) {
    cuddRef(res);
    DdNode *fac_node = cuddUniqueConst(man, fac);
    cuddRef(fac_node);
    DdNode *tmp = res;
    res = Cudd_addApply(man, Cudd_addTimes, tmp, fac_node);
    cuddRef(res);
    Cudd_RecursiveDeref(man, fac_node);
    Cudd_RecursiveDeref(man, tmp);
    cuddDeref(res);
  }

  ADD r(p.manager(), res);
  for (vector<IV>::const_iterator v = peeled_bits.begin();
       v != peeled_bits.end(); v++) {
    ADD bv(p.manager()->addVar(*v));
    assertinternal(r.Cofactor(~bv) == r.Cofactor(bv));
  }

  return ADD(p.manager(), res);
}

ADD sp(ADD &p, ADD &L, const vector<IV> &peeled_bits) {
  Cudd &mgr = *p.manager();
  if (L == mgr.addZero()) return mgr.addZero();
  else if (cuddIsConstant(L.getNode())) {
    ADD pp(p);
    for (vector<IV>::const_iterator v = peeled_bits.begin();
         v != peeled_bits.end(); v++) {
      ADD bv(mgr.addVar(*v));
      pp = pp.Cofactor(~bv) + pp.Cofactor(bv);
    }
    return pp*L;
  } else {
    ADD pL = p*L;
    for (vector<IV>::const_iterator v = peeled_bits.begin();
         v != peeled_bits.end(); v++) {
      ADD bv(mgr.addVar(*v));
      pL = pL.Cofactor(~bv) + pL.Cofactor(bv);
    }
    return pL;
  }
}

double PPeeler::peel(ADD &p) {
  const int old_prec = p.manager()->ReadRoundingPrec();
  p.manager()->SetRoundingPrec(options->mtbddrounding);
  assertinternal(!peel_order.empty());

  ActiveFunction pc;
  pc.x[0] = p;
  set<Person *> remaining(initial_remaining);
//  assertinternal(Cudd_DebugCheck(p.manager()->getManager()) == 0);
  for (vector<PStep>::iterator oi = peel_order.begin(); oi != peel_order.end();
       oi++) {
    p.manager()->SetRoundingPrec(p.manager()->ReadRoundingPrec() - 1);
    ActiveFunction intermediate(oi->L.active);
    vector<IV> peeled_bits;
    oi->getPeeledBits(peeled_bits, remaining);
    for (Uint i = 0; i < Uint(oi->L.x.count()); i++) {
      ADD &p_before = pc.sub(oi->L, i);

//       intermediate.x[i] = sumProd(p_before, oi->L.x[i], peeled_bits);
      intermediate.x[i] = sp(p_before, oi->L.x[i], peeled_bits);
//       ADD s = sp(p_before, oi->L.x[i], peeled_bits);
//       if (fabs(sum(s - intermediate.x[i])/sum(s)) > .01) {
//         intermediate.x[i].print(12, 1);
//         s.print(12, 1);
//         assertinternal(false);
//       }
    }

//    cuddCacheFlush(p.manager()->getManager());

    if (oi + 1 != peel_order.end()) {
      pc = ActiveFunction(oi->active_after);
      intermediate.reduceTo(pc);
    } else {
      double s = 0;
      for (Uint i = 0; i < Uint(intermediate.x.count()); i++) {
        DdNode *xn = intermediate.x[i].getNode();
        assertinternal(cuddIsConstant(xn));
        s += cuddV(xn);
      }
      p.manager()->SetRoundingPrec(old_prec);
      return s;
    }

    remaining = oi->remaining_after;
//    assertinternal(Cudd_DebugCheck(p.manager()->getManager()) == 0);
  }
  assertinternal(false);
}

void PStep::print() const {
  cout << "Peeled:" << endl;
  ::print(peeled);
  cout << "Remaining:" << endl;
  ::print(remaining_after);
  cout << "Active:" << endl;
  ::print(active_after);
}

void PPeeler::tryStep(PStep &best_step, double &lowest_cost, const PStep &step,
                      IV prob_size, Uint num_bits_remaining,
                      const set<Person *> &active,
                      const set<Person *> &remaining) {
  const double step_cost = step.cost(prob_size, num_bits_remaining, active,
                                     remaining);
  if (step_cost < lowest_cost) {
    lowest_cost = step_cost;
    best_step = step;
  }
}

void PStep::insertToPeel(Person *p) {
  peeled.insert(p);
  peeled.insert(p->father);
  peeled.insert(p->mother);
}

void PStep::insertToPeelRecursive(Person *p, const set<Person *> &active) {
  if (peeled.count(p) == 0) {
    peeled.insert(p);
    if (active.count(p) == 0) {
      if (!p->founder()) {
        insertToPeelRecursive(p->father, active);
        insertToPeelRecursive(p->mother, active);
      }
      for (Plist *c = p->children; c != 0; c = c->next)
        insertToPeelRecursive(c->p, active);
    }//  else if (!p->founder()) {
//       if (isPeeled(p->father)) peeled.insert(p->mother);
//       else if (isPeeled(p->mother)) peeled.insert(p->father);
//     }
  }
}

void PStep::setAfter(const set<Person *> &active,
                     const set<Person *> &remaining) {
  for (set<Person *>::const_iterator pi = peeled.begin(); pi != peeled.end();
       pi++)
    if (active.count(*pi) && remaining.count(*pi) && !(*pi)->founder()) {
      if (peeled.count((*pi)->father)) peeled.insert((*pi)->mother);
      if (peeled.count((*pi)->mother)) peeled.insert((*pi)->father);
    }

  remaining_after = remaining;
  for (set<Person *>::const_iterator pi = peeled.begin(); pi != peeled.end(); pi++)
  {
      cerr << "Remaining after:" << flush;

      if (peeled.count((*pi)->father)) {
          cerr << "Has Mother:" << flush;
          assertinternal(peeled.count((*pi)->mother));
          remaining_after.erase(*pi);
      } else
          cerr << "No Mother:" << flush;
          assertinternal(!peeled.count((*pi)->mother));

      cerr << "-- normal " << endl;
  }

  assertinternal(active_after.empty());
  for (set<Person *>::const_iterator ai = active.begin(); ai != active.end();
       ai++)
    if (remaining_after.count(*ai))
      active_after.insert(*ai);
    else {
      bool has_remaining_children = false;
      for (Plist *c = (*ai)->children; c != 0; c = c->next)
        if (remaining_after.count(c->p)) {
          has_remaining_children = true;
          break;
        }

      if (has_remaining_children)
        active_after.insert(*ai);
    }
}

PStep PPeeler::peelUp(Person *p, const set<Person *> &active,
                      const set<Person *> &remaining) {
  PStep step;

  assertinternal(!p->founder());
  step.peeled.insert(p);
  step.insertToPeelRecursive(p->father, active);
  step.peeled.erase(p->mother);
  step.insertToPeelRecursive(p->mother, active);

  step.setAfter(active, remaining);

  return step;
}

PStep PPeeler::peelDown(Person *p, const set<Person *> &active,
                        const set<Person *> &remaining, bool inclusive) {
  PStep step;

  if (inclusive)
    step.insertToPeel(p);
  else
    step.peeled.insert(p);

  for (Plist *c = p->children; c != 0; c = c->next)
    if (remaining.count(c->p))
      step.insertToPeelRecursive(c->p, active);

  step.setAfter(active, remaining);

  return step;
}

PStep PPeeler::peelChildren(Person *p, Person *spouse,
                            const set<Person *> &active,
                            const set<Person *> &remaining) {
  PStep step;

  for (Plist *c = p->children; c != 0; c = c->next)
    if ((c->p->father == spouse || c->p->mother == spouse) &&
        remaining.count(c->p))
      step.insertToPeelRecursive(c->p, active);

  step.setAfter(active, remaining);

  return step;
}

PStep PPeeler::peelSingle(Person *p, const set<Person *> &active,
                          const set<Person *> &remaining) {
  PStep step;
  step.insertToPeel(p);

  step.setAfter(active, remaining);

  return step;
}

void PStep::calcPeelProb(const set<Person *> &active_before,
                         const set<Person *> &remaining_before, Cudd &mgr,
                         Trait *trait, const set<Person *> &non_founders) {
  const int old_prec = mgr.ReadRoundingPrec();
  mgr.SetRoundingPrec(old_prec + 15);
  set<Person *> active(active_before);
  active.insert(active_after.begin(), active_after.end());

  L = ActiveFunction(active);
  ESgraph g(peeled, remaining_before, trait);
  g.createpeelorder();
  ADDvector vars = mgr.GetADDVariables();
//  assertinternal(Cudd_DebugCheck(mgr.getManager()) == 0);
  for (Uint i = 0; i < Uint(L.x.count()); i++) {
    if (i > 0) g.cleanupprob(true);
    g.initializeprob(&mgr, active_before, non_founders);

    for (ESpeople *p = g.first; p != 0; p = p->next) {
      Person *per = p->val->per;
      set<Person *>::const_iterator ai = active.find(per);
      if (ai != active.end()) {
        const Uint d = distance(active.begin(), ai);
        const Uint gt = (i >> (2*d)) % 4;
        for (Uint g = 0; g < 4; g++)
          if (g != gt)
            p->val->add_peelprob[0][g] = mgr.addZero();
        if (active_before.count(per))
          assertinternal(p->val->add_peelprob[0][gt] == mgr.addOne());
      }
    }

    L.x[i] = g.performpeel(vars, mgr);
//    assertinternal(Cudd_DebugCheck(mgr.getManager()) == 0);
  }

  mgr.SetRoundingPrec(old_prec);
}
