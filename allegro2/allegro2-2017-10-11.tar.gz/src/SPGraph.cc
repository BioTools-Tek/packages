#include "SPGraph.hh"
#include "family.h"
#include "singlelocus.h"
#include "options.h"

SPGraph::SPGraph(Family *f, Cudd &m) : fam(f), mgr(m) {
  graph = new Graph(fam->first);
}

SPGraph::~SPGraph() {
  delete graph;
}

ADD SPGraph::homozygous_1unknown(Node *n0, Node *n1, Allele a, Plist* pl,
                                 int gam) {
  ADD result = mgr.addZero();
  if (n0->allele == a) {
    if (n1->setallele2(a)) {
      result = findq(pl->next, gam);
      n1->unsetallele2();
    }
  }
  return result;
}

ADD SPGraph::heterozygous_1unknown(Node *n0, Node *n1, Allele b0, Allele b1,
                                   Plist* pl, int gam) {
  ADD result = mgr.addZero();
  if (n0->allele == b0) n1->setallele2(b1);
  else if (n0->allele == b1) n1->setallele2(b0);
  if (n1->allele != ALLELEUNKNOWN) {
    result = findq(pl->next, gam);
    n1->unsetallele2();
  }
  return result;
}

ADD SPGraph::heterozygous_1block(Node *n0, Node *n1, Allele b0, Allele b1,
                                 Plist* pl, Uint gam) {
  ADD result = mgr.addZero();
  if (n1->block->a0 == b0 && n1->block->a1 == b1) {
    assertinternal(n1->block->addNode(n0, 1 - n1->group));
    result = findq(pl->next, gam);
    n1->block->removeNode(n0);
  }
  else if (n1->block->a0 == b0 || n1->block->a0 == b1 ||
           n1->block->a1 == b0 || n1->block->a1 == b1) {
    if (n1->block->a0 == b0) {
      n1->block->setalleles(n1->group);
      n0->allele = b1;
    }
    else if (n1->block->a0 == b1) {
      n1->block->setalleles(n1->group);
      n0->allele = b0;
    }
    else if (n1->block->a1 == b0) {
      n1->block->setalleles(1 - n1->group);
      n0->allele = b1;
    }
    else if (n1->block->a1 == b1) {
      n1->block->setalleles(1 - n1->group);
      n0->allele = b0;
    }
    result = findq(pl->next, gam);
    n0->allele = ALLELEUNKNOWN;
    n1->block->unsetalleles();
  }
  return result;
}

ADD SPGraph::heterozygous_2blocks(Node *n0, Node *n1, Allele b0, Allele b1,
                                  Plist* pl, int gam) {
  n0->block->setalleles(n0->block->a0 == b0 ? n0->group : 1 - n0->group);
  n1->block->setalleles(n1->block->a0 == b1 ? n1->group : 1 - n1->group);
  ADD result = findq(pl->next, gam);
  n0->block->unsetalleles();
  n1->block->unsetalleles();
  return result;
}

double SPGraph::fromhere(Uint gam, const Doublevector &freq, ADD &sp) {
  assertinternal(graph != 0);
//  zero(qp, fam->numiv);
  graph->reset2();
  graph->setallelefreq(const_cast<FloatVec>(&*freq.begin()));
  double nc = 1.0;
  // Add genotype edges belonging to founders
  for (Person *p = fam->first; p != fam->firstdescendant; p = p->next) {
    if (p->genotyped(gam)) {
      Allele a0 = p->gen[0][gam];
      Allele a1 = p->gen[1][gam];
      if (a0 == a1) {
        if (p->nod[0] != p->nod[1]) nc *= freq[a0 - 1]*freq[a0 - 1];
        else nc *= freq[a0 - 1];
      }
      graph->addfounderedge2(p->nod[0], p->nod[1], a0, a1);
    }
  }

  Plist *firstper = 0, *lastper = 0;
  for (Person *p = fam->firstdescendant; p != 0; p = p->next)
    if (p->children != 0 && p->hasgenotypeddesc(gam) || p->genotyped(gam)) {
      if (firstper == 0) lastper = firstper = new Elist(p, 0);
      else {
        lastper->next = new Elist(p, 0);
        lastper = lastper->next;
      }
      if (p->genotyped(gam))
        ((Elist *)(lastper))->edge =
          new Edge(p->gen[0][gam], p->gen[1][gam],
                   const_cast<FloatVec>(&*freq.begin()));
    }

  // Calculate single locus probabilities
  sp = findq(firstper, gam);

  delete firstper;
  graph->reset2();

  return nc;
}

ADD SPGraph::findq(Plist* pl, int gam) {
  if (pl == 0) {
    // return graph->symbolic_probability(mgr, 50);
    const double val = graph->probability2();
    return mgr.constant(val);
  }
  else {
    Person *p = pl->p;
    int Kf = p->patmask ? 1 : 0;
    int Km = p->matmask ? 1 : 0;
    if (Kf && (p->father->nod[0] == p->father->nod[1] ||
               p->father->nod[0]->allele != ALLELEUNKNOWN &&
               p->father->nod[0]->allele == p->father->nod[1]->allele))
      Kf = 0;
    if (Km && (p->mother->nod[0] == p->mother->nod[1] ||
               p->mother->nod[0]->allele != ALLELEUNKNOWN &&
               p->mother->nod[0]->allele == p->mother->nod[1]->allele))
      Km = 0;

    ADD qdd_00 = mgr.addZero();
    ADD qdd_01 = mgr.addZero();
    ADD qdd_10 = mgr.addZero();
    ADD qdd_11 = mgr.addZero();


    for (int K1 = 0; K1 <= Km; K1++) {
      Node *n1 = p->mother->nod[K1];
      p->nod[1] = n1;
      for (int K0 = 0; K0 <= Kf; K0++) {
        Node *n0 = p->father->nod[K0];
        if (!options->sexlinked || p->sex == FEMALE) p->nod[0] = n0;
        else n0 = p->nod[0] = p->nod[1];
        ADD &cur_qdd = (K0 == 0 ? (K1 == 0 ? qdd_00 : qdd_10) :
                        (K1 == 0 ? qdd_01 : qdd_11));
        if (p->genotyped(gam)) {
          const Allele b0 = p->gen[0][gam];
          const Allele b1 = p->gen[1][gam];
          assertinternal(b0 <= b1);
          const bool n0unknown = n0->allele == ALLELEUNKNOWN;
          const bool n1unknown = n1->allele == ALLELEUNKNOWN;
          if (b0 == b1) {
            if (!n0unknown) {
              if (!n1unknown) {
                if (n0->allele == b0 && n1->allele == b0)
                  cur_qdd = findq(pl->next, gam);
              }
              else // n1unknown
                cur_qdd = homozygous_1unknown(n0, n1, b0, pl, gam);
            }
            else { // n0unknown
              if (!n1unknown)
                cur_qdd = homozygous_1unknown(n1, n0, b0, pl, gam);
              else {
                if (n0->setallele2(b0)) {
                  if (n1->allele == b0) 
                    cur_qdd = findq(pl->next, gam);
                  else if (n1->allele == ALLELEUNKNOWN && n1->setallele2(b0)) {
                    cur_qdd = findq(pl->next, gam);
                    n1->unsetallele2();
                  }
                  n0->unsetallele2();
                }
              }
            }
          }
          else { // b0 != b1
            if (n0 == n1) continue;
            if (!n0unknown) {
              if (!n1unknown) {
                if (n0->allele == b0 && n1->allele == b1 ||
                    n0->allele == b1 && n1->allele == b0)
                  cur_qdd = findq(pl->next, gam);
              }
              else
                cur_qdd = heterozygous_1unknown(n0, n1, b0, b1, pl, gam);
            }
            else {
              if (!n1unknown) // n0unknown
                cur_qdd = heterozygous_1unknown(n1, n0, b0, b1, pl, gam);
              else { // n0unknown and n1unknown
                Block *n0block = n0->block;
                Block *n1block = n1->block;
                if (n0block == 0 && n1block == 0) {
                  Block *newblock = new Block(b0, b1);
                  assertinternal(newblock->addNode(n0, 0));
                  assertinternal(newblock->addNode(n1, 1));
                  cur_qdd = findq(pl->next, gam);
                  delete n0->block;
                  n0->block = n1->block = 0;
                }
                else if (n0block == 0)
                  cur_qdd = heterozygous_1block(n0, n1, b0, b1, pl, gam);
                else if (n1block == 0)
                  cur_qdd = heterozygous_1block(n1, n0, b0, b1, pl, gam);
                else {
                  if (n0block == n1block) {
                    if (b0 == n0block->a0 && b1 == n1block->a1 &&
                        n0->group != n1->group)
                      cur_qdd = findq(pl->next, gam);
                  }
                  else if (n0block->a0 == n1block->a0 &&
                           n0block->a1 == n1block->a1) {
                    if (n0block->a0 == b0 && n0block->a1 == b1) {
                      Block *newblock = new Block(*n0block, *n1block,
                                                  n0->group == n1->group ?
                                                  1 : 0);
                      cur_qdd = findq(pl->next, gam);
                      n0block->resetnodes();
                      n1block->resetnodes();
                      delete newblock;
                    }
                  }
                  else if ((n0block->a0 == b0 || n0block->a1 == b0) &&
                           (n1block->a0 == b1 || n1block->a1 == b1))
                    cur_qdd = heterozygous_2blocks(n0, n1, b0, b1, pl, gam);
                  else if ((n0block->a0 == b1 || n0block->a1 == b1) &&
                           (n1block->a0 == b0 || n1block->a1 == b0))
                    cur_qdd = heterozygous_2blocks(n1, n0, b0, b1, pl, gam);
                }
              }
            }
          }
        }
        else cur_qdd = findq(pl->next, gam);
      }
    }

    ADD result;

    if (Km == 1 && Kf == 1) {
      result = uniqueInter(p->matbitlevel, mgr,
                           uniqueInter(p->patbitlevel, mgr, qdd_11, qdd_10),
          uniqueInter(p->patbitlevel, mgr, qdd_01, qdd_00));
    }
    else if (Km == 1)
      result = uniqueInter(p->matbitlevel, mgr, qdd_10, qdd_00);
    else if (Kf == 1)
      result = uniqueInter(p->patbitlevel, mgr, qdd_01, qdd_00);
    else
      result = qdd_00;

    return result;
  }
}
