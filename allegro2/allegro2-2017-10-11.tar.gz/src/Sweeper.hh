#ifndef _SWEEPER
#define _SWEEPER

#include <algorithm>
#include <map>
#include <set>

#include "cuddObj.hh"

#include "SW.hh"

#include "basic.h"
#include "haldane.h"
#include "cuddutil.h"
#include "options.h"
#include "BFunction.hh"
#include "Unreduced.hh"

//////////////////////////////////////////////////////////////////////
class RecombAccumulator : public map<Unreduced, double> {
public:
  RecombAccumulator() {}
  RecombAccumulator(const set<Unreduced> &ub) {
    for (set<Unreduced>::const_iterator bit = ub.begin(); bit != ub.end();
         bit++)
      operator[](*bit) = .0;
  }
  RecombAccumulator(const RecombAccumulator &ra,
                    const set<Unreduced> &use_bits) :
    map<Unreduced, double>(ra) {
    reset();
    for (set<Unreduced>::const_iterator ubit = use_bits.begin();
         ubit != use_bits.end(); ubit++) {
      iterator bit = find(*ubit);
      assert(bit != end());
      const_iterator ra_bit = ra.find(*ubit);
      assert(ra_bit != ra.end());
      bit->second = ra_bit->second;
    }
  }

  void doBits(const set<Unreduced> &bits) {
    for (set<Unreduced>::const_iterator bit = bits.begin();
         bit != bits.end(); bit++) {
      map<Unreduced, double>::iterator ubit = find(*bit);
      assert(ubit != end());
      ubit->second = .0;
    }
  }

  bool done() const {
    for (const_iterator bit = begin(); bit != end(); bit++)
      if (bit->second != .0)
        return false;
    return true;
  }

  void add(double theta_male, double theta_female, const set<Unreduced> &bits) {
    for (set<Unreduced>::const_iterator bit = bits.begin(); bit != bits.end();
         bit++) {
      iterator biter = find(*bit);
      assertinternal(biter != end());
      double theta = biter->first.isFemale() ? theta_female : theta_male;
      if (biter->first.isIntense())
        theta = 2.*theta*(1 - theta);
      biter->second = addrec(biter->second, theta);
    }
  }

  void add(double theta_male, double theta_female) {
    for (iterator bit = begin(); bit != end(); bit++) {
      double theta = bit->first.isFemale() ? theta_female : theta_male;
      if (bit->first.isIntense())
        theta = 2.*theta*(1 - theta);
      bit->second = addrec(bit->second, theta);
    }
  }

  void reset() {
    for (iterator i = begin(); i != end(); i++)
      i->second = .0;
  }

  unsigned int numLeft() const {
    unsigned int nl = 0;
    for (const_iterator i = begin(); i != end(); i++)
      if (i->second != .0)
        nl++;
    return nl;
  }

  double resipProduct() const {
    double rp = 1.;
    for (const_iterator bit = begin(); bit != end(); bit++)
      rp *= 1. - bit->second;
    return rp;
  }

  void print() const;

  friend RecombAccumulator operator+(const RecombAccumulator &a,
                                     const RecombAccumulator &b) {
    assert(a.size() == b.size());
    RecombAccumulator s(a);

    for (iterator i = s.begin(); i != s.end(); i++) {
      const_iterator bi = b.find(i->first);
      assert(bi != b.end());
      i->second = addrec(i->second, bi->second);
    }

    return s;
  }

  friend bool operator==(const RecombAccumulator &a,
                         const RecombAccumulator &b) {
    if (a.size() != b.size()) return false;
    for (const_iterator ai = a.begin(); ai != a.end(); ai++) {
      const_iterator bi = b.find(ai->first);
      if (bi == b.end() || fabs(bi->second - ai->second) > 1e-4)
        return false;
    }
    return true;
  }

};

//////////////////////////////////////////////////////////////////////
class ConvolutionStep;
class FamilyMap;
class Map;

class ADDWorkSpace {
private:
  class WorkRecord {
  public:
    BFunction *m_bf;
    bool m_needed;

    WorkRecord() : m_bf(0), m_needed(false) {}
    WorkRecord(const WorkRecord &wr, bool swap, const string &name = "") :
        m_needed(false) {
      if (!swap) {
        if (wr.m_bf->type() == BFunction::ADD_FUN)
          m_bf = new ADDFunction(*dynamic_cast<ADDFunction *>(wr.m_bf));
        else
          m_bf = new VectorFunction(*dynamic_cast<VectorFunction *>(wr.m_bf));
      } else {
        assertinternal(!wr.m_needed);
        if (wr.m_bf->inMemory()) {
          const string sf(options->swapdirname + "/ADDWorkSpace_" + name);
          if (wr.m_bf->type() == BFunction::ADD_FUN)
            m_bf = new ADDFunction(*dynamic_cast<ADDFunction *>(wr.m_bf), sf);
          else
            m_bf = new VectorFunction(*dynamic_cast<VectorFunction *>(wr.m_bf),
                                      sf);
        } else {
          if (wr.m_bf->type() == BFunction::ADD_FUN)
            m_bf = new ADDFunction(wr.m_bf->swapFile(), wr.m_bf->manager());
          else
            m_bf = new VectorFunction(wr.m_bf->swapFile(), wr.m_bf->manager());
        }
      }
    }
    WorkRecord(ADD &x) : m_bf(new ADDFunction(x)), m_needed(false) {}
    ~WorkRecord() {} // {delete m_bf;}

    void cleanUp() {
      delete m_bf;
    }
  };

  map<string, WorkRecord> data;

  const unsigned int num_vars;

  WorkRecord &find(const string &name) {
    map<string, WorkRecord>::iterator i = data.find(name);
    assertinternal(i != data.end());
    return i->second;
  }
  const WorkRecord &find(const string &name) const {
    map<string, WorkRecord>::const_iterator i = data.find(name);
    assertinternal(i != data.end());
    return i->second;
  }


public:
  ADDWorkSpace(unsigned int nv) : num_vars(nv) {}

  void add(ADD x, const string &name) {
    assertinternal(data.find(name) == data.end());
    assertinternal(x.manager() == 0 ||
                   (unsigned int)(x.manager()->ReadSize()) == num_vars);
    data[name] = WorkRecord(x);
  }
  void add(const string &file, Cudd &manager, bool ADD_file,
           const string &name) {
    if (ADD_file)
      data[name].m_bf = new ADDFunction(file, manager);
    else
      data[name].m_bf = new VectorFunction(file, manager);
  }
  bool isStored(const string &name) {
    return data.find(name) != data.end();
  }
  void erase(const string &name) {
    data[name].cleanUp();
    data.erase(name);
  }
  void clear() {
    for (map<string, WorkRecord>::iterator i = data.begin(); i != data.end();
         i++)
      i->second.cleanUp();
  }

  bool empty() const {return data.empty();}
  void copy(const string &dest, const string &src) {
    assertinternal(data.find(dest) == data.end());
    if (4*memoryInUse() > 3*options->maxmem)
      data[dest] = WorkRecord(data[src], true, src);
    else {
      WorkRecord &sd(data[src]);
      data[dest] = WorkRecord(sd, false);
      sd.m_needed = false;
    }
  }

//   void copyAndSwap(const string &dest, const string &src) {
//     data[dest] = WorkRecord(data[src], src);
//   }

  Uint memoryInUse() {
    Uint mem = Cudd::memoryInUse();
    for (map<string, WorkRecord>::const_iterator di = data.begin();
         di != data.end(); di++)
      if (di->second.m_bf->type() == BFunction::VECTOR_FUN)
        mem += di->second.m_bf->memoryInUse();
    return mem;
  }

//   BFunction &get(const string &name) {
//     map<string, WorkRecord>::iterator i = data.find(name);
//     assertinternal(i != data.end());
// //     i->second.m_needed = true;
// //     if (!i->second.inMemory())
// //       i->second.readFromFile();
// //       if (i->second.manager->ReadSize() == 0) {
// //         Cudd new_mgr(num_vars, 0, 256, 262144, options->maxmem*(1 << 20)/8);
// //         i->second.manager() = new_mgr;
// //       }
// //       i->second.add = readADD(i->second.swap_file, *i->second.manager);
// //       i->second.swap_file = "";
// //     }
// //     return i->second.add;
//     return i->second;
//   }

//   void addVector(double *f, Cudd &mgr, const string &name);
  double *getVector(const string &name) {
//    addToVector(f, get(name));
//    dontNeed(name);
    map<string, WorkRecord>::iterator i = data.find(name);
    assertinternal(i != data.end());
    assertinternal(i->second.m_bf->type() == BFunction::VECTOR_FUN);
    i->second.m_needed = true;
    VectorFunction *vf = dynamic_cast<VectorFunction *>(i->second.m_bf);
    vf->expand();
    return vf->getVector();
  }
  ADD &getADD(const string &name) {
    WorkRecord &wr = find(name);
    assertinternal(wr.m_bf->type() == BFunction::ADD_FUN);
    wr.m_needed = true;
    return dynamic_cast<ADDFunction *>(wr.m_bf)->getADD();
  }
  void setADD(const string &name, ADD x) {
    WorkRecord &wr = find(name);
    assertinternal(wr.m_bf->type() == BFunction::ADD_FUN);
    dynamic_cast<ADDFunction *>(wr.m_bf)->setADD(x);
  }
  void transferADD(const string &from, const string &to) {
    WorkRecord &wr_from = find(from);
    WorkRecord &wr_to = find(to);
    assertinternal(wr_from.m_bf->type() == BFunction::ADD_FUN);
    return dynamic_cast<ADDFunction *>(wr_from.m_bf)->
      transferTo(wr_to.m_bf->manager());
  }

  ADD asADD(const string &name, ADD &zo) {
    WorkRecord &wr = find(name);
    if (wr.m_bf->type() == BFunction::ADD_FUN)
      return getADD(name);
    else
      return dynamic_cast<VectorFunction *>(wr.m_bf)->asADD(zo);
  }

  void dontNeed(const string &name) {data[name].m_needed = false;}

  void swapToFile(const string &name) {
    WorkRecord &wr = find(name);
    assertinternal(wr.m_needed == false);

    if (wr.m_bf->inMemory())
      writeToFile(options->swapdirname + "/ADDWorkSpace_" + name, name, true);
  }

  void writeToFile(const string &fn, const string &name, bool swap = false) {
    find(name).m_bf->writeToFile(fn, swap);
  }

  void changeToVector(const string &name) {
    WorkRecord &wr = find(name);
    assertinternal(wr.m_bf->type() == BFunction::ADD_FUN);

    ADD add = dynamic_cast<ADDFunction *>(wr.m_bf)->getADD();

    delete wr.m_bf;
    wr.m_bf = new VectorFunction(add);
  }

  void changeToADD(const string &name, ADD &zo) {
    WorkRecord &wr = find(name);
    assertinternal(wr.m_bf->type() == BFunction::VECTOR_FUN);

    ADD add = dynamic_cast<VectorFunction *>(wr.m_bf)->asADD(zo);

    delete wr.m_bf;
    wr.m_bf = new ADDFunction(add);
  }

  void asStraightVector(const string &name, double *res) {
    find(name).m_bf->asStraightVector(res);
  }

  BFunction::Type type(const string &name) const {
    return find(name).m_bf->type();
  }
  void transfer(const string &name, Cudd &mgr) {find(name).m_bf->transfer(mgr);}
  Cudd &manager(const string &name) {return find(name).m_bf->manager();}
  bool isConstant(const string &name) const {
    return find(name).m_bf->isConstant();
  }
  bool isZero(const string &name) const {return find(name).m_bf->isZero();}
  bool isPositive(const string &name) {return find(name).m_bf->isPositive();}

  void inplaceMult(const string &name, ADD &y) {
    find(name).m_bf->inplaceMult(y);
  }
  void inplaceMult(const string &x, const string &y) {
    find(x).m_bf->inplaceMultBF(*find(y).m_bf);
  }

  int *getInvperm(const string &name) {return find(name).m_bf->getInvperm();}
  int *getPerm(const string &name) {return find(name).m_bf->getPerm();}
  void shuffle(const string &name, int *invperm) {
    find(name).m_bf->shuffle(invperm);
  }

  int *support(const string &name) {return find(name).m_bf->support();}

  void integrateOut(const string &name, const set<Unreduced> &bits) {
    find(name).m_bf->integrateOut(bits);
  }

  double dotProduct(const string &a, const string &b) {
    WorkRecord &a_wr = find(a);
    WorkRecord &b_wr = find(b);

    if (a_wr.m_bf->type() == BFunction::VECTOR_FUN)
      return a_wr.m_bf->dotProduct(*b_wr.m_bf);
    else
      return b_wr.m_bf->dotProduct(*a_wr.m_bf);
  }
  double dotProductRec(const string &a, const string &b, const Unreduced &bit) {
    WorkRecord &a_wr = find(a);
    WorkRecord &b_wr = find(b);

    if (a_wr.m_bf->type() == BFunction::VECTOR_FUN)
      return a_wr.m_bf->dotProductRec(*b_wr.m_bf, bit);
    else
      return b_wr.m_bf->dotProductRec(*a_wr.m_bf, bit);
  }

  void makeSpace(unsigned int want, unsigned int available);

  // for debugging
  void print();
  void printBF(char *name, int print_level);
  void printZO(char *name, int print_level);

  void checkManagers();

};

class Sweeper {
private:
  Cudd mgr;

  const unsigned int nbits;

  set<Unreduced> unreduced;

  RecombAccumulator racc;
//  ADD from;

  ADDWorkSpace work_space;

  struct delete_ptr {
    template<class T> T* operator()(T* p) const {delete p; return 0;}
  };
public:
  Sweeper(Family *fam);
  ~Sweeper() {
    work_space.clear();
  }

  void setup(ADDvector &sp);

  ADD integrateOutUninteresting(ADD &x) {
    work_space.add(x, "x");
    work_space.integrateOut("x", uninteresting);
    ADD res(work_space.getADD("x"));
    work_space.erase("x");
    return res;
//    return integrateOut(x, uninteresting);
  }

  const RecombAccumulator &getRacc() const {return racc;}

  void makeIntense(uint64_t bit) {
    for (set<Unreduced>::iterator ui = unreduced.begin(); ui != unreduced.end();
         ui++)
      if (ui->type == Unreduced::REGULAR && ui->begin == bit) {
        const_cast<Unreduced &>(*ui).makeIntense();
        return;
      }
    assertinternal(false);
  }
  void makeFemale(uint64_t bit) {
    for (set<Unreduced>::iterator ui = unreduced.begin(); ui != unreduced.end();
         ui++)
      if (ui->type == Unreduced::REGULAR && ui->begin == bit) {
        const_cast<Unreduced &>(*ui).makeFemale();
        return;
      }
    assertinternal(false);
  }

  void addFounderReduction(const vector<ReducedIndex> &flips, bool interesting,
                           bool female);
  void addFounderCoupleReduction(const vector<ReducedIndex> &flips,
                                 const vector<ReducedIndex> &src,
                                 const vector<ReducedIndex> &dest,
                                 bool interesting);
  void firstMarker();
  void lastMarker();
  void nextMarker(RecombAccumulator &ra, double theta_male, double theta_female,
                  Uint gam, bool viterbi, bool from_left);
  void updateFrom(ADD &spt);
  bool writeFrom(const string &fn) {
    work_space.writeToFile(fn, "from");
    work_space.dontNeed("from");
    return work_space.type("from") == BFunction::ADD_FUN;
  }

  void viterbiStep(RecombAccumulator &ra, double theta_male,
                   double theta_female, ADD spt, const string &fn);

  ADD completeStep(const string &left_file, bool left_is_ADD,
                   const RecombAccumulator &ra_left, Uint gam,
                   const RecombAccumulator &ra_right, Cudd &comp_mgr);
  void completeUninformative(Uint &pos, const FamilyMap &fm, const string &left,
                             bool left_is_ADD, const RecombAccumulator &la,
                             ADD &sp, Map *map, Cudd &mgr);

  static set<Unreduced> informativePass(ADD to,
                                        const set<Unreduced> &unreduced);

  IV startViterbiBacktrack();
  IV viterbiBacktrack(IV left, RecombAccumulator &ra, ADD spt,
                      double theta_male, double theta_female,
                      const string &rfn);

  void calcRecombDist(const string &left_fn, bool left_is_ADD,
                      const RecombAccumulator &la, ADD &sp, Uint gam_m_1,
                      double theta, double theta_female);
  void probRecomb(double &recomb, double &recomb_female, const string &left,
                  const RecombAccumulator &ral, double theta,
                  double theta_female);

private:
  set<Unreduced> uninteresting;

  struct SPTStructure {
    ADD spt;
    set<Unreduced> informative;
    set<Unreduced> uninformative_from_left;
    set<Unreduced> uninformative_from_right;

  };
  vector<SPTStructure> spt_structure;

  uint64_t informativeBits(ADD);
  double handleUninteresting(const string &zo, const string &left,
                             const RecombAccumulator &ra_left,
                             const string &right,
                             const RecombAccumulator &ra_right,
                             const set<Unreduced> &unint);
  static ADD splitUninterestingConvolutions(ADD zo_left,
                                            RecombAccumulator &ra_ul,
                                            unsigned int num_left_nodes,
                                            ADD zo_right,
                                            RecombAccumulator &ra_ur,
                                            unsigned int num_right_nodes);
  void handleUninterestingSide(const string &side, const string &zo,
                               RecombAccumulator &ra);
  void convolutionPass(const string &res_name, const string &zo_name,
                       const set<Unreduced> &targ, RecombAccumulator &ra,
                       bool viterbi);

  ADD completeInteresting(const string &zo, ADD &sp,
                          const string &left, RecombAccumulator &ral,
                          const string &right, RecombAccumulator &rar,
                          Cudd &result_mgr);
  void completeUninformativeSide(const string &side,
                                        const string &zo_side,
                                        const set<Unreduced> &unhandled,
                                        RecombAccumulator &sra);
  string completeLQR(const string &left, ADD &sp, const string &right);
//  static DdNode *expandZO(DdNode *zo, DdManager *mgr, st_table *table);
  ADD expandZO(ADD &zo) const;

  static void
  swapConvolutionStepCreateFiles(ADD res, ADD zo, ADD cube,
                                 const vector<Uint> &cond_bits, Uint cond_idx,
                                 const string &output,
                                 map<DdNode *, string> &results,
                                 map<DdNode *, string> &result_names);
  void convolutionStep(const string &res, const string &zo,
                       ConvolutionStep **cs, ConvolutionStep **cs_end,
                       bool viterbi);

  class ZOEffect {
  public:
    ADD zo;
    double minterms;
    Unreduced bit;

    ZOEffect(const Unreduced &b) : minterms(-1.), bit(b) {}

    friend bool operator==(const ZOEffect &a, const ZOEffect &b) {
      return a.bit == b.bit;
    }

  };

  static void findOptimalHandlingOrder(vector<Unreduced> &optimal_order, ADD zo,
                                       const set<Unreduced> &targ);
  static void findHandlingOrderRand(ADD zo, vector<ZOEffect> &v);
  static bool trySwapping(ZOEffect &a, ZOEffect &b);
  static void print(const vector<Sweeper::ZOEffect> &effects);

  static set<Unreduced> findLegalStepSubset(set<Unreduced> &unhandled,
                                            double minterm);
  double skipCompleteUninformative(const string &zo, const string &tl,
                                   RecombAccumulator ralt,
                                   ADD &sp, const string &tr,
                                   RecombAccumulator rart,
                                   const set<Unreduced> &unhandled);

  static ADD maxOut(ADD x, const set<Unreduced> &u, bool out_reduced);
  static ADD ivToADD(IV v, Cudd &mgr);
  static IV getMaxIV(IV max_iv, DdNode *x, DdNode *mx, st_table *table);
  static IV getMaxIV(ADD x);
  IV viterbiBacktrack(const string &left, const string &right,
                      RecombAccumulator &ra);

  void probRecombSplit(double &recomb, double &recomb_female,
                       const set<Unreduced> &all_bits,
                       const set<Unreduced> &convolve_bits,
                       const set<Unreduced> &remaining_bits,
                       const string &left_name, const RecombAccumulator &ral,
                       const string &right_name, const RecombAccumulator &rar,
                       double theta, double theta_female);
  void probRecomb(double &recomb, double &recomb_female,
                  const set<Unreduced> &bits, const string &left,
                  const RecombAccumulator &ral, const string &right,
                  const RecombAccumulator &rar, double theta,
                  double theta_female);

  set<Unreduced> findUninterestingUninformative(Uint gam, bool right,
                                                ADD &side);
  void
  integrateOutUninterestingUninformative(ADD &side, ADD &sp, ADD &zo,
                                         const set<Unreduced> &unint_uninf);

  void buildBitInfo(vector<pair<Unreduced, double> > &bi,
                    const set<Unreduced> &unhandled,
                    ADD &left, RecombAccumulator &ral,
                    ADD &right, RecombAccumulator &rar);

  void checkManagers();
  void checkBF(const string &name, const string &ref_fn, const Uint gam);

};

#endif // _SWEEPER
