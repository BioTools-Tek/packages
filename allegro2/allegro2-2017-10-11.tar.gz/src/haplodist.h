#ifndef _HAPLODIST
#define _HAPLODIST
#include "basic.h"
#include "viterbidist.h"
#include "fmtout.h"
#include "family.h"
#include "options.h"
#include "map.h"

class Haplodist : public Viterbidist {
public:
  static Haplodist *gethaplodist(const string &haplo, const string &inher,
                                 const string &ihaplo, const string &founder);
  virtual string describe() const {return "haplotype";}
  virtual void print() const;

  /// Returns true if the family will be used by the distribution.
  virtual bool usefamily(Family */*fam*/, bool /*mtbdd*/) const {return true;}
  /// Returns true if families that have no uninformative markers are to be
  /// used
  virtual bool useuninformative() const {return true;}

protected:
  Haplodist(const string &hapf, const string &inhf, const string &ihapf,
            const string &fndrf, const string &p = "hpt");

  Outfile haplotypefile;
  Outfile inherfile;
  Outfile ihaplotypefile;
  Outfile founderallelefile;

  void ivout(IVVec ivpath, bool pick_mle);
  virtual void printresults(const vector<IntMat> &curbits,
                            vector<Allele **> &alleles,
                            const vector<IntMat> founderalleles);
  void printheaders();
private:
  Uint colwidth;

  void setbits(Person *p, IntVec firstfounderbit, Uint &j, IntMat curbits,
               IV v1) const;
  void updatefirstfounderbit(Person *p, int &fb, int &tb, IV v0, IV v1,
                             Float tht, bool pick_mle) const;
  void updatefirstgcbit(Foundercouple *fc, int &fb, int &tb, IV v0, IV v1,
                        Float tht, bool pick_mle) const;

  template<typename T>
  void outputfile(ostream &f, const vector<T> &x, Person *firstper,
                  bool trans = false) {
    f << "\n";
    for (Person *p = firstper; p != 0; p = p->next) {
      if (!options->sexlinked || p->sex == FEMALE)
        printline(f, p, x, 0, trans);
      printline(f, p, x, 1, trans);
    }
  }

  void markerheader(ostream &f, Uint maxlen);
  void printper(ostream &f, Person *p);
  template<typename T>
  void printline(ostream &f, Person *p, const vector<T> &x, int sex,
                 bool trans) {
    printper(f, p);
    for (Uint gam = 0; gam < map->loci.size(); gam++)
      if (trans && options->printoriginalalleles) {
        if (x[gam][p->nmrk][sex] == ALLELEUNKNOWN)
          fmtout(f, colwidth, options->unknownrepeatstring, false);
        else
          fmtout(f, colwidth,
                 map->loci[gam].origalleles[x[gam][p->nmrk][sex] - 1]);
      }
      else
        fmtout(f, colwidth, x[gam][p->nmrk][sex]);
    f << "\n";
  }

  virtual void set(FloatVec pv, Uint pos);
  virtual void set(ADD &pv, double sum_pv, Uint pos);
  virtual void reset(Uint np);
};

#endif // _HAPLODIST
