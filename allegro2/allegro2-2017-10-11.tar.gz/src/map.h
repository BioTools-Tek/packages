#ifndef _MAP
#define _MAP
#include "basic.h"
#include "options.h"

#include <map>
#include <iostream>

class Infile;

class Haplotype : public vector<Allele> {
public:
  Haplotype(Uint n = 0, Allele a = 0) : vector<Allele>(n, a) {}

  bool isConsistent(const Haplotype &h) const {
    if (h.size() != size()) return false;
    for (unsigned int i = 0; i < size(); i++)
      if (h[i] != this->operator[](i) && h[i] != 0 && this->operator[](i) != 0)
        return false;
    return true;
  }

  Haplotype intersection(const Haplotype &h) const {
    assert(h.size() == size());
    Haplotype res(size());
    for (unsigned int i = 0; i < size(); i++)
      if (h[i] == 0)
        res[i] = this->operator[](i);
      else {
        assertinternal(this->operator[](i) == 0 || h[i] == this->operator[](i))
        res[i] = h[i];
      }
    return res;
  }

  friend ostream &operator<<(ostream &out, const Haplotype &h) {
    for (unsigned int i = 0; i < h.size(); i++) {
      if (i > 0) out << "/";
      out << int(h[i]);
    }
    return out;
  }
  void print() const {
    cout << *this << endl;
  }

};

class Pos {
private:
  Float m_position[2];
public:
  Pos() {m_position[0] = m_position[1] = NAN;}

  Float positionAvg() const {return (m_position[0] + m_position[1])/2.;}
  Float positionMale() const {return m_position[0];}
  Float positionFemale() const {return m_position[1];}
  Float position(Uint type) const {
    switch (type) {
      case MALE: return positionMale();
      case FEMALE: return positionFemale();
      default: return positionAvg();
    }
  }
  void setPosition(Float pos, int isex) {
    if (isex == 0)
      m_position[0] = m_position[1] = pos;
    else
      m_position[isex - 1] = pos;
  }

};

class HaploTree {
public:
  map<Uint, HaploTree> branches;
  Uint index;

  void insert(const Haplotype &h, Uint idx) {
    insert(h.begin(), h.end(), idx);
  }
  void insert(Haplotype::const_iterator h_i, Haplotype::const_iterator h_end,
              Uint idx) {
    if (h_i == h_end)
      index = idx;
    else
      branches[*h_i].insert(h_i + 1, h_end, idx);
  }

  void print() const;
  void printutil(const string s) const {
    if (branches.empty())
      cout << s << index << endl;
    else
      for (map<Uint, HaploTree>::const_iterator bi = branches.begin();
           bi != branches.end(); bi++)
        bi->second.printutil(s + bi->first + "\t");
  }

};

class LocusInfo : public Pos {
private:
  Float theta[2];

public:
  Uint numallele; // numallele is the number of alleles at locus
  vector<vector<Float> > pi; // population allele frequencies (array of matrices)
                             // pi[p][m][a] is the frequency of allele a + 1 at
                             // marker m in population p
  vector<int> origalleles; // only used if options->printorigalleles is true

  string name;
  bool shouldfindp;   // Should multipoint stuff be calculated

//   map<Haplotype, Uint> haplotypeidx;
  vector<HaploTree> ht;

  // which markers map to the locus
  vector<Uint> locus2markers;
  vector<string> markernames;

  LocusInfo() : Pos() {theta[0] = theta[1] = NAN;}

  Float thetaMale() const {return theta[0];}
  Float thetaFemale() const {return theta[1];}
  void setTheta(Float th, int isex) {
    if (isex == 0)
      theta[0] = theta[1] = th;
    else
      theta[isex - 1] = th;
  }

  void merge(const LocusInfo &loc) {
    theta[0] = loc.theta[0];
    theta[1] = loc.theta[1];
    name += "/" + loc.name;
    locus2markers.insert(locus2markers.end(), loc.locus2markers.begin(),
                         loc.locus2markers.end());
    markernames.insert(markernames.end(), loc.markernames.begin(),
                       loc.markernames.end());
  }

};

class PosInfo : public Pos {
public:
  bool inbetween;     // Is position inbetween markers or at marker
  int leftmarker;     // The next informative marker to the left
};

class Map {
public:
  Map();              // Create empty map
  void init(Uint N);  // initilize to N markers
  // to add info on marker number m:
  void addmarker(Uint m, Uint num_p, FloatVec p, const string &mn);
  void addpopulationfreq(Uint m, Uint popidx, Uint nump, FloatVec p);
  void adddist(Float firstmarker_pos, FloatVec dist,
               int isex);  // to add intermarker distances
  Allele randomallele(Uint gam) const;

  vector<LocusInfo> loci;
  vector<PosInfo> positions;

  void reset();

  void setunit(Unit u) {unit = u;}

  void readhaplofreqs();

protected:
  void createpos();
  void readstepfile(Infile& f);
  void maxsteplength();
  void fixedstep();
  void allocate(Uint n);
  void start();
  Uint nsex;
  Unit unit;
};

#endif // _MAP
