#include "files.h"
#include "scoredistfull.h"
#include "family.h"
#include "map.h"
#include "fmtout.h"
#include "calcscore.h"
#include "cuddutil.h"
#include "SW.hh"

Scoredistfull::Scoredistfull(const string &p, Float maxs) :
    Scoredist(p, 0), maxscore(maxs), scoreval(0), iscoreval(0), lowtable(0) {
  curmaxscore = Uint(maxscore) - 1;
  if (maxscore > 0) lowtable = new Double[Uint(maxscore)];
}

Scoredistfull::~Scoredistfull() {
  while (!familydata.empty()) {
    delete familydata.back();
    familydata.pop_back();
  }
  delete [] lowtable;
}

void Scoredistfull::reset(Uint np) {
  while (!familydata.empty()) {
    delete familydata.back();
    familydata.pop_back();
  }
  npos = np;
}

void Scoredistfull::zerotables() {
  if (maxscore > 0) zero(lowtable, curmaxscore + 1);
  for (Table::iterator i = hightable.begin(); i != hightable.end(); i++)
    i->second = 0.0;
}

void Scoredistfull::nextfam(bool mtbdd, Uint pos, FloatVec p0) {
  if (pos == 0) {
    delete [] iscoreval;
    familydata.push_back(new Familydata(this));
  }
  Familydata *famdat = familydata.back();
  hightable.clear();
  zerotables();
  curmaxscore = 0;
  const IV numscores = (curfamily()->numiv()*
                        (IV(1) << curfamily()->nasymmetricfoundercouples()));
  if (pos == 0) {
    if (mtbdd) {
      for (Uint a = 0; a < (1U << curfamily()->nasymmetricfoundercouples());
           a++)
        setuptables(calcscore->S[a].getNode());

    }
    else {
      scoreval = calcscore->vec;
      iscoreval = new Uint[numscores];
      for (IV v = 0; v < numscores; v++) iscoreval[v] = Uint(scoreval[v]);
      for (IV v = 0; v < numscores; v++) {
        if (scoreval[v] >= maxscore) {
          if (hightable.find(scoreval[v]) == hightable.end())
            hightable.insert(Table::value_type(scoreval[v], 0.0));
        }
        else if (maxscore > 0) {
          lowtable[iscoreval[v]] = 1.0;
          if (curmaxscore < iscoreval[v]) curmaxscore = iscoreval[v];
        }
      }
    }

    Uint scidx = hightable.size();
    if (maxscore > 0)
      for (Uint i = 0; i <= curmaxscore; i++)
        if (lowtable[i] != 0.0) scidx++;
    famdat->nscores = scidx;
    assertcond(famdat->nscores > 0, "No score possible!");
    famdat->nullprob = newmatrix<Double>(npos, famdat->nscores);
    zero(famdat->nullprob[0], npos*famdat->nscores);
    famdat->value = new Double[famdat->nscores];
    scidx = 0;
    for (IT i = hightable.begin(); i != hightable.end(); i++) {
      famdat->value[scidx] = i->first;
      scidx++;
    }


    if (maxscore > 0)
      for (Uint i = 0; i <= curmaxscore; i++) {
        if (lowtable[i] != 0.0) {
          famdat->value[scidx] = i;
          scidx++;
        }
      }
  }

  zerotables();
  if (isnullconstant()) {
    if (mtbdd) {
      Cudd &mgr = *calcscore->S[0].manager();
      updatetables(mgr.constant(1./Double(curfamily()->numiv())), 1.);
      assert(lowtable == 0 ||
             fabs(sum<double>(lowtable, curmaxscore + 1) - 1.) < .01);
    }
    else {
      const Double unif = 1.0/Double(numscores);
      for (IV v = 0; v < numscores; v++) {
        if (lowtable != 0 && scoreval[v] < maxscore)
          lowtable[iscoreval[v]] += unif;
        else hightable[scoreval[v]] += unif;
      }
    }
  }
  else {
    assertinternal(!mtbdd);
    updatetables(p0);
  }
  tablestoprob(famdat->nullprob[pos]);
}

void Scoredistfull::tablestoprob(DoubleVec d) {
  Uint scidx = 0;
  Familydata *famdat = familydata.back();
  for (IT i = hightable.begin(); i != hightable.end(); i++) {
    assertinternal(i->first >= famdat->value[scidx]);
    while (i->first > famdat->value[scidx]) scidx++;
    d[scidx] = i->second;
    scidx++;
  }
  if (maxscore > 0)
    for (Uint i = 0; i <= curmaxscore; i++) {
      if (lowtable[i] != 0.0) {
        if (Double(i) >= famdat->value[scidx])
          assertinternal(Double(i) >= famdat->value[scidx]);
        while (Double(i) > famdat->value[scidx]) scidx++;
        d[scidx] = lowtable[i];
        scidx++;
      }
    }
}

void Scoredistfull::updatetables(FloatVec pv) {
  const IV numiv = curfamily()->numiv();
  for (Uint a = 0; a < (Uint(1) << curfamily()->nasymmetricfoundercouples());
       a++) {
    UintVec is = iscoreval + a*numiv;
    DoubleVec sv = scoreval + a*numiv;
    for (IV v = 0; v < numiv; v++) {
      if (sv[v] < maxscore) lowtable[is[v]] += pv[v];
      else hightable[sv[v]] += pv[v];
    }
  }
}

void Scoredistfull::set(FloatVec pv, Uint pos) {
  zerotables();
  updatetables(pv);
  Familydata *famdat = familydata.back();
  famdat->prob[pos] = new Double[famdat->nscores];
  zero(famdat->prob[pos], famdat->nscores);
  tablestoprob(famdat->prob[pos]);
  if (curfamily()->nasymmetricfoundercouples() > 0) {
    Double fac = 1.0/Double(1 << curfamily()->nasymmetricfoundercouples());
    for (Uint i = 0; i < famdat->nscores; i++)
      famdat->prob[pos][i] *= fac;
  }
}

void Scoredistfull::skipfam() {
  if (!familydata.empty()) {
    delete familydata.back();
    familydata.pop_back();
  }
}

void Scoredistfull::getresults(UintVec nscores, DoubleMat value,
                               DoubleMat *prob, DoubleMat *nullprob) {
  for (Uint fam = 0; fam < familydata.size(); fam++) {
    nscores[fam] = familydata[fam]->nscores;
    value[fam] = familydata[fam]->value;
    prob[fam] = familydata[fam]->prob;
    for (Uint pos = 0; pos < nnulldist(); pos++)
      nullprob[pos][fam] = familydata[fam]->nullprob[pos];
  }
}

void Scoredistfull::set(ADD &pv, double sum_pv, Uint pos) {
  zerotables();
  updatetables(pv, sum_pv);
  Familydata *famdat = familydata.back();
  famdat->prob[pos] = new double[famdat->nscores];
  zero(famdat->prob[pos], famdat->nscores);
  tablestoprob(famdat->prob[pos]);
}

void Scoredistfull::setuptables(DdNode *S) {
  if (cuddIsConstant(S)) {
    const double s = cuddV(S);
    if (s - .000001 >= maxscore) {
      if (hightable.find(s) == hightable.end())
        hightable.insert(Table::value_type(s, 0.0));
    }
    else if (maxscore > 0) {
      const Uint i = Uint(rint(s));
      lowtable[i] = 1.0;
      if (curmaxscore < i) curmaxscore = i;
    }
  }
  else {
    setuptables(cuddT(S));
    setuptables(cuddE(S));
  }
}

ADD integrateToLevel(ADD x, int from_level, int to_level) {
  DdManager *man = x.manager()->getManager();
  DdNode *xn = x.getNode();
  const int x_level = cuddI(man, xn->index);
  const int size = x.manager()->ReadSize();
  ADD fac = x.manager()->constant(pow(2., min(size, min(to_level, x_level)) -
                                      from_level - 1));
  if (x_level < to_level)
    return fac*
      (integrateToLevel(ADD(x.manager(), cuddT(xn)), x_level, to_level) +
       integrateToLevel(ADD(x.manager(), cuddE(xn)), x_level, to_level));
  else
    return fac*x;
}

typedef map<DdNode *, ADD> LevelProb;
void addToProb(LevelProb &lp, DdManager *man, DdNode *S, ADD p,
               int from_level) {
  LevelProb::iterator lpi = lp.find(S);
  ADD pi = integrateToLevel(p, from_level, cuddI(man, S->index));
  if (lpi == lp.end())
    lp[S] = pi;
  else
    lpi->second += pi;
}

void Scoredistfull::updatetables(ADD pv_in, double sum_pv) {
  SW_START("Scoredistfull::updatetables");
  DdManager *man = pv_in.manager()->getManager();
  assertinternal(man->size < int(MAXBITS));

  for (Uint a = 0; a < (1U << curfamily()->nasymmetricfoundercouples()); a++) {
    LevelProb levels[man->size];
    LevelProb const_level;

    DdNode *S = calcscore->S[a].getNode();
    assertinternal(!cuddIsConstant(S));
    ADD pv = pv_in.manager()->constant(
      pow(2., min(cuddI(man, S->index),
                  cuddI(man, pv_in.getNode()->index))))*pv_in;

    while (cuddI(man, S->index) > cuddI(man, pv.getNode()->index)) {
      DdNode *pn = pv.getNode();
      assertinternal(!cuddIsConstant(pn));
      const int last_level = cuddI(man, pn->index);
      assert(!Cudd_IsConstant(pn));
      pv = ADD(pv.manager(), cuddT(pn)) + ADD(pv.manager(), cuddE(pn));
      const int new_level = min(cuddI(man, S->index),
                                min(Cudd_ReadSize(man),
                                    cuddI(man, pv.getNode()->index)));
      if (new_level - last_level > 1)
        pv *= pv.manager()->constant(pow(2., new_level - last_level - 1));
    }

    levels[cuddI(man, S->index)][S] = pv;

    for (int l = 0; l < man->size; l++)
      for (LevelProb::iterator li = levels[l].begin();
           li != levels[l].end(); li++) {
        DdNode *Sn = li->first;
        DdNode *pn = li->second.getNode();

        const int S_level = cuddI(man, Sn->index);

        assert(S_level <= cuddI(man, pn->index));
        ADD p_T, p_E;
        if (Sn->index == pn->index) {
          p_T = ADD(pv.manager(), cuddT(pn));
          p_E = ADD(pv.manager(), cuddE(pn));
        } else
          p_T = p_E = li->second;

        DdNode *Sn_T = cuddT(Sn);
        if (Cudd_IsConstant(Sn_T))
          addToProb(const_level, man, Sn_T, p_T, S_level);
        else
          addToProb(levels[cuddI(man, Sn_T->index)], man, Sn_T, p_T, S_level);

        DdNode *Sn_E = cuddE(Sn);
        if (Cudd_IsConstant(Sn_E))
          addToProb(const_level, man, Sn_E, p_E, S_level);
        else
          addToProb(levels[cuddI(man, Sn_E->index)], man, Sn_E, p_E, S_level);
      }

    for (LevelProb::iterator li = const_level.begin();
         li != const_level.end(); li++) {
      const double Sv = cuddV(li->first);
      const double prob = cuddV(li->second.getNode());

      if (Sv - .000001 >= maxscore)
        hightable[Sv] += prob;
      else if (maxscore > 0) {
        const Uint i = Uint(rint(Sv));
        lowtable[i] += prob;
      }
    }
  }

  const double inv_sum_pv =
    1./sum_pv/double(1U << curfamily()->nasymmetricfoundercouples());
  if (lowtable != 0)
    for (unsigned int sc = 0; sc <= curmaxscore; sc++)
      lowtable[sc] *= inv_sum_pv;
  for (Table::iterator sc = hightable.begin(); sc != hightable.end(); sc++)
    sc->second *= inv_sum_pv;

  SW_STOP("Scoredistfull::updatetables");
  assertinternal(!hightable.empty() ||
                 fabs(sum<double>(lowtable, curmaxscore + 1) - 1.) < .1);
}
