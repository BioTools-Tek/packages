#include <stdio.h>
#include "fmtout.h"

const string Floattostring(Float x, Uint prec) {
  char buf[100];
  char fmt[100] = "";
  strcat(fmt, "%.");
  sprintf(buf, "%ul", (unsigned int)(prec));
  strcat(fmt, buf);
  strcat(fmt, "f");
  sprintf(buf, fmt, x);
  return string(buf);
}
