#include "calcassoc.h"
#include "control.h"
#include "files.h"
#include "map.h"
#include "vecutil.h"
#include "fmtout.h"

///////////////////////////////////////////////////////////////////////////
// Calcassoc
Calcassoc::Calcassoc(bool estfrq) : Calc("assocweight"), estimatefreq(estfrq) {}

Calcassoc::~Calcassoc() {
  deletepi();
}

void Calcassoc::deletepi() {
  while (pi.size() > 0) {
    delete [] pi.back();
    pi.pop_back();
  }
}

void Calcassoc::set_up(Family *first, IV /*maxnumiv*/) {
  cerr << "calcassoc::set_up() began" << cout;

  if (estimatefreq) {
    deletepi();
    pi.resize(control->map.loci.size(), 0);
  }

  affA.resize(control->map.loci.size(), 0);
  affn.resize(control->map.loci.size(), 0);
  contA.resize(control->map.loci.size(), 0);
  contn.resize(control->map.loci.size(), 0);
  for (Uint gam = 0; gam < control->map.loci.size(); gam++) {
    String2Double pns;
    affA[gam] = new Uint[control->map.loci[gam].numallele];
    zero(affA[gam], control->map.loci[gam].numallele);
    contA[gam] = new Uint[control->map.loci[gam].numallele];
    zero(contA[gam], control->map.loci[gam].numallele);
    for (Family *fam = first; fam != 0; fam = fam->next) {
      assertinternal(fam->numbits < options->mtbddthreshold);
      for (Person *p = fam->first; p != 0; p = p->next)
        if (p->genotyped(gam)) {
          Double w = assign(p, gam);
          if (w > 0) {
            affA[gam][p->gen[0][gam] - 1]++;
            affA[gam][p->gen[1][gam] - 1]++;
            affn[gam]++;
          }
          else if (w < 0) {
            contA[gam][p->gen[0][gam] - 1]++;
            contA[gam][p->gen[1][gam] - 1]++;
            contn[gam]++;
          }
        }
    }
    if (estimatefreq) {
      pi[gam] = new Float[control->map.loci[gam].numallele];
      zero(pi[gam], control->map.loci[gam].numallele);
      if (affn[gam] + contn[gam] > 0)
        for (Uint a = 0; a < control->map.loci[gam].numallele; a++)
          pi[gam][a] =
            (affA[gam][a] + contA[gam][a])/2.0/(affn[gam] + contn[gam]);
    }
  }
}

FloatVec Calcassoc::getfreq(Uint gam) {
  if (estimatefreq) return pi[gam];
  else return &*control->map.loci[gam].pi[0].begin();
}

//////////////////////////////////////////////////////////////////////////
// Calcassocsimple
string Calcassocsimple::describe() const {
  return  Calcassoc::describe() + "waff:" + Floattostring(waff, 2) +
    " wunaff:" + Floattostring(wunaff, 2);
}

///////////////////////////////////////////////////////////////////////////
// Calcassocfile
Calcassocfile::Calcassocfile(bool estfrq, const string &file) :
    Calcassoc(estfrq), filename(file) {
  Infile wtsfile;
  wtsfile.setname(filename);
  wtsfile.optcheck("Association weight file");
  wtsfile.open();
  while (!wtsfile.eof()) {
    string pn;
    Double weight;
    wtsfile >> pn >> weight;
    weights[pn] = weight;
    optassert(wtsfile.good() || wtsfile.eof(),
              "Illegal format of association weight file " + filename);
  }
  wtsfile.close();
}

///////////////////////////////////////////////////////////////////////////
// Calcassocfrac
void Calcassocfrac::set_up(Family *first, IV maxnumiv) {
  cerr << "calcassocFrac::set_up() began" << cout;

  weights.clear();
  weights.resize(control->map.loci.size());
  for (Uint gam = 0; gam < control->map.loci.size(); gam++) {
    for (Family *fam = first; fam != 0; fam = fam->next) {
      assertinternal(fam->numbits <= options->mtbddthreshold);
      for (Person *p = fam->first; p != 0; p = p->next)
        if (p->genotyped(gam))
          if (p->origdstat == AFFECTED) weights[gam][p->id]++;
          else if (p->origdstat == UNAFFECTED) weights[gam][p->id]--;
    }
    Double naff = 0.0;
    Double nunaff = 0.0;
    for (String2Double::const_iterator i = weights[gam].begin();
         i != weights[gam].end(); i++)
      if (i->second < 0) nunaff++;
      else if (i->second > 0) naff++;
    if (naff == 0.0)
      warning("No affecteds genotyped at " + control->map.loci[gam].name +
              " so that fraction of alleles can not be used in association");
    else if (nunaff == 0.0)
      warning("No unaffecteds genotyped at " + control->map.loci[gam].name +
              " so that fraction of alleles can not be used in association");
    for (String2Double::iterator i = weights[gam].begin();
         i != weights[gam].end(); i++)
      if (naff > 0 && nunaff > 0) {
        if (i->second < 0) i->second = 1.0/nunaff/i->second;
        else if (i->second > 0) i->second = 1.0/naff/i->second;
      }
      else i->second = 0.0;
  }
  Calcassoc::set_up(first, maxnumiv);
}
