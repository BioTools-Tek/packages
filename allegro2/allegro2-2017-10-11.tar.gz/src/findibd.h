#ifndef _FINDIBD
#define _FINDIBD
#include "basic.h"
#include "calc.h"
#include "cuddObj.hh"

class IBDperson;

class FindIBD : public Calc {
protected:
  IBDperson *firstibdperson;
  IV numiv;
  bool mtbdd;

  string pairtype;
  typedef pair<int, int> Intpair;
  typedef vector<Intpair> Intpairvector;
  Intpairvector foundercoupleindices;
  IV mask;
  bool isinformative(Person *p);
  FindIBD(const string &pairs);

  vector<pair<string, string> > pairs;

  static void calcsharing(ADD &S1, ADD &S2, Person *p, Person *q, Family *fam,
                          Cudd &mgr);

  void findPosterior(ADD &prob, double sum_prob,
                     vector<int *> &support, unsigned int target,
                     int *cur_supp, vector<double> &results);

public:
  static FindIBD *getFindIBD(const string &pairtype);

  virtual ~FindIBD();

  void findposterior(ADD prob, double sum_prob,
                     DoubleVec results1, DoubleVec results2);

  void findprior(DoubleVec results1, DoubleVec results2);
  void findposterior(FloatVec prob, DoubleVec results1, DoubleVec results2);

  void collectpairs(StringVec person1, StringVec person2) const;
  void priorresult(Person *a, Person *b, Float &p1, Float &p2) const;

  Uint countpairs();

  virtual void operator()(Family *fam);
  virtual void operator()(Family *fam, Cudd &mgr);
};

#endif // _FINDIBD
