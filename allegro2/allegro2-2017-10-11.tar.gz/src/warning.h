#ifndef _WARNING
#define _WARNING
#include "basic.h"
#include <fstream>

string operator+(const string& s, int n);
string operator+(const string& s, Uint n);
string operator+(const string& s, Double a);

void setoptlinenum (int n); // set line number in options file
void message(const string& s);
void warning(const string& s);
void optwarning(const string& s);
void optassert(bool cond, const string &msg);
void fatal(const string& s);

extern ofstream *logfile;

#endif // _WARNING
