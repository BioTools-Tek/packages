#ifndef __CONVOLUTIONSTEP_H
#define __CONVOLUTIONSTEP_H

#include <cuddObj.hh>
#include "cuddutil.h"
#include "options.h"

#include "SW.hh"

struct ConvolutionStepSwapException {
  ConvolutionStep **cs_b;
  ConvolutionStep **cs_e;
  ADD zo;
  double orig_zo_minterms;

  bool must_swap;
  double memory_required;

  ConvolutionStepSwapException(ConvolutionStep **b, ConvolutionStep **e,
                               ADD &z) :
      cs_b(b), cs_e(e), zo(z), orig_zo_minterms(countMinterm(zo)),
      must_swap(false), memory_required(z.manager()->ReadMemoryInUse()) {}
};

struct ConvolutionStepVectorException {
  ConvolutionStep **cs_e;

  ConvolutionStepVectorException(ConvolutionStep **e) :
      cs_e(e) {}
};

class ConvolutionStep {
protected:
  double theta;

public:
  static void indexToLevel(int *perm, int n, ConvolutionStep **cs,
                           ConvolutionStep **cs_end) {
    if (cs != cs_end) {
      Unreduced &red((*cs)->red);
      if (red.type == Unreduced::REGULAR)
        red.begin = n - 1 - perm[red.begin];
      else {
        for (unsigned int i = 0; i < red.flips.size(); i++)
          red.flips[i] = n - 1 - perm[red.flips[i]];
        red.begin = *min_element(red.flips.begin(), red.flips.end());
        if (red.type == Unreduced::FCR) {
          for (unsigned int i = 0; i < red.swaps_src.size(); i++) {
            red.swaps_src[i] = n - 1 - perm[red.swaps_src[i]];
            red.swaps_dest[i] = n - 1 - perm[red.swaps_dest[i]];
          }
          const ReducedIndex src_min =
            *min_element(red.swaps_src.begin(), red.swaps_src.end());
          const ReducedIndex dest_min =
            *min_element(red.swaps_dest.begin(), red.swaps_dest.end());
          red.begin = min(red.begin, min(src_min, dest_min));
        }
      }
      indexToLevel(perm, n, cs + 1, cs_end);
    }
  }

//   static void vectorStep(ADD &res, ADD &zo, ConvolutionStep **cs,
//                          ConvolutionStep **cs_end) {
//     // Move distribution to vector representation and remove ADD
//     // representation from memory
//     const unsigned int numbits = res.manager()->ReadSize();
//     double *f = new double[IV(1) << numbits];
//     assert(Cudd_DebugCheck(res.manager()->getManager()) == 0);
//     addToVector(f, res);
//     Cudd &mgr = *res.manager();
//     const string zo_file(options->swapdirname + "/zo");
//     writeADD(zo_file, zo);
//     indexToLevel(mgr.getManager()->perm, cs, cs_end);
//     zo = res = ADD();
//     Cudd empty;
//     mgr.operator=(empty);

//     // Convolve distribution
//     vectorStep(f, IV(1) << numbits, cs, cs_end);
// //     fft(f, f, IV(1) << numbits, numbits);

// //     IV mask = 0;
// //     vector<IV> frs;
// //     for (ConvolutionStep **c = cs; c != cs_end; c++)
// //       if (c->type == Unreduced::REGULAR)
// //         mask |= c->begin;
// //       else if (c->type == Unreduced::FR) {
// //         IV m = 0;
// //         for (unsigned int i = 0; i < c->flips.size(); i++)
// //           m |= IV(1) << c->flips[i];
// //         frs.push_back(m);
// //       } else {
// //       }

// //     fft(f, f, IV(1) << numbits, numbits);

//     // Move distribution back to ADD representation
//     Cudd m(numbits);
//     mgr = m;
//     res = mgr.addZero();
//   assert(Cudd_DebugCheck(mgr.getManager()) == 0);
//     zo = readADD(zo_file, mgr);
//     remove(zo_file.c_str());
//   assert(Cudd_DebugCheck(mgr.getManager()) == 0);
//     vectorToADD(res, f, zo);
//   assert(Cudd_DebugCheck(mgr.getManager()) == 0);
//     delete [] f;
//   }
  static void vectorStep(double *f, IV numiv, ConvolutionStep **cs,
                         ConvolutionStep **cs_end) {
    if (cs == cs_end) return;
    const Unreduced &red = (*cs)->red;
    const double theta_fac = (*cs)->theta/(1 - (*cs)->theta);
    IV bit;
    if (red.type == Unreduced::REGULAR)
      bit = IV(1) << red.begin;
    else if (!red.flips.empty())
      bit = IV(1) << red.flips.front();
    else
      bit = numiv;
    const IV prev_bit = bit << 1;
    if (red.type == Unreduced::REGULAR) {
      for (IV v = 0; v < numiv; v += prev_bit)
        for (IV w = 0; w < bit; w++) {
          const IV vw0 = v | w;
          const IV vw1 = vw0 | bit;
          const double f0 = f[vw0];
          const double f1 = f[vw1];
          if (f0 != .0) {
            if (f1 != .0) {
              f[vw0] = theta_fac*f1 + f0;
              f[vw1] = theta_fac*f0 + f1;
            } else
              f[vw1] = theta_fac*f0;
          } else if (f1 != .0)
            f[vw0] = theta_fac*f1;
        }
    } else if (red.type == Unreduced::FR) {
      IV mask = 0;
      for (unsigned int i = 0; i < red.flips.size(); i++)
        mask |= IV(1) << red.flips[i];
      for (IV v = 0; v < numiv; v += prev_bit)
        for (IV w = 0; w < bit; w++) {
          const IV vw0 = v | w;
          const IV vw1 = vw0 ^ mask;
          const double f0 = f[vw0];
          const double f1 = f[vw1];
          if (f0 != .0) {
            if (f1 != .0) {
              f[vw0] = theta_fac*f1 + f0;
              f[vw1] = theta_fac*f0 + f1;
            } else
              f[vw1] = theta_fac*f0;
          } else if (f1 != .0)
            f[vw0] = theta_fac*f1;
        }
    } else {
      if (bit == numiv) {
        for (IV v = 0; v < numiv; v++) {
          IV w = v;
          for (unsigned int i = 0; i < red.swaps_src.size(); i++) {
            const IV bs = IV(1) << red.swaps_src[i];
            const IV bd = IV(1) << red.swaps_dest[i];

            const bool s = bs & v;
            const bool d = bd & v;
            if (s != d) {
              if (s) {
                w |= bd;
                w &= ~bs;
              } else {
                w &= ~bd;
                w |= bs;
              }
            }
          }
          if (v == w)
            f[v] *= (theta_fac + 1.);
          else if (v < w) {
            const double f0 = f[v];
            const double f1 = f[w];
            if (f0 != .0) {
              if (f1 != .0) {
                f[v] = theta_fac*f1 + f0;
                f[w] = theta_fac*f0 + f1;
              } else
                f[w] = theta_fac*f0;
            } else if (f1 != .0)
              f[v] = theta_fac*f1;
          }
        }
      } else {
        IV mask = 0;
        for (unsigned int i = 0; i < red.flips.size(); i++)
          mask |= IV(1) << red.flips[i];
        for (IV v = 0; v < numiv; v += prev_bit)
          for (IV w = 0; w < bit; w++) {
            const IV vw0 = v | w;
            IV vw1 = vw0 ^ mask;
            for (unsigned int i = 0; i < red.swaps_src.size(); i++) {
              const IV bs = IV(1) << red.swaps_src[i];
              const IV bd = IV(1) << red.swaps_dest[i];

              const bool s = bs & vw0;
              const bool d = bd & vw0;
              if (s != d) {
                if (s) {
                  vw1 |= bd;
                  vw1 &= ~bs;
                } else {
                  vw1 &= ~bd;
                  vw1 |= bs;
                }
              }
            }
            const double f0 = f[vw0];
            const double f1 = f[vw1];
            if (f0 != .0) {
              if (f1 != .0) {
                f[vw0] = theta_fac*f1 + f0;
                f[vw1] = theta_fac*f0 + f1;
              } else
                f[vw1] = theta_fac*f0;
            } else if (f1 != .0)
              f[vw0] = theta_fac*f1;
          }
      }
    }
    vectorStep(f, numiv, cs + 1, cs_end);
  }

  static bool allow_swap;
  Unreduced red;

  ConvolutionStep(double th, const Unreduced &r) : theta(th), red(r) {
    assertinternal(th > .0);
  }
  virtual ~ConvolutionStep() {cleanUp();}

  virtual ADD updateZO(ADD &zo) {return red.expandZO(zo);}
  virtual void updateViterbi(ADD &/*res*/, ADD /*zo*/) {assert(false);}
  virtual void updateRes(ADD &/*res*/, ADD /*zo*/) {assert(false);}
//   virtual void inPlaceUpdateRes(ADD &/*res*/, ADD /*zo*/) {assert(false);}

  static void step(ADD &res, ADD &zo, ConvolutionStep **cs,
                   ConvolutionStep **cs_end, unsigned int &last_reorder_size,
                   bool viterbi) {
    if (cs == cs_end) return;
    Cudd &mgr = *res.manager();

    ADD new_zo = (*cs)->updateZO(zo);
    try {
      step(res, new_zo, cs + 1, cs_end, last_reorder_size, viterbi);
    } catch (ConvolutionStepSwapException ce) {
      if (!ce.must_swap) {
        ce.memory_required *= 1.75*countMinterm(zo)/countMinterm(ce.zo);
        if (5*ce.memory_required >= 3*options->maxmem)
          ce.must_swap = true;
      }
      if (ce.must_swap) {
        if (ce.cs_b == cs + 1 && 16*countMinterm(zo) > ce.orig_zo_minterms) {
          ce.cs_b--;
          ce.zo = zo;
        }
        (*cs)->cleanUp();
        new_zo = ADD();
        throw ce;
      }
    } catch (ConvolutionStepVectorException ce) {
      (*cs)->cleanUp();
      new_zo = ADD();
      throw ce;
    }

    if (2*mgr.ReadMemoryInUse() > options->maxmem && allow_swap) {
      ConvolutionStepSwapException ce(cs, cs + 1, new_zo);
      new_zo = ADD();
      ce.must_swap = true;
      throw ce;
    } else if (mgr.ReadKeys() - mgr.ReadDead() >
               options->mtbdddynamicthreshold*(IV(1) << mgr.ReadSize())) {
      if (21*(((IV(1) << (mgr.ReadSize() + 3))) >> 20) < 10*options->maxmem &&
          !viterbi) {
        (*cs)->cleanUp();
        new_zo = ADD();
        throw ConvolutionStepVectorException(cs + 1);
      } // else if (mgr.ReadKeys() - mgr.ReadDead() >
//         warning("will likely run out of memory!");
    }
    new_zo = ADD();

    if (viterbi) {
      SW_START("ConvolutionStep::updateViterbi");
      (*cs)->updateViterbi(res, zo);
      SW_STOP("ConvolutionStep::updateViterbi");
    } else {
      SW_START("ConvolutionStep::updateRes");
//       (*cs)->inPlaceUpdateRes(res, zo);
     (*cs)->updateRes(res, zo);
      SW_STOP("ConvolutionStep::updateRes");
    }


//     cout << cs_end - cs << "\t" << res.nodeCount() << "\t"
//          << zo.CountMinterm(39) << endl;


    SW_START("ConvolutionStep::reorder");
    if (((cs_end - cs) % 2) == 0)
      mgr.SetRoundingPrec(mgr.ReadRoundingPrec() - 1);
//     if (mgr.ReadRoundingPrec() > int(options->mtbddmaxrounding) + 13)
//       mgr.SetRoundingPrec(mgr.ReadRoundingPrec() - 1);
    const unsigned int old_size = mgr.ReadKeys() - mgr.ReadDead();

    if (4*last_reorder_size < old_size ||
        ((10*mgr.ReadMemoryInUse() > 3*options->maxmem) &&
        (2*last_reorder_size < old_size)) ||
        10*mgr.ReadMemoryInUse() > 7*options->maxmem) {
//       int rounding_incr = 5*mgr.ReadMemoryInUse() > options->maxmem ? 7 : 1;
//       do {
//         const int rounding_max = options->mtbddmaxrounding +
//           (5*mgr.ReadMemoryInUse() > 3*options->maxmem && !allow_swap ?
//            0 : 10);
//         mgr.SetRoundingPrec(max(rounding_max,
//                                 mgr.ReadRoundingPrec() - rounding_incr));
//         if (mgr.ReadRoundingPrec() != rounding_max && mgr.ReadSize() > 20 &&
//             5*mgr.ReadMemoryInUse() < 3*options->maxmem) {
//           reRound(res, mgr.ReadSize()/3);
//         }
        reorderManager(mgr, cs_end - cs, old_size, last_reorder_size);
//         if (mgr.ReadRoundingPrec() == rounding_max) break;
//         rounding_incr = 10;
//       } while (5*mgr.ReadMemoryInUse() > 3*options->maxmem && !allow_swap &&
//                mgr.ReadRoundingPrec() > int(options->mtbddmaxrounding));
    }
    SW_STOP("ConvolutionStep::reorder");

    (*cs)->cleanUp();

    if (8*mgr.ReadMemoryInUse() > 3*options->maxmem && allow_swap)
      throw ConvolutionStepSwapException(cs, cs, zo);
  }

  virtual void cleanUp() {}

  static void reorderManager(Cudd &mgr, Uint numdone, unsigned int old_size,
                             unsigned int &last_reorder_size) {
    mgr.SetMaxGrowth(1.0001);

    mgr.ReduceHeap(CUDD_REORDER_SIFT, 0);
    const unsigned int size = mgr.ReadKeys() - mgr.ReadDead();
#ifdef DEBUG_OUTPUT
    cerr << "Reordering\t" << last_reorder_size << "\t" << old_size
         << "\t" << size << "\t" << numdone << endl;
#endif // DEBUG_OUTPUT
    last_reorder_size = size;
  }

};

class ConvolutionStepRegular : public ConvolutionStep {
private:
  unsigned int index;
  ADD zo_0, zo_1;

public:
  ConvolutionStepRegular(double th, unsigned int idx) :
      ConvolutionStep(th, Unreduced(idx)), index(idx) {}
  virtual ~ConvolutionStepRegular() {}
  virtual void cleanUp() {zo_0 = zo_1 = ADD();}

  virtual ADD updateZO(ADD &zo) {
    ADD bit(zo.manager()->addVar(index));
    zo_0 = zo.Cofactor(~bit);
    zo_1 = zo.Cofactor(bit);
    return zo_0 | zo_1;
  }
  virtual void updateRes(ADD &res, ADD /*zo*/) {
    ADD bit(res.manager()->addVar(index));
    ADD on(singleCofactor(res, index, true));
    ADD off(singleCofactor(res, index, false));
//     ADD on(res.Cofactor(bit));
//     ADD off(res.Cofactor(~bit));
    res = res.manager()->addZero(); // allow freeing of memory
    ADD theta_acc = res.manager()->constant(theta/(1. - theta));

    ADD res_1 = zo_1*on + theta_acc*zo_1*off;
    zo_1 = ADD();
    ADD tmp = zo_0*off;
    off = ADD();
    ADD tmp2 = zo_0*on;
    zo_0 = on = ADD();
    tmp2 *= theta_acc;
    ADD res_0 = tmp + tmp2;
    tmp = tmp2 = ADD();

    res = bit.Ite(res_1, res_0);
  }
//   virtual void inPlaceUpdateRes(ADD &res, ADD /*zo*/) {
//     DdManager *man = res.manager()->getManager();

//     const int depth = Cudd_ReadSize(man)/3;
//     if (Cudd_ReadSize(man) < 25 ||
//         5*Cudd_ReadMemoryInUse(man)/(1 << 20) < options->maxmem) {
//       updateRes(res, res.manager()->addZero());
//       return;
//     }

//     if (cuddI(man, index) < depth) {
//       int *invperm = new int[Cudd_ReadSize(man)];
//       memcpy(invperm, man->invperm, Cudd_ReadSize(man)*sizeof(int));
//       for (int i = cuddI(man, index); i < depth; i++)
//         invperm[i] = invperm[i + 1];
//       invperm[depth] = index;
//       Cudd_ShuffleHeap(man, invperm);
//       delete [] invperm;
//     }

//     ADD bit(res.manager()->addVar(index));
//     ADD on = singleCofactor(res, index, true);
//     ADD off = singleCofactor(res, index, false);
//     res = res.manager()->addZero(); // allow freeing of memory
//     ADD theta_acc = res.manager()->constant(theta/(1. - theta));

//     vector<unsigned int> path(depth, 2);
//     vector<DdNode *> on_v(1 << depth, (DdNode *)(0));
//     vector<DdNode *> off_v(1 << depth, (DdNode *)(0));
//     vector<DdNode *> zo_0_v(1 << depth, (DdNode *)(0));
//     vector<DdNode *> zo_1_v(1 << depth, (DdNode *)(0));

//     buildV(on_v, path, on.getNode(), man);
//     buildV(off_v, path, off.getNode(), man);
//     buildV(zo_0_v, path, zo_0.getNode(), man);
//     buildV(zo_1_v, path, zo_1.getNode(), man);

//     map<pair<pair<DdNode *, DdNode *>, pair<DdNode *, DdNode *> >, DdNode *>
//       conv;

//     for (unsigned int i = 0; i < on_v.size(); i++) {
//       pair<pair<DdNode *, DdNode *>, pair<DdNode *, DdNode *> >
//         key(make_pair(on_v[i], off_v[i]), make_pair(zo_1_v[i], zo_0_v[i]));
//       if (conv.find(key) == conv.end()) {
//         conv[key] = 0;
//         cuddRef(on_v[i]);
//         cuddRef(off_v[i]);
//         cuddRef(zo_0_v[i]);
//         cuddRef(zo_1_v[i]);
//       }
//     }

//     on = off = zo_0 = zo_1 = ADD();

//     for (map<pair<pair<DdNode *, DdNode *>,
//            pair<DdNode *, DdNode *> >, DdNode*>::iterator ci = conv.begin();
//          ci != conv.end(); ci++) {
//       DdNode *on_i = ci->first.first.first;
//       DdNode *off_i = ci->first.first.second;
//       DdNode *zo_1_i = ci->first.second.first;
//       DdNode *zo_0_i = ci->first.second.second;
//       // ADD res_1 = zo_1*on + theta_acc*zo_1*off
//       DdNode *t_on1 = Cudd_addApply(man, Cudd_addTimes, on_i, zo_1_i);
//       cuddRef(t_on1);
//       DdNode *t_off1 = Cudd_addApply(man, Cudd_addTimes, off_i, zo_1_i);
//       cuddRef(t_off1);
//       Cudd_RecursiveDeref(man, zo_1_i);
//       DdNode *t_thoff1 = Cudd_addApply(man, Cudd_addTimes, theta_acc.getNode(),
//                                        t_off1);
//       cuddRef(t_thoff1);
//       Cudd_RecursiveDeref(man, t_off1);

//       DdNode *r1 = Cudd_addApply(man, Cudd_addPlus, t_on1, t_thoff1);
//       cuddRef(r1);
//       Cudd_RecursiveDeref(man, t_on1);
//       Cudd_RecursiveDeref(man, t_thoff1);

//       // zo_0*off + theta_acc*zo_0*on
//       DdNode *t_on0 = Cudd_addApply(man, Cudd_addTimes, on_i, zo_0_i);
//       cuddRef(t_on0);
//       Cudd_RecursiveDeref(man, on_i);
//       DdNode *t_off0 = Cudd_addApply(man, Cudd_addTimes, off_i, zo_0_i);
//       cuddRef(t_off0);
//       Cudd_RecursiveDeref(man, off_i);
//       Cudd_RecursiveDeref(man, zo_0_i);
//       DdNode *t_thon0 = Cudd_addApply(man, Cudd_addTimes, theta_acc.getNode(),
//                                       t_on0);
//       cuddRef(t_thon0);
//       Cudd_RecursiveDeref(man, t_on0);

//       DdNode *r0 = Cudd_addApply(man, Cudd_addPlus, t_thon0, t_off0);
//       cuddRef(r0);
//       Cudd_RecursiveDeref(man, t_thon0);
//       Cudd_RecursiveDeref(man, t_off0);

//       // bit.Ite(res_1, res_0);
//       ci->second = Cudd_addIte(man, bit.getNode(), r1, r0);
//       cuddRef(ci->second);
//       Cudd_RecursiveDeref(man, r0);
//       Cudd_RecursiveDeref(man, r1);
//     }

//     theta_acc = ADD();

//     vector<DdNode *> r_v(1 << depth, (DdNode *)(0));
//     for (unsigned int i = 0; i < r_v.size(); i++)
//       r_v[i] = conv[make_pair(make_pair(on_v[i], off_v[i]),
//                               make_pair(zo_1_v[i], zo_0_v[i]))];

//     res = ADD(res.manager(), buildRes(r_v, 0, 0, man));

//     for (map<pair<pair<DdNode *, DdNode *>,
//            pair<DdNode *, DdNode *> >, DdNode *>::iterator ci = conv.begin();
//          ci != conv.end(); ci++)
//       cuddDeref(ci->second);
//   }

  virtual void updateViterbi(ADD &res, ADD /*zo*/) {
    ADD bit(res.manager()->addVar(index));
    ADD on(singleCofactor(res, index, true));
    ADD off(singleCofactor(res, index, false));
//     ADD on(res.Cofactor(bit));
//     ADD off(res.Cofactor(~bit));
    res = res.manager()->addZero(); // allow freeing of memory
    ADD theta_acc = res.manager()->constant(theta/(1. - theta));

    ADD res_1 = (zo_1*on).Maximum(theta_acc*zo_1*off);
    zo_1 = ADD();
    ADD tmp = zo_0*off;
    off = ADD();
    ADD tmp2 = zo_0*on;
    zo_0 = on = ADD();
    tmp2 *= theta_acc;
    ADD res_0 = tmp.Maximum(tmp2);
    tmp = tmp2 = ADD();

    res = bit.Ite(res_1, res_0);
  }
};

class ConvolutionStepRedux : public ConvolutionStep {
public:
  ConvolutionStepRedux(double th, const Unreduced &r) :
      ConvolutionStep(th, r) {}
  virtual ~ConvolutionStepRedux() {}

  virtual void updateRes(ADD &res, ADD zo) {
    ADD transformed = red.transform(res);

    ADD theta_acc = res.manager()->constant(theta/(1. - theta));

    ADD tmp = zo*res;
    res = ADD();
    ADD tmp2 = zo*transformed;
    transformed = ADD();
    tmp2 *= theta_acc;
    res = tmp + tmp2;
  }
//   virtual void inPlaceUpdateRes(ADD &res, ADD zo) {
//     ADD transformed = red.transform(res);

//     ADD theta_acc = res.manager()->constant(theta/(1. - theta));

//     ADD tmp = zo*res;
//     res = ADD();
//     ADD tmp2 = zo*transformed;
//     transformed = ADD();
//     tmp2 *= theta_acc;
//     res = tmp + tmp2;
//   }
  virtual void updateViterbi(ADD &res, ADD zo) {
    ADD transformed = red.transform(res);

    ADD theta_acc = res.manager()->constant(theta/(1. - theta));

    ADD tmp = zo*res;
    res = ADD();
    ADD tmp2 = zo*transformed;
    transformed = ADD();
    tmp2 *= theta_acc;
    res = tmp.Maximum(tmp2);
  }
};

#endif // __CONVOLUTIONSTEP_H
