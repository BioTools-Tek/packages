#include "files.h"
#include "model.h"
#include "distribution.h"

Model::Modelvector Model::models;

void Model::modeloutput() {
  for (Uint model = 0; model < models.size(); model++)
    if (models[model]->nfam() > 0) 
      models[model]->output();
}

void Model::printmodels() {
  for (Uint model = 0; model < models.size(); model++)
    models[model]->print();
}

const string &Model::getfamid(Uint ifa) const {
  return distribution->getfamid(ifa);
}

Uint Model::nfam() const {
  return distribution->nfam();
}
