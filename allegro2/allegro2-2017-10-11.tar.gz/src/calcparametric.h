#ifndef _CALCPARAMETRIC
#define _CALCPARAMETRIC
#include "calclinkage.h"
#include "trait.h"
#include "mtbddpeel.h"

class Foundercouple;

class Calcparametric : public Calclinkage {
protected:
  // The likelihood of every inheritance vector is stored in vec
  Trait *trait;

  void calclod(Family *fam, Foundercouple *fc);
  void calclod(Family *fam, Foundercouple *fc, Cudd &mgr);
  Calcparametric(Trait *tr) :
      Calclinkage("par"), trait(tr) {}

  virtual void clean_up() {
    mtbdd_peeler.clear();
  }

  static string description(Trait *tr)
    {return string("par") + (tr == 0 ? "" : " " + tr->describe());}

  vector<PPeeler> mtbdd_peeler;
public:
  virtual bool getsexlinked() const
    {return trait == 0 ? false : trait->getsexlinked();}
//    string getfreq() const {return trait == 0 ? "default" : trait->getfreq();}
//    string getpenetrances() const
//      {return trait == 0 ? "default" : trait->getpenetrances();}
  Trait *gettrait() {return trait;}
  static Calcparametric *getcalcparametric(Trait *tr);
  virtual void operator() (Family *fam);
  virtual void operator() (Family *fam, Cudd &mgr);
  void settrait(Trait *tr) {assertinternal(trait == 0); trait = tr;}
  virtual string describe() const {return description(trait);}

  virtual Double sumLp(ADD &pv, Double sum_pv);

  virtual bool use(Family *fam, bool mtbdd) const {
    if (mtbdd) return !mtbdd_peeler.empty();
    else return Calclinkage::use(fam, false);
  }
};

#endif // _CALCPARAMETRIC
