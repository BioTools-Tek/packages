#ifndef _SPGRAPH
#define _SPGRAPH 1

#include "basic.h"

#include "cuddObj.hh"

class Node;
class Graph;
class Family;
class Plist;

class SPGraph {
private:
  Family *fam;
  Cudd &mgr;

  ADD homozygous_1unknown(Node *n0, Node *n1, Allele a, Plist* pl, int gam);
  ADD heterozygous_1unknown(Node *n0, Node *n1, Allele b0, Allele b1,
                            Plist* pl, int gam);
  ADD heterozygous_1block(Node *n0, Node *n1, Allele b0, Allele b1,
                          Plist* pl, Uint gam);
  ADD heterozygous_2blocks(Node *n0, Node *n1, Allele b0, Allele b1,
                           Plist* pl, int gam);

  ADD findq(Plist* pl, int gam);

public:
  Graph *graph;

  SPGraph(Family *fam, Cudd &m);
  ~SPGraph();

  double fromhere(Uint gam, const Doublevector &freq, ADD &sp);

};

#endif // _SPGRAPH
