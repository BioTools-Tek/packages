#include <fstream>
#include "matrix.h"
#include "probability.h"
#include "files.h"
#include "options.h"
#include "map.h"
#include "vecutil.h"
#include "family.h"
#include "control.h"

Graph *Probability::graph = 0;

Probability::Probability(Floatmatrix *qp, Floatmatrix *lqp,
                         Floatmatrix *lqhatp, FloatVec rqhatp,
                         Family *f, Map *mp) {
  fam = f;
  numbits = fam->numbits;
  numiv = fam->numiv();
  map = mp;
  q = qp;
  lq = lqp;
  lqhat = lqhatp;
  rqhat = rqhatp;
  q->probability = this;
  q->nextfam(map->loci.size()*fam->numiv(), fam->numiv());
  if (lqhat != 0) {
    assertinternal(lq != 0 && rqhat != 0);
      lqhat->nextfam(map->loci.size()*fam->numiv(), fam->numiv());
      lq->nextfam(map->loci.size()*fam->numiv(), fam->numiv());
      lq->probability = this;
  }
  wtstar = 0;
  wtstar_female = 0;
  graph = 0;
  createweight();
  createfoundergraph();

  l_nc = new Float[map->loci.size()];
  copyval(l_nc, 1.0, map->loci.size());
}

Probability::~Probability() {
  delete [] l_nc;
}

void Probability::createweight() {
  wtstar = new unsigned char[numiv];
  if (options->sexspecific) {
    wtstar_female = new unsigned char[numiv];
    IV malemask = 0;
    IV femalemask = 0;
    for (Person *p = fam->firstdescendant; p != 0; p = p->next) {
      IV mask = 0;
      for (Plist *c = p->children; c != 0; c = c->next)
        mask |= (p->sex == MALE ? c->p->patmask : c->p->matmask);
      if (p->sex == MALE) malemask |= mask;
      else femalemask |= mask;
    }
    for (IV v = 0; v < numiv; v++) {
      wtstar[v] = POPCOUNT(v & malemask);
      wtstar_female[v] = POPCOUNT(v & femalemask);
    }
    for (Person *p = fam->first; p != fam->firstdescendant; p = p->next)
      if (p->mask != 0) {
        unsigned char *wts = (p->sex == MALE ? wtstar : wtstar_female);
        for (IV v = 0; v < numiv; v++) {
          const unsigned char weight = POPCOUNT(v & p->mask);
          wts[v] += (weight & 1) ? weight + 1 : weight;
        }
      }
  }
  else {
    for (IV v = 0; v < numiv; v++)
      wtstar[v] = POPCOUNT(v & fam->mask);
    for (Person *p = fam->first; p != fam->firstdescendant; p = p->next)
      if (p->mask != 0) {
        for (IV v = 0; v < numiv; v++) {
          const unsigned char weight = POPCOUNT(v & p->mask);
          wtstar[v] += (weight & 1) ? weight + 1 : weight;
        }
      }
    for (Foundercouple *fc = fam->firstfoundercouple; fc != 0; fc = fc->next)
      if (fc->mask != 0)
        for (IV v = 0; v < numiv; v++)
          wtstar[v] += POPCOUNT(v & fc->mask);
  }
}

Float Probability::fromhere(FamilyMap *fm, Uint gam, FloatVec q) {
  const Float nc = fromhere(gam, q,
                            &*map->loci[gam].pi[fam->populationindex].begin(),
                            fam);
  if (fm != 0)
    fm->setinformative(gam, checkq(gam));
  return nc;
}
