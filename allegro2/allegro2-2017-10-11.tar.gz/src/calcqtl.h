#ifndef _CALCQTL
#define _CALCQTL
#include "basic.h"
#include "calc.h"
#include "calcscore.h"
#include "findnormal.h"

class CalcQTL : public Calcscore {
protected:
  const string trait;
  Double sigma2;
  Double shared;
  Double sigma2_g;
  Double sigma2_d;
  FindNormalLoglik loglik;

  CalcQTL(const string &cid, Double s2, Double s, Double g, Double d,
          const string &tr);
  static string description(const string &cid, Double /*s2*/, Double s,
                            Double g, Double d, const string &tr)
    {return cid + " vc_" + Floattostring(s, 6) + "/" + Floattostring(g, 6) +
       "/" + Floattostring(d, 6) + (tr == "" ? "" : " trait:" + tr);}
  void setupscorefamily(Family */*fam*/) {}
  virtual void calc(DoubleVec , Family */*fam*/) {}
  virtual ADD calc(Family */*fam*/, Cudd &mgr) {return mgr.addOne();}
public:
  static CalcQTL *getcalcQTL(const string &cid, Double s2, Double s,
                             Double g, Double d, const string &tr);
  virtual void operator() (Family *fam);
  virtual void operator() (Family */*fam*/, Cudd &/*mgr*/)
    {assertinternal(false);}
  virtual bool isdiscrete() const {return false;}
};

#endif // _CALCQTL
