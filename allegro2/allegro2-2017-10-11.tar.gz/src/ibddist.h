#ifndef _IBDDIST
#define _IBDDIST
#include "distribution.h"
#include "findibd.h"

class IBDdist : public Distribution {
public:
  virtual string describe() const {return "IBD" + pairtype;}
  static IBDdist *getibddist(const string &pt, const string &type);

  Uint countpairs(Uint ifa) {return familydata[ifa]->npairs;}
  void getpairs(Uint ifa, StringVec &p1, StringVec &p2)
    {p1 = familydata[ifa]->person1; p2 = familydata[ifa]->person2;}
  void getprioribd(Uint ifa, DoubleVec &i1, DoubleVec &i2)
    {i1 = familydata[ifa]->prioribd1; i2 = familydata[ifa]->prioribd2;}
  void getposterioribd(Uint ifa, DoubleVec &i1, DoubleVec &i2, Uint pos)
    {i1 = familydata[ifa]->posterioribd1[pos];
    i2 = familydata[ifa]->posterioribd2[pos];}

  virtual bool usefamily(Family *, bool) const {return true;}
protected:

  class Familydata {
  public:
    void initialize(Uint np, Uint npos) {
      npairs = np;
      if (npairs > 0) {
        person1 = new string[npairs];
        person2 = new string[npairs];
        prioribd1 = new Double[npairs];
        prioribd2 = new Double[npairs];
        posterioribd1 = newmatrix<Double>(npos, npairs);
        posterioribd2 = newmatrix<Double>(npos, npairs);
      }
      else {
        person1 = person2 = 0;
        prioribd1 = prioribd2 = 0;
        posterioribd1 = posterioribd2 = 0;
      }
    }

    Familydata() : npairs(0), person1(0), person2(0), prioribd1(0),
                   prioribd2(0), posterioribd1(0), posterioribd2(0) {}
    Familydata(const Familydata &/*fd*/) {assertinternal(false);}

    ~Familydata();
    Uint npairs;
    StringVec person1;
    StringVec person2;
    DoubleVec prioribd1;
    DoubleVec prioribd2;
    DoubleMat posterioribd1;
    DoubleMat posterioribd2;
  };
  friend class IBDdist::Familydata;
  typedef vector<Familydata *> Familydatavector;
  Familydatavector familydata;
  FindIBD *findIBD;

  IBDdist(const string &p, const string &type);

  string pairtype;
  Outfile priorpairwiseibd;
  Outfile posteriorpairwiseibd;

  virtual void reset(Uint np);
  virtual void nextfam(bool mtbdd, Uint pos = 0, DoubleVec p0 = 0);
  virtual void set(FloatVec pv, Uint pos);
  virtual void set(ADD &pv, double sum_pv, Uint pos);
  virtual void skipfam();

  virtual void getuninteresting(::set<Unreduced> &uninteresting);

};

#endif // _IBDDIST
