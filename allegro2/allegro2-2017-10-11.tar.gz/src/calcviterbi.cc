#include "calcviterbi.h"
#include "control.h"
#include "options.h"
#include <cstddef>

vector<IVVec> Calcviterbi::buffers;
vector<Uint> Calcviterbi::buffersize;

Calcviterbi *Calcviterbi::getcalcviterbi(const string &s) {
  Calc *clc = findcalc(s);
  if (clc == 0) clc = new Calcviterbi(s);
  return (Calcviterbi *)clc;
}

void Calcviterbi::set_up(Family */*first*/, IV maxnumiv) {
  cerr << "Ants are fast. Are we 32-bit?" << sizeof(std::size_t) << endl;
  cerr << "calcviterbi::set_up() began\n" << cout;

  cerr << "calcviterbi::set_up() psibufborrowed=" << psibufborrowed << "\n" << cout;
  if (!psibufborrowed) delete [] psibuf;
  delete psi;
  cerr << "calcviterbi::set_up() psi deleted" << "\n" << cout;

  cerr << "calcviterbi::set_up() options_swap?" << options->swap << "\n" << cout;
  cerr << "calcviterbi::set_up() map.loci.size=" << control->map.loci.size() << ", maxnumiv=" << maxnumiv << "\n" << cout;

  Uint n = Uint(options->swap ? Double(maxnumiv) :
                (Double(control->map.loci.size())*Double(maxnumiv)));

  cerr << "calcviterbi::set_up() n value=" << n << "\n" << cout;

  if (n == 0) n = 1;
  psibuf = getbuf(n);
  cerr << "calcviterbi::set_up() getbuf(" << n << ")\n" << cout;

  cerr << "calcviterbi::set_up() psibuf=" << psibuf << "\n" << cout;
  psibufborrowed = psibuf != 0;
  cerr << "calcviterbi::set_up() psibufborrowed=" << psibufborrowed << "\n" << cout;

  if (!psibufborrowed){
      //PROBLEMS OCCUR HERE
      cerr << "calcviterbi::set_up() new IV \n" << cout;
      cerr << "size of IV:" << sizeof(IV) <<  endl;
      cerr << "total requested: ("
//           << (sizeof(IV)*n) << "bytes) = ("
//           << (sizeof(IV)*n)/1024 << "KB) = ("
//           << (sizeof(IV)*n)/(1024*1024) << "MB) = ("
           << (sizeof(IV)*n)/(1024*1024*1024) << "GB)" << endl;

      psibuf = new IV[n];
      cerr << "calcviterbi::set_up() got new IV \n" << cout;
  }

  cerr << "calcviterbi::set_up() new IVMatrix \n" << cout;
  psi = new IVmatrix(psibuf, n, options->swapdirname, "psi." + id + ".");
  cerr << "calcviterbi::set_up() got new IVMatrix \n" << cout;

}

void Calcviterbi::registerbuf(IVVec buf, Uint n) {
  buffers.push_back(buf);
  buffersize.push_back(n);
}

void Calcviterbi::resetbufs() {
  buffers.clear();
  buffersize.clear();
}

IVVec Calcviterbi::getbuf(Uint n) {
  assertinternal(buffers.size() == buffersize.size());
  Uint i = 0;
  while (i < buffersize.size() && buffersize[i] < n)
    i++;
  if (i < buffers.size()) {
    buffersize[i] = 0;
    return buffers[i];
  }
  else return 0;
}
