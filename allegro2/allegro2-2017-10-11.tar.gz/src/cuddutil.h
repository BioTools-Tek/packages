#ifndef _CUDDUTIL
#define _CUDDUTIL

#include "basic.h"
#include "cuddInt.h"
#include "cuddObj.hh"
#include "vecutil.h"
#include "ZUtils.hh"
#include "CacheManager.hh"

#include <map>

inline bool isbitinformative(unsigned int level, DdNode *p) {
  if (p->index > level)
    return false;
  else if (p->index == level)
    return cuddT(p) != cuddE(p);
  else
    return(isbitinformative(level, cuddT(p)) ||
           isbitinformative(level, cuddE(p)));
}

inline ADD uniqueInter(int index, Cudd &mgr, ADD f, ADD g) {
  DdManager *man = mgr.getManager();
  DdNode *fn = f.getNode();
  DdNode *gn = g.getNode();

  return ADD(&mgr, (fn == gn) ? fn : cuddUniqueInter(man, index, fn, gn));
}


inline double cuddMax(DdNode *p) {
  if (Cudd_IsConstant(p)) return Cudd_V(p);
  else {
    const double max_T = cuddMax(Cudd_T(p));
    const double max_E = cuddMax(Cudd_E(p));
    return max_T > max_E ? max_T : max_E;
  }
}

inline double cuddMinNonZero(DdNode *p) {
  if (Cudd_IsConstant(p)) {
    const double val = Cudd_V(p);
    return val;
  }
  else {
    const double min_T = cuddMinNonZero(Cudd_T(p));
    const double min_E = cuddMinNonZero(Cudd_E(p));
    return min_E == 0 || ((min_T > 0 && min_T) < min_E ? min_T : min_E);
  }
}

inline double sum(DdManager *mgr, DdNode *x, CuddCacheN_D &cache) {
  if (cuddIsConstant(x)) return cuddV(x);

  const int x_level = mgr->perm[x->index];
  const bool use_cache = mgr->size > x_level + mgr->size/4;
  if (use_cache) {
    CuddCacheN_D::const_iterator ci = cache.find(x);
    if (ci != cache.end()) return ci->second;
  }

//   DdNode *T = cuddT(x);
//   DdNode *E = cuddE(x);

  const double T_sum = sum(mgr, cuddT(x), cache);
  const double E_sum = sum(mgr, cuddE(x), cache);

  const double res = .5*(T_sum + E_sum);

//   const int T_level = cuddIsConstant(T) ? mgr->size : mgr->perm[T->index];
//   const int E_level = cuddIsConstant(E) ? mgr->size : mgr->perm[E->index];

//   const double res = ((uint64_t(1) << ((T_level - x_level) - 1))*T_sum +
//                       (uint64_t(1) << ((E_level - x_level) - 1))*E_sum);
  if (use_cache) {
    if (cache.size() > (1 << 17)) cache.clear();
    cache[x] = res;
  }
  return res;
}

inline double sum(ADD x, int base_level = -1) {
  DdNode *xn = x.getNode();
  DdManager *man = x.manager()->getManager();

  const int num_levels = base_level == -1 ? man->size : man->size - base_level;

  if (cuddIsConstant(xn))
    return (uint64_t(1) << num_levels)*cuddV(xn);
  else {
    CuddCacheN_D &cache = CuddCacheManager::getCacheN_D("sum", man);

    const double res = (uint64_t(1) << num_levels)*sum(man, xn, cache);

    return res;
  }
}

// inline double sum(const ADDvector &v) {
//   double s = .0;
//   for (int i = 0; i < v.count(); i++)
//     s += sum(v[i]);
//   return s;
// }

// inline double sumprod(const ADDvector &v, ADD p) {
//   double s = .0;
//   for (int i = 0; i < v.count(); i++) {
//     ADD vi = v[i];
//     s += sum(vi*p);
//   }
//   return s;
// }

inline double normal(ADD &x) {
  const double s = sum(x);
  if (s == .0) x = x.manager()->addZero();
  else x *= x.manager()->constant(1./s);
  return s;
}

inline DdNode *addTransferEvil(DdManager *src, DdManager *dest, DdNode *f,
                               st_table *table) {
  // terminal case
  if (Cudd_IsConstant(f)) return cuddUniqueConst(dest, cuddV(f));

  // check cache
  const bool use_cache = src->size > cuddI(src, f->index) + src->size/4;
  if (use_cache) {
    DdNode *res;
    if (st_lookup(table, f, &res))
      return res;
  }

  // recursive step
  DdNode *const rt = addTransferEvil(src, dest, cuddT(f), table);
  cuddRef(rt);
  DdNode *const re = addTransferEvil(src, dest, cuddE(f), table);
  cuddRef(re);

  DdNode *const var = Cudd_addIthVar(dest, f->index);
  cuddRef(var);
  DdNode *const r = (rt == re) ? rt : Cudd_addIte(dest, var, rt, re);
  cuddRef(r);

  Cudd_RecursiveDeref(dest, var);
  Cudd_RecursiveDeref(dest, rt);
  Cudd_RecursiveDeref(dest, re);

  if (use_cache)
    // store result in cache
    st_add_direct(table, (char *)f, (char *)r);
  else
    cuddDeref(r);

  return r;
}

inline ADD addTransfer(ADD a, Cudd& dest) {
  if (a.manager() == &dest) return a;
  st_table *table = st_init_table(st_ptrcmp, st_ptrhash);
  DdManager *src = a.manager()->getManager();
  DdNode *result = addTransferEvil(src, dest.getManager(), a.getNode(), table);
  ADD res(&dest, result);

  st_generator *gen = st_init_gen(table);
  DdNode *key, *value;
  while (st_gen(gen, &key, &value)) {
    Cudd_RecursiveDeref(dest.getManager(), value);
  }
  st_free_gen(gen);
  st_free_table(table);

  return res;
}

/**
 * Returns approximately <tt>f + g</tt>, where \c f and \c g are ADDs.
 * For each leaf, <tt>f + g</tt> becomes \c f if <tt>f / g &gt; fac</tt>
 * and the other way around.
 * The manager of \c f and \c g is \c man.
 */
inline DdNode *plusTrim(DdManager *man, DdNode *f, DdNode *g, double fac) {
  DdNode *fv, *fvn, *gv, *gvn;
  unsigned int index;

  // terminal cases
  if (f == DD_ZERO(man)) {
    return g;
  }
  if (g == DD_ZERO(man)) {
    return f;
  }
  if (cuddIsConstant(f) && cuddIsConstant(g)) {
    const double fval = cuddV(f);
    const double gval = cuddV(g);

    if (fval / gval > fac) {
      return f;
    } else if (gval / fval > fac) {
      return g;
    } else {
      return cuddUniqueConst(man, fval + gval);
    }
  }

  if (f > g) {
    DdNode *tmp = f;
    f = g;
    g = tmp;
  }
  typedef DdNode * (*DD_CTFP)(DdManager *, DdNode *, DdNode *);
  DdNode *const cached = cuddCacheLookup2(man, (DD_CTFP) plusTrim, f, g);
  if (cached != 0) return cached;

  // recursive step
  const unsigned int ford = cuddI(man, f->index);
  const unsigned int gord = cuddI(man, g->index);
  if (ford <= gord) {
    index = f->index;
    fv = cuddT(f);
    fvn = cuddE(f);
  } else {
    index = g->index;
    fv = fvn = f;
  }
  if (gord <= ford) {
    gv = cuddT(g);
    gvn = cuddE(g);
  } else {
    gv = gvn = g;
  }

  DdNode *const T = plusTrim(man, fv, gv, fac);
  cuddRef(T);
  DdNode *const E = plusTrim(man, fvn, gvn, fac);
  cuddRef(E);
  DdNode *const res = (T == E) ? T : cuddUniqueInter(man, (int) index, T, E);
  cuddDeref(T);
  cuddDeref(E);
  cuddCacheInsert2(man, (DD_CTFP) plusTrim, f, g, res);

  return res;
}

inline void buildV(vector<DdNode *> &xv, const vector<unsigned int> &path,
                   unsigned int lvl, unsigned int j, DdNode *x) {
  if (lvl == path.size())
    xv[j] = x;
  else {
    if(path[lvl] == 0 || path[lvl] == 2)
      buildV(xv, path, lvl + 1, j, x);
    if(path[lvl] == 1 || path[lvl] == 2)
      buildV(xv, path, lvl + 1, j + (1 << (path.size() - 1 - lvl)), x);
  }
}

inline void buildV(vector<DdNode *> &xv, vector<unsigned int> &path,
                   DdNode *x, DdManager *man) {
  const unsigned int lvl = cuddI(man, x->index);
  if (lvl >= path.size()) {
    buildV(xv, path, 0, 0, x);
  } else {
    assertinternal(path[lvl] == 2);
    path[lvl] = 0;
    buildV(xv, path, cuddT(x), man);
    path[lvl] = 1;
    buildV(xv, path, cuddE(x), man);
    path[lvl] = 2;
  }
}

inline DdNode *buildRes(const vector<DdNode *> &rv, unsigned int lvl,
                        unsigned int j, DdManager *man) {
  const unsigned int depth = findPowTwo(rv.size());
  if (lvl == depth) {
    assertinternal(cuddI(man, rv[j]->index) >= (int)depth);
    return rv[j];
  } else {
    DdNode *rt = buildRes(rv, lvl + 1, j, man);
    cuddRef(rt);
    assertinternal(cuddI(man, rt->index) > (int)lvl);
    DdNode *re = buildRes(rv, lvl + 1, j + (1 << (depth - 1 - lvl)), man);
    cuddRef(re);
    assertinternal(cuddI(man, re->index) > (int)lvl);
    DdNode *res = (rt == re) ? rt :
      cuddUniqueInter(man, man->invperm[lvl], rt, re);
    assertinternal(cuddI(man, res->index) >= (int)lvl);
    cuddDeref(rt);
    cuddDeref(re);

    return res;
  }
}

// computes x *= y in a potentially more efficient manner than default
inline void inplaceMult(ADD &x, ADD y, unsigned int depth) {
  DdNode *xn = x.getNode();
  DdNode *yn = y.getNode();

  vector<unsigned int> path(depth, 2);
  vector<DdNode *> xv(1 << depth, (DdNode *)(0));
  vector<DdNode *> yv(1 << depth, (DdNode *)(0));

  DdManager *man = x.manager()->getManager();

  buildV(xv, path, xn, man);
  buildV(yv, path, yn, man);

  map<pair<DdNode *, DdNode *>, DdNode *> prod;

  for (unsigned int i = 0; i < xv.size(); i++)
    if (prod.find(make_pair(xv[i], yv[i])) == prod.end()) {
      prod[make_pair(xv[i], yv[i])] = 0;
      cuddRef(xv[i]);
      cuddRef(yv[i]);
    }

  x = x.manager()->addZero();

  for (map<pair<DdNode *, DdNode *>, DdNode *>::iterator pi = prod.begin();
       pi != prod.end(); pi++) {
    pi->second = Cudd_addApply(man, Cudd_addTimes,
                               pi->first.first, pi->first.second);
    cuddRef(pi->second);
    Cudd_RecursiveDeref(man, pi->first.first);
    Cudd_RecursiveDeref(man, pi->first.second);
  }

  vector<DdNode *> rv(1 << depth, (DdNode *)(0));
  for (unsigned int i = 0; i < rv.size(); i++)
    rv[i] = prod[make_pair(xv[i], yv[i])];

  x = ADD(x.manager(), buildRes(rv, 0, 0, man));

  for (map<pair<DdNode *, DdNode *>, DdNode *>::iterator pi = prod.begin();
       pi != prod.end(); pi++)
    cuddDeref(pi->second);
}

inline DdNode *reRound(DdNode *x, DdManager *mgr, st_table *table) {
  if (cuddIsConstant(x)) return cuddUniqueConst(mgr, cuddV(x));

  const bool use_cache = mgr->size > cuddI(mgr, x->index) + mgr->size/4;
  DdNode *res;
  if (use_cache && st_lookup(table, x, &res))
    return res;

  DdNode *rt = reRound(cuddT(x), mgr, table);
  cuddRef(rt);
  DdNode *re = reRound(cuddE(x), mgr, table);
  cuddRef(re);

  if (rt == cuddT(x) && re == cuddE(x))
    res = x;
  else
    res = rt == re ? rt : cuddUniqueInter(mgr, x->index, rt, re);
  cuddDeref(rt);
  cuddDeref(re);

  if (use_cache)
    st_add_direct(table, (char *)x, (char *)(res));

  return res;
}

inline void reRound(ADD &x, unsigned int depth) {
  DdNode *xn = x.getNode();
  DdManager *man = x.manager()->getManager();
  st_table *table = st_init_table(st_ptrcmp, st_ptrhash);

  vector<unsigned int> path(depth, 2);
  vector<DdNode *> xv(1 << depth, (DdNode *)(0));
  buildV(xv, path, xn, man);

  map<DdNode *, DdNode *> round;
  for (unsigned int i = 0; i < xv.size(); i++)
    if (round.find(xv[i]) == round.end()) {
      round[xv[i]] = 0;
      cuddRef(xv[i]);
    }

  x = x.manager()->addZero();

  for (map<DdNode *, DdNode *>::iterator ri = round.begin(); ri != round.end();
       ri++) {
    ri->second = reRound(ri->first, man, table);
    cuddRef(ri->second);
    Cudd_RecursiveDeref(man, ri->first);
  }

  for (unsigned int i = 0; i < xv.size(); i++)
    xv[i] = round[xv[i]];

  x = ADD(x.manager(), buildRes(xv, 0, 0, man));

  for (map<DdNode *, DdNode *>::iterator ri = round.begin(); ri != round.end();
       ri++)
    cuddDeref(ri->second);

  st_free_table(table);
}

inline DdNode *singleCofactor(DdNode *x, DdManager *mgr, st_table *table,
                              int level, bool T) {
  if (cuddIsConstant(x)) return x;

  const int lvl = cuddI(mgr, x->index);
  if (lvl > level) return x;
  else if (lvl == level) return T ? cuddT(x) : cuddE(x);
  else {
    DdNode *res;
    const bool use_cache = mgr->size > lvl + mgr->size/4;
    if (use_cache && st_lookup(table, x, &res))
      return res;

    DdNode *rt = singleCofactor(cuddT(x), mgr, table, level, T);
    cuddRef(rt);
    DdNode *re = singleCofactor(cuddE(x), mgr, table, level, T);
    cuddRef(re);

    if (rt == cuddT(x) && re == cuddE(x))
      res = x;
    else
      res = rt == re ? rt : cuddUniqueInter(mgr, x->index, rt, re);
    cuddDeref(rt);
    cuddDeref(re);

    if (use_cache)
      st_add_direct(table, (char *)x, (char *)(res));

    return res;
  }
}

inline ADD singleCofactor(ADD x, int index, bool T) {
  DdNode *xn = x.getNode();
  DdManager *man = x.manager()->getManager();
  st_table *table = st_init_table(st_ptrcmp, st_ptrhash);

  DdNode *cof = singleCofactor(xn, man, table, cuddI(man, index), T);

  st_free_table(table);

  return ADD(x.manager(), cof);
}

inline DdNode *dropVar(DdNode *x, DdManager *mgr, st_table *table, int level) {
  if (cuddIsConstant(x)) return cuddUniqueConst(mgr, cuddV(x));

  const int lvl = cuddI(mgr, x->index);
  if (lvl > level) return x;
  else {
    DdNode *res;
    const bool use_cache = mgr->size > lvl + mgr->size/4;
    if (use_cache && st_lookup(table, x, &res))
      return res;

    if (lvl == level)
      res = Cudd_addApply(mgr, Cudd_addOr, cuddT(x), cuddE(x));
    else {
      DdNode *rt = dropVar(cuddT(x), mgr, table, level);
      cuddRef(rt);
      DdNode *re = dropVar(cuddE(x), mgr, table, level);
      cuddRef(re);

      if (rt == cuddT(x) && re == cuddE(x))
        res = x;
      else
        res = rt == re ? rt : cuddUniqueInter(mgr, x->index, rt, re);
      cuddDeref(rt);
      cuddDeref(re);
    }

    if (use_cache)
      st_add_direct(table, (char *)x, (char *)(res));

    return res;
  }
}

inline ADD dropVar(ADD x, int index) {
  DdNode *xn = x.getNode();
  DdManager *man = x.manager()->getManager();
  st_table *table = st_init_table(st_ptrcmp, st_ptrhash);

  DdNode *y = dropVar(xn, man, table, cuddI(man, index));

  st_free_table(table);

  return ADD(x.manager(), y);
}

inline double countMinterm(DdNode *x, DdManager *mgr, double max,
                           CuddCacheN_D &cache) {
  if (cuddIsConstant(x)) {
    if (cuddV(x) == .0)
      return .0;
    else
      return max;
  }

  const int x_level = mgr->perm[x->index];
  const bool use_cache = mgr->size > x_level + mgr->size/4;
  if (use_cache) {
    CuddCacheN_D::const_iterator ci = cache.find(x);
    if (ci != cache.end()) return ci->second;
  }

  DdNode *xt = cuddT(x);
  DdNode *xe = cuddE(x);

  const double minT = countMinterm(xt, mgr, max, cache);
  const double minE = countMinterm(xe, mgr, max, cache);

  const double res = .5*(minT + minE);
  if (use_cache) {
    if (cache.size() > (1 << 17)) cache.clear();
    cache[x] = res;
  }
  return res;
}

inline double countMinterm(ADD &x) {
  CuddCacheN_D &cache =
    CuddCacheManager::getCacheN_D("countMinterm", x.manager()->getManager());
  return countMinterm(x.getNode(), x.manager()->getManager(),
                      pow(2., x.manager()->ReadSize()), cache);
}

inline void writeLabel(gzFile out, DdNode *key,
                       map<DdNode *, pair<unsigned int, int> > &label) {
  map<DdNode *, pair<unsigned int, int> >::iterator lt = label.find(key);
  assertinternal(lt != label.end());
  write(out, lt->second.first);
  lt->second.second--;
  if (lt->second.second <= 0 &&
      !(cuddIsConstant(key) && (cuddV(key) == .0 || cuddV(key) == 1.)))
    label.erase(lt);
}

inline void writeADD(gzFile out, DdNode *x,
                     map<DdNode *, pair<unsigned int, int> > &label,
                     unsigned int &ls) {
  if (label.find(x) == label.end()) {
    if (!cuddIsConstant(x)) {
      writeADD(out, cuddT(x), label, ls);
      writeADD(out, cuddE(x), label, ls);
    }
    label[x] = make_pair(ls, x->ref);
    ls++;
    write(out, (unsigned int)(x->index));
    if (cuddIsConstant(x))
      write(out, cuddV(x));
    else {
      writeLabel(out, cuddT(x), label);
      writeLabel(out, cuddE(x), label);
    }
  }
}

inline void writeADD(const string &fn, ADD x) {
  gzFile out = gzopen(fn.c_str(), "wb");
  assertcond(out != 0, "unable to write diagram swap file: '" + fn +  "'!");
  Cudd &mgr = *x.manager();
  write(out, (unsigned int)mgr.ReadSize());
  for (int i = 0; i < mgr.ReadSize(); i++)
    write(out, (unsigned int)mgr.getManager()->invperm[i]);

  map<DdNode *, pair<unsigned int, int> > label;
  unsigned int ls = 0;
  writeADD(out, x.getNode(), label, ls);

  gzclose(out);
}

inline ADD readADD(const string &fn, Cudd &mgr) {
  gzFile in = gzopen(fn.c_str(), "rb");
  assertcond(in != 0, "unable to read diagram swap file: '" + fn +  "'!");

  unsigned int size;
  read(in, size);
  assertinternal(size == (unsigned int)mgr.ReadSize());
  int *invperm = new int[size];
  for (unsigned int i = 0; i < size; i++)
    read(in, invperm[i]);
  mgr.ShuffleHeap(invperm);
  delete [] invperm;

  vector<DdNode *> nodes;
  while (!gzeof(in)) {
    unsigned int index;
    read(in, index);
    DdNode *x;
    if (index == CUDD_CONST_INDEX) {
      double value;
      read(in, value);
      x = cuddUniqueConst(mgr.getManager(), value);
    } else {
      assertinternal(index < size);
      unsigned int t, e;
      read(in, t);
      read(in, e);
      assertinternal(t < nodes.size() && e < nodes.size());
      DdNode *nt = nodes[t];
      DdNode *ne = nodes[e];
      x = nt == ne ? nt : cuddUniqueInter(mgr.getManager(), index, nt, ne);
    }
    cuddRef(x);
    nodes.push_back(x);
  }
  assertinternal(!nodes.empty());
  gzclose(in);

  // Every node is going to be owned by someone so no need for recursive deref
  for (unsigned int i = 0; i < nodes.size(); i++) {
    cuddDeref(nodes[i]);
    assertinternal(nodes[i]->ref > 0 || i + 1 == nodes.size());
  }

  return ADD(&mgr, nodes.back());
}

inline void expandVector(double *f, unsigned int lvl_child,
                         unsigned int lvl, unsigned int size, IV sz,
                         unsigned int not_top = 1) {
  assert(lvl_child > lvl);
  unsigned int n, num_dup;
  if (lvl_child == CUDD_CONST_INDEX) {
    n = 1;
    num_dup = 1 << (size - lvl - not_top);
  } else {
    n = 1 << (size - lvl_child);
    num_dup = 1 << (lvl_child - lvl - not_top);
  }
  for (unsigned int i = 1; i < num_dup; i++)
    memcpy(f + sz/2 + i*n, f + sz/2, n*sizeof(double));
}

// inline void ddnodeToVector(double *f, DdNode *x, DdManager *mgr,
//                            st_table *table, unsigned int size) {
//   if (cuddIsConstant(x)) *f = cuddV(x);
//   else {
//     const int lvl = cuddI(mgr, x->index);
//     double *res;
//     const IV sz = IV(1) << (size - lvl);
//     const bool use_cache = mgr->size > lvl + mgr->size/4;
//     if (use_cache && st_lookup(table, x, &res))
//       memcpy(f, res, sz*sizeof(double));
//     else {
//       ddnodeToVector(f + sz/2, cuddT(x), mgr, table, size);
//       expandVector(f, cuddI(mgr, cuddT(x)->index), lvl, size, sz);

//       ddnodeToVector(f, cuddE(x), mgr, table, size);
//       expandVector(f, cuddI(mgr, cuddE(x)->index), lvl, size, 0);
// //         memcpy(f + i*n_E, f, n_E*sizeof(double));

//       if (use_cache)
//         st_add_direct(table, (char *)x, (char *)f);
//     }
//   }
// }

inline void ddnodeToVector(double *f, int *perm, DdNode *x,
                           st_table *table, unsigned int size) {
  if (cuddIsConstant(x)) *f = cuddV(x);
  else {
    const int f_lvl = perm[x->index];
    assertinternal(f_lvl >= 0);
//    const int x_lvl = cuddI(mgr, x->index);
    double *res;
    const IV sz = IV(1) << (size - f_lvl);
    const bool use_cache = size > f_lvl + size/4;
    if (use_cache && st_lookup(table, x, &res))
      memcpy(f, res, sz*sizeof(double));
    else {
      DdNode *T = cuddT(x);
      ddnodeToVector(f + sz/2, perm, T, table, size);

      const int T_index = T->index;
      expandVector(f, T_index == CUDD_CONST_INDEX ? CUDD_CONST_INDEX :
                   perm[T_index], f_lvl, size, sz);

      DdNode *E = cuddE(x);
      ddnodeToVector(f, perm, cuddE(x), table, size);

      const int E_index = E->index;
      expandVector(f, E_index == CUDD_CONST_INDEX ? CUDD_CONST_INDEX :
                   perm[E_index], f_lvl, size, 0);
//         memcpy(f + i*n_E, f, n_E*sizeof(double));

      if (use_cache)
        st_add_direct(table, (char *)x, (char *)f);
    }
  }
}

inline void addToVector(double *f, ADD &x, int *perm = 0) {
  DdNode *xn = x.getNode();
  DdManager *mgr = x.manager()->getManager();
  st_table *table = st_init_table(st_ptrcmp, st_ptrhash);

  if (perm == 0)
    perm = mgr->perm;

  int sz = 0;
  for (int i = 0; i < mgr->size; i++)
    if (perm[i] != -1)
      sz++;

  memset(f, 0, (IV(1) << sz)*sizeof(double));
  ddnodeToVector(f, perm, xn, table, sz);
  if (xn->index == CUDD_CONST_INDEX || perm[xn->index] > 0)
    expandVector(f, xn->index == CUDD_CONST_INDEX ? sz : perm[xn->index], 0, sz,
                 0, 0);

  st_free_table(table);
}

/// Return the ADD corresponding to arr
inline DdNode *arr2add(DdManager *man, const double *arr, int *arr_invperm,
                       DdNode *zo, IV len, int arr_level) {
  // terminal case
  if (len == 1)
    return Cudd_addConst(man, *arr);

  const int index = arr_invperm[arr_level];
  const int man_level = man->perm[index];

  const IV next_len = len >> 1;

  DdNode *zo_T, *zo_E;
  const int zo_level = cuddI(man, zo->index);
  if (man_level == zo_level) {
    zo_T = cuddT(zo);
    zo_E = cuddE(zo);
  } else if (zo_level > man_level)
    zo_T = zo_E = zo;
  else
    assertinternal(false);

  DdNode *rt = (zo_T == man->zero ? man->zero :
                arr2add(man, arr + next_len, arr_invperm, zo_T, next_len,
                        arr_level + 1));
  cuddRef(rt);
  DdNode *re = (zo_E == man->zero ? man->zero :
                arr2add(man, arr, arr_invperm, zo_E, next_len, arr_level + 1));
  cuddRef(re);

  DdNode *r = rt == re ? rt : cuddUniqueInter(man, index, rt, re);
  cuddDeref(rt);
  cuddDeref(re);

  return r;
}

inline void vectorToADD(ADD &res, double *f, int *f_invperm, ADD &zo) {
  DdManager *mgr = res.manager()->getManager();
  IV numiv = 1;
  for (int i = 0; i < mgr->size; i++)
    if (f_invperm[i] != -1)
      numiv <<= 1;
  res = ADD(res.manager(), arr2add(mgr, f, f_invperm, zo.getNode(), numiv, 0));
}

#endif // _CUDDUTIL
