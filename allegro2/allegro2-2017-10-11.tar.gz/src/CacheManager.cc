#include "CacheManager.hh"

extern "C" {
  int cleanCache(DdManager */*man*/, const char *, void *) {
    CuddCacheManager::flush();
    return 1;
  }
}

map<pair<string, DdManager *>, CuddCacheN_D> CuddCacheManager::m_cachesN_D;
map<pair<string, DdManager *>, CuddCacheNN_N> CuddCacheManager::m_cachesNN_N;
map<pair<string, DdManager *>, CuddCacheNN_D> CuddCacheManager::m_cachesNN_D;
