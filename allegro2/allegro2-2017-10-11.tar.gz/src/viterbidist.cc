#include "files.h"
#include "family.h"
#include "distribution.h"
#include "viterbidist.h"
#include "map.h"
#include "options.h"
#include "utils.h"
#include "vecutil.h"
#include "calcviterbi.h"
#include "Sweeper.hh"

Viterbidist::Viterbidist(const string &p) :
    Distribution(p), path(0), ntmpfc(10), ntmp(10), sweeper(0) {
  calc = Calcviterbi::getcalcviterbi(p);
  tmpfloat = new Float[1 << ntmp];
  tmpfcfloat = new Float[1 << ntmpfc];
  tmpiv = new IV[1 << ntmp];
  tmpfciv = new IV[1 << ntmpfc];
}

void Viterbidist::nextfam(bool mtbdd, Uint pos, DoubleVec /*p0*/) {
  Family *fam = curfamily();
  if (sweeper != 0) delete sweeper;
  if (mtbdd) {
    sweeper = new Sweeper(fam);
    racc.resize(map->loci.size());
  }
  else {
    assertinternal(pos == 0);
    calc->psi->nextfam(map->loci.size()*fam->numiv(), fam->numiv());
    // Calculate how big tmp vectors have to be
    Uint curtmp = 0;
    Uint curtmpfc = 0;
    for (Foundercouple *fc = fam->firstfoundercouple; fc != 0; fc = fc->next) {
      Uint ngc = 0;
      for (Plist *c = fc->wife->children; c != 0; c = c->next)
        if (c->p->children != 0) ngc += c->p->children->length();
      curtmpfc = max(curtmpfc, 2*(fc->wife->children->length() - 1) + ngc - 1);
    }
    for (Person *p = fam->first; p != fam->firstdescendant; p = p->next)
      if (p->children != 0) curtmp = max(curtmp, p->children->length() - 1);
    // Resize tmp vectors if needed
    if (curtmp > ntmp) {
      ntmp = curtmp;
      delete [] tmpfloat;
      delete [] tmpiv;
      tmpfloat = new Float[1 << ntmp];
      tmpiv = new IV[1 << ntmp];
    }
    if (curtmpfc > ntmpfc) {
      ntmpfc = curtmpfc;
      delete [] tmpfcfloat;
      delete [] tmpfciv;
      tmpfcfloat = new Float[1 << ntmpfc];
      tmpfciv = new IV[1 << ntmpfc];
    }
  }
}

Viterbidist::~Viterbidist() {
  delete [] path;
  delete [] tmpfloat;
  delete [] tmpfcfloat;
  delete [] tmpiv;
  delete [] tmpfciv;

  delete sweeper;
}

void Viterbidist::reset(Uint np) {
  delete [] path;
  path = new IV[np];
  npos = np;

  delete sweeper;
  racc.clear();
}

void Viterbidist::gettheta(Uint gam, Float &tht, Float &tht_female) const {
  tht = map->loci[gam].thetaMale();
  tht_female = map->loci[gam].thetaFemale();
}

void Viterbidist::set(FloatVec q, Uint gam) {
  Family *fam = curfamily();
  const IV numiv = fam->numiv();
  if (gam == npos - 1) copyvec(calc->vec, q, numiv);
  else {
    IVVec h = calc->psi->getrow(gam, false);
    for (IV v = 0; v < numiv; v++) h[v] = v;
    Float tht, tht_female;
    gettheta(gam, tht, tht_female);
    step(calc->vec, h, tht, tht_female);
    calc->psi->store(gam);
    elemprod(calc->vec, calc->vec, q, numiv);
    normal<Float>(calc->vec, numiv);
    assertinternal(calc->vec[0] >= 0);
  }
  if (gam == 0) {
    Float deltamax = -1;
    for (IV v = 0; v < numiv; v++)
      if (deltamax < calc->vec[v]) {
        deltamax = calc->vec[v];
        path[0] = v;
      }
    assertinternal(deltamax != -1);
    for (Uint g = 1; g < npos; g++)
      path[g] = calc->psi->getrow(g - 1, true)[path[g - 1]];
  }
}

void print(IV v, Uint nb) {
  string o;
  for (Uint i = 0; i < nb; i++)
    o += v & (IV(1) << i) ? "1" : "0";
  cout << o << endl;
}

void Viterbidist::set(ADD &pv, double /*sum_pv*/, Uint pos) {
  assertinternal(sweeper != 0);

  calc->S.push_back(pv);
  const string fn(options->swapdirname + "/" + describe() + "." + pos);
  if (pos == npos - 1) {
    sweeper->firstMarker();
    racc.back() = sweeper->getRacc();
  } else {
    Float tht, tht_female;
    gettheta(pos, tht, tht_female);
    sweeper->nextMarker(racc[pos], tht, tht_female < .0 ? tht : tht_female, pos,
                        true, false);
  }
  sweeper->updateFrom(pv);
  sweeper->writeFrom(fn);

  if (pos == 0) {
    path[0] = sweeper->startViterbiBacktrack();
    remove(fn.c_str());
    for (Uint g = 1; g < npos; g++) {
      Float tht, tht_female;
      gettheta(pos, tht, tht_female);
      const string fn(options->swapdirname + "/" + describe() + "." + g);
      path[g] = sweeper->viterbiBacktrack(path[g - 1], racc[g],
                                          calc->S[npos - 1 - g], tht,
                                          tht_female < .0 ? tht : tht_female,
                                          fn);
      remove(fn.c_str());
    }

    delete sweeper;
    sweeper = 0;
    racc.clear();
  }
}

void Viterbidist::SPT(ADDvector &sp) {
  if (sweeper != 0)
    sweeper->setup(sp);
}

void Viterbidist::dobits(FloatVec p, IVVec h, Float fac,
                         IV frombit, IV tobit, IV N) {
  for (IV k = frombit; k <= tobit; k <<= 1) {
    IV u = 0;
    while (u < N) {
      for (IV v = u; v < u + k; v++)
        dobit(p[v], p[v | k], h[v], h[v | k], fac);
      u += k << 1;
    }
  }
}

void Viterbidist::dofounderloop(FloatVec p0, IVVec h, Float fac, IV base,
                                IV mask, IV lastbit) {
  for (IV k = base, i = 0; k <= mask + base; i++, k += lastbit) {
    tmpfloat[i] = p0[k];
    tmpiv[i] = h[k];
  }
  Uint N = mask/lastbit;
  // First assume there is not a recombination in first child
  dobits(tmpfloat, tmpiv, fac, 1, N, N + 1);
  // Then assume that there is one
  for (IV k = lastbit; k <= mask; k <<= 1) {
    IV u = base;
    while (u <= mask + base) {
      for (IV w = u; w < u + k; w += lastbit)
        doinversebit(p0[w], p0[w | k], h[w], h[w | k], fac);
      u += k << 1;
    }
  }
  for (IV k = base, i = 0; k <= mask + base; i++, k += lastbit) {
    p0[k] *= fac;
    if (tmpfloat[i] > p0[k]) {
      p0[k] = tmpfloat[i];
      h[k] = tmpiv[i];
    }
  }
}

void Viterbidist::dofounder(FloatVec p0, IVVec h, Float fac, IV N,
                            IV mask, IV lastbit) {
  IV u = 0;
  if (lastbit == 0) lastbit = N;
  while (u < N) {
    for (IV v = u; v < lastbit + u; v++) {
      dofounderloop(p0, h, fac, v, mask, lastbit);
    }
    u += mask + lastbit;
  }
}

void Viterbidist::calculatefcpi(IV base, FloatVec p0, IVVec hp,
                                Foundercouple *fc) {
  Uint n = POPCOUNT(fc->wife->mask);
  // First loop over bits of husband and wife
  for (IV w = 0; w <= fc->wife->mask; w += fc->wife->lastbit)
    for (IV h = (w >> n) /*+ fc->husband->lastbit*/;
         h <= fc->husband->mask; h += fc->husband->lastbit) {
      IV m = h | w;
      IV pim = fc->pi(m);
      // Then loop over bits of fc's grandchildren
     IV to, inc;
      if (m != pim) {
        to = fc->mask + fc->lastgcbit;
        inc = fc->lastgcbit;
      }
      else if (POPCOUNT(fc->mask) == 1) {
        to = fc->mask;
        inc = fc->mask;
      }
      else {
        to = (fc->mask + fc->lastgcbit)/2;
        inc = fc->lastgcbit;
      }
      for (IV v = base; v < to + base; v += inc) {
        IV a = m | v;
        IV b = pim | (v^fc->mask);
        Float tp = p0[a];
        IV th = hp[a];
        p0[a] = p0[b];
        p0[b] = tp;
        hp[a] = hp[b];
        hp[b] = th;
      }
    }
}

void Viterbidist::dofcfounders(FloatVec p0, IVVec h, Float fac, Uint wm,
                               IV wb, IV hm, IV hb, IV start, IV inc, IV end) {
  for (IV u = start; u < end; u += inc) {
    for (IV i = u; i <= u + wm; i += wb)
      dofounderloop(p0, h, fac, i, hm, hb);
    for (IV i = u; i <= u + hm; i += hb)
      dofounderloop(p0, h, fac, i, wm, wb);
  }
}

void Viterbidist::dofc(FloatVec p, IVVec h, Float fac, IV frombit, IV tobit,
                       IV start, IV inc, IV end) {
  IV N = frombit + tobit;
  for (IV k = frombit; k <= tobit; k <<= 1) {
    IV u = 0;
    while (u < N) {
      for (IV w = u; w < u + k; w += frombit)
        for (IV v = start + w; v < end + w; v += inc)
          dobit(p[v], p[v | k], h[v], h[v | k], fac);
      u += k << 1;
    }
  }
}

void makefcmask(IV num, Uint n, IV &wm, IV &hm, IV &wb, IV &hb) {
  wm = hm = wb = hb = 0;
  for (Uint i = 0; i < n; i++) {
    num /= 2;
    wm += num;
    wb = num;
  }
  for (Uint i = 0; i < n; i++) {
    num /= 2;
    hm += num;
    hb = num;
  }
}

void Viterbidist::step(FloatVec p0, IVVec h, Float tht, Float tht_female) {
  const Float fac = tht/(1.0 - tht);
  const Float fac_female = tht_female/(1.0 - tht_female);
  Family *fam = curfamily();
  const IV numiv = fam->numiv();
  // First take care of founder couple bits
  for (Foundercouple *fc = fam->firstfoundercouple; fc != 0; fc = fc->next) {
    assertinternal(!options->sexspecific);
    for (IV k1 = 0; k1 < numiv; k1 += fc->childrenmask + fc->lastcbit())
      for (IV k2 = k1; k2 < k1 + fc->lastcbit();
           k2 += fc->mask + fc->lastgcbit)
        for (IV k3 = k2; k3 < k2 + fc->lastgcbit; k3++) {
          // Copy to temporary buffers
          IV i = 0;
          // First assume there is not a recombination in the founder
          // couple grandchild
          for (IV v = 0; v <= fc->childrenmask; v += fc->lastcbit())
            // Go through the bits of the children of the fc
            for (IV u = v; u <= v + fc->mask; u += fc->lastgcbit) {
              // Go through the bits of the grandchildren of the fc
              tmpfcfloat[i] = p0[k3 + u];
              tmpfciv[i] = h[k3 + u];
              i++;
            }
          IV wm, hm, wb, hb;
          makefcmask(i, POPCOUNT(fc->wife->mask), wm, hm, wb, hb);
          dofounder(tmpfcfloat, tmpfciv, fac, i, wm, wb);
          dofounder(tmpfcfloat, tmpfciv, fac, i, hm, hb);
          dobits(tmpfcfloat, tmpfciv, fac, 1,
                 (hb == 0 ? (IV(1) << POPCOUNT(fc->mask) - 1) :
                  hb - 1), i);
          // Then assume there is a recombination in the founder
          // couple grandchild
          calculatefcpi(k3, p0, h, fc);
          dofcfounders(p0, h, fac, fc->wife->mask, fc->wife->lastbit,
                       fc->husband->mask, fc->husband->lastbit,
                       k3, fc->lastgcbit, fc->mask + fc->lastgcbit);
          dofc(p0, h, fac, fc->lastgcbit, fc->mask,
               k3, fc->husband->lastbit, fc->wife->mask + fc->wife->lastbit);
          // Compare results
          i = 0;
          for (IV v = 0; v <= fc->childrenmask; v += fc->lastcbit())
            // Go through the bits of the children of the fc
            for (IV u = v; u <= v + fc->mask; u += fc->lastgcbit) {
              // Go through the bits of the grandchildren of the fc
              p0[k3 + u] *= fac;
              if (tmpfcfloat[i] > p0[k3 + u]) {
                p0[k3 + u] = tmpfcfloat[i];
                h[k3 + u] = tmpfciv[i];
              }
              i++;
            }
        }
  }
  // Next take care of founder bits
  for (Person *p = fam->first; p != fam->firstdescendant; p = p->next)
    if (p->mask != 0 && p->fc == 0) {
      if (!options->sexspecific || p->sex == MALE) 
        dofounder(p0, h, fac, numiv, p->mask, p->lastbit);
      else
        dofounder(p0, h, fac_female, numiv, p->mask, p->lastbit);
    }
  // Finally take care of the rest of the bits
  if (options->sexspecific) {
    for (Person *p = fam->firstdescendant; p != 0; p = p->next) {
      for (Plist *c = p->children; c != 0; c = c->next)
        if (p->sex == MALE && c->p->patmask != 0)
          dobits(p0, h, fac, c->p->patmask, c->p->patmask, numiv);
        else // (p->sex == FEMALE && c->p->matmask != 0)
          dobits(p0, h, fac_female, c->p->matmask, c->p->matmask, numiv);
    }
  }
  else
    dobits(p0, h, fac, 1, fam->mask, numiv);
}

Uint Viterbidist::countfounderrecombs(IV mask, IV v0, IV v1,
                                      Uint &same, Uint &diff) const {
  // Calc number of bits unchanged
  same = POPCOUNT(~(v1 ^ v0) & mask);
  // Calc number of bits changed
  diff = POPCOUNT(mask) - same;
  return max(int(same), int(diff) - 1);
}

Uint Viterbidist::countfcrecombs(Foundercouple *fc, IV v0, IV v1,
                                 Uint &same, Uint &diff) const {
  same = diff = 0;
  Uint a, b;
  // Calc number of recombinations if there IS NOT a recomb in gc
  same += countfounderrecombs(fc->wife->mask, v0, v1, a, b);
  same += countfounderrecombs(fc->husband->mask, v0, v1, a, b);
  countfounderrecombs(fc->mask, v0, v1, a, b);
  same += a;
  diff += b;
  // Calc number of recombinations if there IS a recomb in gc
  Uint shift = POPCOUNT(fc->wife->mask);
  diff += countfounderrecombs(fc->husband->mask, v0 >> shift, v1, a, b);
  diff += countfounderrecombs(fc->husband->mask, v0, v1 >> shift, a, b);
  return max(int(same), int(diff) - 1);
}

Uint Viterbidist::countrecombs(Family *f, IV v0, IV v1) const {
  Uint recs = 0;
  Uint same, diff;
  for (Foundercouple *fc = f->firstfoundercouple; fc != 0; fc = fc->next)
    recs +=
      POPCOUNT(fc->mask | fc->husband->mask | fc->wife->mask) -
      countfcrecombs(fc, v0, v1, same, diff);
  for (Person *p = f->first; p != 0; p = p->next)
    if (p->children != 0 && p->fc == 0 && p->founder() &&
        (!options->sexlinked || p->sex == FEMALE))
      recs += POPCOUNT(p->mask) -
        countfounderrecombs(p->mask, v0, v1, same, diff);
  recs += POPCOUNT(f->mask) -
    POPCOUNT(~(v1 ^ v0) & f->mask);
  return recs;
}
