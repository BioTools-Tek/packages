#include "SPPeel.hh"
#include "SPPeelMarriage.hh"

SPPeel::SPPeel(Uint gam, Family *fam, Cudd &mgr) : m_mgr(mgr) {
  for (Person *p = fam->first; p != 0; p = p->next) {
    const string father(p->founder() ? "" : p->father->id);
    const string mother(p->founder() ? "" : p->mother->id);
    if (p->genotyped(gam))
      addPerson(p->id, father, mother, p->patbitlevel, p->matbitlevel,
                p->founder(), p->gen[0][gam], p->gen[1][gam]);
    else if (p->children != 0 && p->hasgenotypeddesc(gam))
      addPerson(p->id, father, mother, p->patbitlevel, p->matbitlevel,
                p->founder(), ALLELEUNKNOWN, ALLELEUNKNOWN);
  }
}

SPPeel::SPPeel(const vector<SPPeelMarriage> &fam, SPPeelPerson *split_on,
               PhasedGT selected_haplotype, Cudd &mgr) : m_mgr(mgr) {
  assertinternal(!split_on->isFounder());
  // First add people (other than split_to as children
  unsigned int split_count = 0;
  for (vector<SPPeelMarriage>::const_iterator fi = fam.begin(); fi != fam.end();
       fi++) {
    const string father_id = addParent(fi->m_father, split_on,
                                       selected_haplotype, split_count);
    const string mother_id = addParent(fi->m_mother, split_on,
                                       selected_haplotype, split_count);
    for (vector<SPPeelPerson *>::const_iterator ci = fi->m_children.begin();
         ci != fi->m_children.end(); ci++) {
      string id = (*ci)->m_id;
      if (*ci == split_on) {
        id += string(" ") + split_count;
        split_count++;
      }
      SPPeelPerson *c = m_family[id] =
        new SPPeelPerson(id, father_id, mother_id, (*ci)->m_patbitlevel,
                         (*ci)->m_matbitlevel, (*ci)->isFounder());
      if (*ci == split_on)
        c->m_phases[selected_haplotype] =
          split_on->m_phases[selected_haplotype];
      else
        c->m_phases = (*ci)->m_phases;
    }
  }
  assertinternal(split_count > 1);

  // See if some people only occur as founders
  for (vector<SPPeelMarriage>::const_iterator fi = fam.begin(); fi != fam.end();
       fi++) {
    if (fi->m_father != split_on &&
        m_family.find(fi->m_father->m_id) == m_family.end()) {
      SPPeelPerson *f = m_family[fi->m_father->m_id] =
        new SPPeelPerson(fi->m_father->m_id, "", "", Person::FIXEDBIT,
                         Person::FIXEDBIT, fi->m_father->isFounder());
      f->m_phases = fi->m_father->m_phases;
    }
    if (fi->m_mother != split_on &&
        m_family.find(fi->m_mother->m_id) == m_family.end()) {
      SPPeelPerson *f = m_family[fi->m_mother->m_id] =
        new SPPeelPerson(fi->m_mother->m_id, "", "", Person::FIXEDBIT,
                         Person::FIXEDBIT, fi->m_mother->isFounder());
      f->m_phases = fi->m_mother->m_phases;
    }
  }
}

string SPPeel::addParent(SPPeelPerson *founder, SPPeelPerson *split_on,
                         PhasedGT selected_haplotype,
                         unsigned int &split_count) {
  string id = founder->m_id;
  if (founder == split_on) {
    id += string(" ") + split_count;
    split_count++;
    SPPeelPerson *f = m_family[id] = new SPPeelPerson(id, "", "",
                                                      Person::FIXEDBIT,
                                                      Person::FIXEDBIT, false);
    f->m_phases[selected_haplotype] = split_on->m_phases[selected_haplotype];
  }
  return id;
}

SPPeel::~SPPeel() {
  for (PeelFamily::const_iterator pfi = m_family.begin(); pfi != m_family.end();
       pfi++)
    delete pfi->second;
}

ADD SPPeel::peel(const FloatVec &allele_freq, Uint nalleles) {
  if (m_family.empty()) return m_mgr.addOne();

  // Setup marriages to be peeled
  typedef hash_map<string, SPPeelMarriage, stringhash> Marriages;
  Marriages marriages;

  for (PeelFamily::iterator fit = m_family.begin(); fit != m_family.end();
       fit++) {
    if (fit->second->m_father == "") continue;
    string key = fit->second->m_father + " / " + fit->second->m_mother;
    Marriages::const_iterator mar = marriages.find(key);
    if (mar == marriages.end())
      marriages[key] = SPPeelMarriage(findPerson(fit->second->m_father),
                                      findPerson(fit->second->m_mother));
    marriages[key].addChild(fit->second);
  }

  vector<SPPeelMarriage> fam;
  for (Marriages::const_iterator mit = marriages.begin();
       mit != marriages.end(); mit++)
    fam.push_back(mit->second);

  SPPeelMarriage::setAlleleFreq(allele_freq, nalleles);

  ADDvector vars = m_mgr.GetADDVariables();

  // Actual peeling
  ADD result = m_mgr.addZero();
  while (!fam.empty() && result == m_mgr.addZero()) {
    // Search for ellegible marriage
    vector<SPPeelMarriage>::iterator best_mar = fam.end();
    SPPeelPerson *best_peel_to = 0;
    unsigned int best_cost = INT_MAX;
    for (vector<SPPeelMarriage>::iterator mit = fam.begin();
         mit != fam.end(); mit++) {
      SPPeelPerson *peel_to;
      if (mit->ripe(peel_to, fam)) {
        const unsigned int cost =
          mit->m_father->numPhasedGTs()*mit->m_mother->numPhasedGTs();
        if (cost < best_cost) {
          best_mar = mit;
          best_peel_to = peel_to;
          best_cost = cost;
        }
      }
    }

    if (best_mar != fam.end()) { // Found marriage to peel
      // Propagate genotype information as much as possible befor peeling
      propagateGenotypes(fam);

      best_mar->peelTo(best_peel_to, m_mgr, vars, fam.size() == 1);
      fam.erase(best_mar);
      if (fam.empty()) result = best_peel_to->sumProb(m_mgr);
    } else { // No ellegible marriage found, need to split a person
      SPPeelPerson *split_on = findLoopBreaker(fam);

      for (map<PhasedGT, ADD>::const_iterator hai = split_on->m_phases.begin();
           hai != split_on->m_phases.end(); hai++) {
        SPPeel split(fam, split_on, hai->first, m_mgr);
        result += split.peel(allele_freq, nalleles);
      }
    }
  }

  return result;
}

SPPeelPerson *SPPeel::findPerson(const string &id) {
  for (PeelFamily::iterator fit = m_family.begin(); fit != m_family.end();
       fit++)
    if (fit->first == id)
      return fit->second;
  assertinternal(false);
  return 0;
}

SPPeelPerson *SPPeel::findLoopBreaker(const vector<SPPeelMarriage> &fam) {
  // a loop breaker must be a parent in at least one family and a
  // child at least one
  SPPeelPerson *loop_breaker = 0;
  for (vector<SPPeelMarriage>::const_iterator fit = fam.begin();
       fit != fam.end(); fit++)
    for (vector<SPPeelPerson *>::const_iterator cit = fit->m_children.begin();
         cit != fit->m_children.end(); cit++)
      if (!(*cit)->isLeaf(fam) &&
          (loop_breaker == 0 ||
           loop_breaker->m_phases.size() < (*cit)->m_phases.size()) &&
          finerThanRelatives(**cit, fam))
        loop_breaker = *cit;

  if (loop_breaker == 0) {
    // Look for the person with the smallest number of possible
    // haplotypes and make it a loop_breaking candidate
    for (vector<SPPeelMarriage>::const_iterator fit = fam.begin();
         fit != fam.end(); fit++)
      for (vector<SPPeelPerson *>::const_iterator cit = fit->m_children.begin();
           cit != fit->m_children.end(); cit++)
        if (!(*cit)->isLeaf(fam) &&
            (loop_breaker == 0 ||
             loop_breaker->numPhasedGTs() < (*cit)->numPhasedGTs()))
          loop_breaker = *cit;
    assertinternal(loop_breaker != 0);

    makeFinerThanRelatives(*loop_breaker, fam);
  }
  assertcond(loop_breaker != 0, "Unable to break loop. Please report this bug");
  return loop_breaker;
}

bool SPPeel::finerThanRelatives(const SPPeelPerson &p,
                                const vector<SPPeelMarriage> &fam) {
  for (vector<SPPeelMarriage>::const_iterator fit = fam.begin();
       fit != fam.end(); fit++) {
    if (!p.isFiner(*fit->m_father) || !p.isFiner(*fit->m_mother))
      return false;
    for (vector<SPPeelPerson *>::const_iterator cit = fit->m_children.begin();
         cit != fit->m_children.end(); cit++)
      if (!p.isFiner(**cit))
        return false;
  }
  return true;
}

void SPPeel::makeFinerThanRelatives(SPPeelPerson &p,
                                    const vector<SPPeelMarriage> &fam) {
  for (vector<SPPeelMarriage>::const_iterator fit = fam.begin();
       fit != fam.end(); fit++) {
    if (!p.isFiner(*fit->m_father))
      p.makeFinerThan(*fit->m_father);
    if (!p.isFiner(*fit->m_mother))
      p.makeFinerThan(*fit->m_mother);
    for (vector<SPPeelPerson *>::const_iterator cit = fit->m_children.begin();
         cit != fit->m_children.end(); cit++)
      if (!p.isFiner(**cit))
        p.makeFinerThan(**cit);
  }
}

void SPPeel::uniquify(set<PhasedGT> &ass) {
  assertinternal(!ass.empty());
  if (ass.size() == 1) return;
  bool overlap_found;
  do {
    overlap_found = false;
    for (set<PhasedGT>::iterator i = ass.begin(); i != ass.end(); i++) {
      for (set<PhasedGT>::iterator j = ass.begin(); j != i; j++)
        if (overlap(*i, *j)) {
          const PhasedGT ia = *i;
          const PhasedGT ja = *j;
          overlap_found = true;
          if (ia == ja)
            ass.erase(i);
          else {
            const PhasedGT inter = intersection(ia, ja);
            assertinternal(inter.first != 0 && inter.second != 0);
            const PhasedGT i_rest = subtract(ia, inter);
            const PhasedGT j_rest = subtract(ja, inter);
            insertExtra(ass, inter, i_rest, ia);
            insertExtra(ass, inter, j_rest, ja);
            set<PhasedGT>::iterator ii = find(ass.begin(), ass.end(), ia);
            assertinternal(ii != ass.end());
            ass.erase(ii);
            set<PhasedGT>::iterator jj = find(ass.begin(), ass.end(), ja);
            assertinternal(jj != ass.end());
            ass.erase(jj);
            ass.insert(inter);
          }
          break;
        }
      if (overlap_found)
        break;
    }
  } while (overlap_found);
  assertinternal(!ass.empty());

  for (set<PhasedGT>::iterator i = ass.begin(); i != ass.end(); i++)
    for (set<PhasedGT>::iterator j = ass.begin(); j != i; j++)
      if (overlap(*i, *j))
        cerr << "found overlapping assignments" << endl;
}

void SPPeel::propagateGenotypes(vector<SPPeelMarriage> &fam) {
  set<SPPeelPerson *> changed;
  for (vector<SPPeelMarriage>::iterator fit = fam.begin(); fit != fam.end();
       fit++) {
    changed.insert(fit->m_father);
    changed.insert(fit->m_mother);
    for (vector<SPPeelPerson *>::iterator cit = fit->m_children.begin();
         cit != fit->m_children.end(); cit++)
      changed.insert(*cit);
  }

  do {
    set<SPPeelPerson *> newly_changed;

//    printVec(fam);

    for (vector<SPPeelMarriage>::iterator fit = fam.begin(); fit != fam.end();
         fit++) {
      bool changes = (changed.count(fit->m_father) > 0 ||
                      changed.count(fit->m_mother) > 0);
      for (vector<SPPeelPerson *>::iterator cit = fit->m_children.begin();
           !changes && cit != fit->m_children.end(); cit++)
        changes |= changed.count(*cit);

      if (changes) {
        set<ParentalAssignment> par_ass;
        fit->findAssignments(par_ass);

        set<PhasedGT> father_ass, mother_ass;
        for (set<ParentalAssignment>::const_iterator pi = par_ass.begin();
             pi != par_ass.end(); pi++) {
          father_ass.insert(pi->first);
          mother_ass.insert(pi->second);
        }
        uniquify(father_ass);
        uniquify(mother_ass);
        if (updatePossiblePhases(fit->m_father, father_ass))
          newly_changed.insert(fit->m_father);
        if (updatePossiblePhases(fit->m_mother, mother_ass))
          newly_changed.insert(fit->m_mother);
        for (vector<SPPeelPerson *>::iterator cit = fit->m_children.begin();
             cit != fit->m_children.end(); cit++) {
          set<PhasedGT> child_ass;
          for (set<ParentalAssignment>::const_iterator pi = par_ass.begin();
               pi != par_ass.end(); pi++) {
            const uint64_t pt1 = pi->first.first;
            const uint64_t pt2 =
              (pi->first.first == pi->first.second ||
               (*cit)->m_patbitlevel == Person::FIXEDBIT ?
               pt1 : pi->first.second);
            const uint64_t mt1 = pi->second.first;
            const uint64_t mt2 =
              (pi->second.first == pi->second.second ||
               (*cit)->m_matbitlevel == Person::FIXEDBIT ?
               mt1 : pi->second.second);

            child_ass.insert(PhasedGT(pt1, mt1));
            if (pt1 != pt2) {
              child_ass.insert(PhasedGT(pt2, mt1));
              if (mt1 != mt2) {
                child_ass.insert(PhasedGT(pt1, mt2));
                child_ass.insert(PhasedGT(pt2, mt2));
              }
            } else if (mt1 != mt2)
              child_ass.insert(PhasedGT(pt1, mt2));
          }
          uniquify(child_ass);
          if (updatePossiblePhases(*cit, child_ass))
            newly_changed.insert(*cit);
        }

//        fit->print();
      }
    }

    changed = newly_changed;
  } while (!changed.empty());
}

void print(const set<PhasedGT> &ass) {
  for (set<PhasedGT>::const_iterator ai = ass.begin(); ai != ass.end(); ai++) {
    if (ai != ass.begin()) cout << " ";
    cout << ai->first << "/" << ai->second;
  }
  cout << endl;
}

bool SPPeel::updatePossiblePhases(SPPeelPerson *p, const set<PhasedGT> &ass) {
  // Remove assignements from ass that are not consistent with p's
  // phases
  set<PhasedGT> ca;
  for (set<PhasedGT>::iterator ai = ass.begin(); ai != ass.end(); ai++) {
    bool consistent = false;
    for (map<PhasedGT, ADD>::const_iterator phi = p->m_phases.begin();
         !consistent && phi != p->m_phases.end(); phi++)
      if ((ai->first & phi->first.first) && (ai->second & phi->first.second))
        consistent = true;

    if (consistent) ca.insert(*ai);
  }

  // Remove phases from p that are not consistent with any of ca's
  // assignments
  map<PhasedGT, ADD> new_phases;
  bool changes = false;
  for (map<PhasedGT, ADD>::const_iterator phi = p->m_phases.begin();
       phi != p->m_phases.end(); phi++) {
    bool consistent = false;
    for (set<PhasedGT>::iterator ai = ca.begin();
         !consistent && ai != ca.end(); ai++)
      if ((ai->first & phi->first.first) && (ai->second & phi->first.second))
        consistent = true;

    if (consistent)
      new_phases[phi->first] = phi->second;
    else
      changes = true;
  }
  if (changes)
    p->m_phases = new_phases;

  // Make p's phases finer than ca's assignments
  new_phases.clear();
  for (map<PhasedGT, ADD>::iterator phi = p->m_phases.begin();
       phi != p->m_phases.end(); phi++)
    for (set<PhasedGT>::iterator ai = ca.begin(); ai != ca.end(); ai++) {
      const uint64_t i1 = ai->first & phi->first.first;
      const uint64_t i2 = ai->second & phi->first.second;
      if (i1 && i2) {
        new_phases[PhasedGT(i1, i2)] = phi->second;
        if (i1 != phi->first.first || i2 != phi->first.second)
          changes = true;
      }
    }
  if (new_phases.empty()) {
    print(ass);
    print(ca);
    p->printShort();
  }
  assertinternal(!new_phases.empty());

  if (changes) {
    p->m_phases = new_phases;
    return true;
  } else
    return false;
}
