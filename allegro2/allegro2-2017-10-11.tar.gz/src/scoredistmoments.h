#ifndef _SCOREDISTMOMENTS
#define _SCOREDISTMOMENTS
#include "scoredist.h"
#include "vecutil.h"
#include "utils.h"
#include "CacheManager.hh"

class DdManager;
class DdNode;

class Scoredistmoments : public Scoredist {
  friend class Scoredist;
public:
  virtual ~Scoredistmoments();

  // Function for extracting results
  void getresults(DoubleMat *value, DoubleMat *nullvalue,
                  DoubleMat nullmean, DoubleMat nullsd, Uint deg,
                  DoubleVec minvalue, DoubleVec maxvalue);

protected:
  Scoredistmoments(const string &p, Uint deg);

  class Familydata {
  protected:
    Scoredistmoments *owner;
  public:
    Familydata(Scoredistmoments *own) : owner(own), value(0), nullvalue(0),
      minvalue(0.0), maxvalue(0.0) {
      nullmean = new Double[owner->npos];
      zero(nullmean, owner->npos);
      nullsd = new Double[owner->npos];
      zero(nullsd, owner->npos);
      value = newmatrix<Double>(owner->npos, owner->degree);
      zero(value[0], owner->npos*owner->degree);
      nullvalue = newmatrix<Double>(owner->nnulldist(),
                                    max(Uint(2), owner->degree));
      zero(nullvalue[0], max(Uint(2), owner->degree)*owner->nnulldist());
    }
    Familydata(const Familydata &fd) : owner(fd.owner) {
      nullmean = new Double[owner->npos];
      zero(nullmean, owner->npos);
      nullsd = new Double[owner->npos];
      zero(nullsd, owner->npos);
      value = newmatrix<Double>(owner->npos, owner->degree);
      zero(value[0], owner->npos*owner->degree);
      nullvalue = newmatrix<Double>(owner->nnulldist(),
                                    max(Uint(2), owner->degree));
      zero(nullvalue[0], max(Uint(2), owner->degree)*owner->nnulldist());
      minvalue = fd.minvalue;
      maxvalue = fd.maxvalue;
    }
    ~Familydata() {
      delete [] nullmean;
      delete [] nullsd;
      deletematrix(value);
      deletematrix(nullvalue);
    }
    DoubleVec nullmean;
    DoubleVec nullsd;

    DoubleMat value;
    DoubleMat nullvalue;

    Double minvalue;
    Double maxvalue;
  };
  friend class Scoredistmoments::Familydata;
  typedef vector<Familydata *> Familydatavector;
  Familydatavector familydata;

  // MTBDD utilities
  void setuniformstats(DdNode *S, Familydata *famdat);
  void setuniformmoments(DdNode *S, Familydata *famdat);
  void setmoments(DdNode *S, int S_parent_level, DdNode *pv, double inv_sum_pv,
                  DdManager *mgr, Familydata *famdat, Uint pos,
                  CuddCacheN_D &sum_cache);

  virtual void reset(Uint np);
  virtual void nextfam(bool mtbdd, Uint pos = 0, DoubleVec p0 = 0);
  virtual void set(FloatVec pv, Uint pos);
  virtual void set(ADD &pv, double sum_pv, Uint pos);
  virtual void skipfam();

};

#endif // _SCOREDISTMOMENTS
