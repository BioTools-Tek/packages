#ifndef _SPPEELMARRIAGE_HH
#define _SPPEELMARRIAGE_HH

#include "SPPeelPerson.hh"

#include <vector>
#include <set>
#include <map>

using namespace std;

class SPPeelMarriage {
public:
  SPPeelMarriage(SPPeelPerson *fa = 0, SPPeelPerson *mo = 0) :
    m_father(fa), m_mother(mo) {}

  void addChild(SPPeelPerson *child) {
    m_children.push_back(child);
  }
  bool ripe(SPPeelPerson *&peel_to,
            const vector<SPPeelMarriage> &fam) const;
  bool contains(const SPPeelPerson *per) const;

  void peelTo(SPPeelPerson *peel_to, Cudd &mgr, ADDvector &x, bool final_peel);

  SPPeelPerson *m_father;
  SPPeelPerson *m_mother;
  vector<SPPeelPerson *> m_children;

  static void setAlleleFreq(const FloatVec &allele_freq, Uint nalleles) {
    s_allele_freq.clear();
    s_allele_freq.insert(s_allele_freq.end(),
                         allele_freq, allele_freq + nalleles);
    s_allele_mask_freq.clear();
  }

  unsigned int numAssignments() const {
    set<ParentalAssignment> assignments;
    findAssignments(assignments);
    return assignments.size();
  }
  void findAssignments(set<ParentalAssignment> &assignments) const;

  void print() const;
  void printShort() const;

protected:
  static Doublevector s_allele_freq;
  static map<uint64_t, double> s_allele_mask_freq;

  static double alleleFreq(uint64_t allele) {
    map<uint64_t, double>::const_iterator mit = s_allele_mask_freq.find(allele);
    if (mit != s_allele_mask_freq.end()) return mit->second;
    else {
      double f = .0;
      for (Uint i = 0; i < s_allele_freq.size(); i++)
        if (allele & (uint64_t(1) << i))
          f += s_allele_freq[i];
      s_allele_mask_freq[allele] = f;
      return f;
    }
  }

  static void getPossibleParentAssignments(vector<PhasedGT> &npa,
                                           const PhasedGT &pa,
                                           uint64_t ca, bool bit_fixed);
  static void addAssignment(set<ParentalAssignment> &assignments,
                            const set<ParentalAssignment> &old_ass,
                            uint64_t ca1, uint64_t ca2,
                            bool pat_bit_fixed, bool mat_bit_fixed);

  ADD parentalProb(const PhasedGT &h, const map<PhasedGT, ADD> &phases,
                   Cudd &mgr, bool founder, bool peeling_to_child) const;
  void childProb(map<PhasedGT, ADD> &phases,
                 const ParentalAssignment &pa,
                 const SPPeelPerson *child,
                 ADDvector &x, Cudd &mgr) const;
  ADD getDistribution(const ParentalAssignment &pa,
                      Cudd &mgr, ADDvector &x,
                      const SPPeelPerson *peel_to) const;
  void addParentalPhase(map<PhasedGT, ADD> &phases,
                        const map<PhasedGT, ADD> &old_phases,
                        const PhasedGT &h, ADD prob, Cudd &mgr,
                        bool founder) const;

  static bool childConsistent(uint64_t par, uint64_t child) {
    return par & child;
  }
  static void refineAssignments(set<ParentalAssignment> &assignments);

  void mergeIdentical();

  void hideUninformativeBits();
  void hideUninheritedParent(SPPeelPerson *parent) const;
  void hideUninherited(SPPeelPerson *peel_to);

};

// For debugging purposes
void printVec(const vector<SPPeelMarriage> &v);

#endif // _SPPEELMARRIAGE_HH
