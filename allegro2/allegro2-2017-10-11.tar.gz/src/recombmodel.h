#ifndef _RECOMB
#define _RECOMB
#include "basic.h"
#include "model.h"

class Recombmodel : public Model {
public:
  Recombmodel(const string &of, const string &fof);
  virtual ~Recombmodel() {}
  virtual void print() const;
  virtual void output();
protected:
  Uint numbits;
  int lastcalcmarker; // Last calculated marker no. or - 1

  Double totxover;
  Double totxover_female;
  Double totdistance;
  Double totdistance_female;
  Uint bitsum;
  Uint bitsum_male;
  Uint bitsum_female;

  virtual void lines(ostream &f, Uint ifa, bool famflag);
  virtual void totline(ostream &f, Uint pos);
  virtual void famline(ostream &f, Uint ifa, Uint pos);
  virtual void totheader(ostream &f);
  virtual void famheader(ostream &f);
};

#endif // _RECOMB
