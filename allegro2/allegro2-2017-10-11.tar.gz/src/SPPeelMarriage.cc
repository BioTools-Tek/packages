#include "SPPeelMarriage.hh"
#include "SW.hh"
#include "family.h"

Doublevector SPPeelMarriage::s_allele_freq;
map<uint64_t, double> SPPeelMarriage::s_allele_mask_freq;

bool SPPeelMarriage::ripe(SPPeelPerson *&peel_to,
                          const vector<SPPeelMarriage> &fam) const {
  unsigned int num_non_leaves = 0;
  peel_to = m_father;
  if (!m_father->isLeaf(fam)) {
    num_non_leaves++;
    peel_to = m_father;
  }
  if (!m_mother->isLeaf(fam)) {
    num_non_leaves++;
    peel_to = m_mother;
  }
  for (unsigned int c = 0; num_non_leaves < 2 && c < m_children.size(); c++)
    if (!m_children[c]->isLeaf(fam)) {
      num_non_leaves++;
      peel_to = m_children[c];
    }

  return num_non_leaves < 2;
}

bool SPPeelMarriage::contains(const SPPeelPerson *per) const {
  if (m_father == per || m_mother == per) return true;
  else {
    for (unsigned int c = 0; c < m_children.size(); c++)
      if (m_children[c] == per) return true;
    return false;
  }
}

void SPPeelMarriage::getPossibleParentAssignments(vector<PhasedGT> &npa,
                                                  const PhasedGT &pa,
                                                  uint64_t ca, bool bit_fixed) {
  if (ca == UNINFORMATIVE) npa.push_back(pa);
  else {
    if (pa.first & ca)
      npa.push_back(PhasedGT(pa.first & ca, pa.second));
    if (!bit_fixed && (pa.second & ca))
      npa.push_back(PhasedGT(pa.first, pa.second & ca));
  }
}

void SPPeelMarriage::addAssignment(set<ParentalAssignment> &assignments,
                                   const set<ParentalAssignment> &old_ass,
                                   uint64_t ca1, uint64_t ca2,
                                   bool pat_bit_fixed, bool mat_bit_fixed) {
  for (set<ParentalAssignment>::const_iterator i = old_ass.begin();
       i != old_ass.end(); i++) {
    const PhasedGT &fa = i->first;
    const PhasedGT &mo = i->second;

    vector<PhasedGT> nfa, nmo;
    getPossibleParentAssignments(nfa, fa, ca1, pat_bit_fixed);
    getPossibleParentAssignments(nmo, mo, ca2, mat_bit_fixed);

    for (unsigned int f = 0; f < nfa.size(); f++)
      for (unsigned int m = 0; m < nmo.size(); m++)
        assignments.insert(ParentalAssignment(nfa[f], nmo[m]));
  }
  if (assignments.empty()) return;

  bool overlap_found;
  do {
    overlap_found = false;
    for (set<ParentalAssignment>::iterator i = assignments.begin();
         i != assignments.end(); i++) {
      for (set<ParentalAssignment>::iterator j = assignments.begin();
           j != i; j++)
        if (overlap(*i, *j)) {
          const ParentalAssignment ia = *i;
          const ParentalAssignment ja = *j;
          assertinternal(ia != ja);
          overlap_found = true;
          const ParentalAssignment inter = intersection(ia, ja);
          assertinternal(inter.first.first != 0 && inter.first.second != 0 &&
                 inter.second.first != 0 && inter.second.second != 0);
          const ParentalAssignment i_rest = subtract(ia, inter);
          const ParentalAssignment j_rest = subtract(ja, inter);
          insertExtra(assignments, inter, i_rest, ia);
          insertExtra(assignments, inter, j_rest, ja);
          set<ParentalAssignment>::iterator ii =
            find(assignments.begin(), assignments.end(), ia);
          assertinternal(ii != assignments.end());
          assignments.erase(ii);
          set<ParentalAssignment>::iterator jj =
            find(assignments.begin(), assignments.end(), ja);
          assertinternal(jj != assignments.end());
          assignments.erase(jj);
          assignments.insert(inter);
          break;
        }
      if (overlap_found)
        break;
    }
  } while (overlap_found);
  assertinternal(!assignments.empty());

  for (set<ParentalAssignment>::iterator i = assignments.begin();
       i != assignments.end(); i++)
    for (set<ParentalAssignment>::iterator j = assignments.begin(); j != i; j++)
      if (overlap(*i, *j))
        cerr << "found overlapping assignments" << endl;
}

ADD SPPeelMarriage::parentalProb(const PhasedGT &h,
                                 const map<PhasedGT, ADD> &phases,
                                 Cudd &mgr, bool founder,
                                 bool peeling_to_child) const {
  ADD res = mgr.addZero();
  for (map<PhasedGT, ADD>::const_iterator it = phases.begin();
       it != phases.end(); it++) {
    const PhasedGT &k = it->first;
    if ((h.first & k.first) && (h.second & k.second)) {
      double mult = 1.;
      if (founder)
        mult *= alleleFreq(h.first & k.first)*alleleFreq(h.second & k.second);
      else if (peeling_to_child) {
        if ((h.first & k.first) != k.first)
          mult *= alleleFreq(h.first & k.first)/alleleFreq(k.first);
        if ((h.second & k.second) != k.second)
          mult *= alleleFreq(h.second & k.second)/alleleFreq(k.second);
      }

      ADD r = it->second;
      if (mult != 1.) r *= mgr.constant(mult);
      res += r;
    }
  }
  return res;
}

void addPhase(map<PhasedGT, ADD> &phases, const PhasedGT &h, ADD prob) {
  map<PhasedGT, ADD>::iterator it = phases.find(h);
  if (it == phases.end())
    phases[h] = prob;
  else
    it->second += prob;
}

void SPPeelMarriage::childProb(map<PhasedGT, ADD> &phases,
                               const ParentalAssignment &pa,
                               const SPPeelPerson *child,
                               ADDvector &x, Cudd &mgr) const {
  const unsigned int patlevel = child->m_patbitlevel;
  const unsigned int matlevel = child->m_matbitlevel;
  for (map<PhasedGT, ADD>::const_iterator it = child->m_phases.begin();
       it != child->m_phases.end(); it++) {
    const PhasedGT &ch = it->first;

    bool p00, p01, p10, p11;
    p00 = p01 = p10 = p11 = false;
    if (childConsistent(pa.first.first, ch.first) &&
        childConsistent(pa.second.first, ch.second))
      p00 = true;
    if (patlevel != Person::FIXEDBIT &&
        childConsistent(pa.first.second, ch.first) &&
        childConsistent(pa.second.first, ch.second))
      p10 = true;
    if (matlevel != Person::FIXEDBIT &&
        childConsistent(pa.first.first, ch.first) &&
        childConsistent(pa.second.second, ch.second))
      p01 = true;
    if (patlevel != Person::FIXEDBIT && matlevel != Person::FIXEDBIT &&
        childConsistent(pa.first.second, ch.first) &&
        childConsistent(pa.second.second, ch.second))
      p11 = true;

    if (patlevel == Person::FIXEDBIT && matlevel == Person::FIXEDBIT) {
      if (p00)
        addPhase(phases, PhasedGT(pa.first.first, pa.second.first),
                 it->second);
    } else if (matlevel == Person::FIXEDBIT) {
      if (p00)
        addPhase(phases, PhasedGT(pa.first.first, pa.second.first),
                 x[patlevel].Ite(mgr.addZero(), it->second));
      if (p10)
        addPhase(phases, PhasedGT(pa.first.second, pa.second.first),
                 x[patlevel].Ite(it->second, mgr.addZero()));
    } else if (patlevel == Person::FIXEDBIT) {
      if (p00)
        addPhase(phases, PhasedGT(pa.first.first, pa.second.first),
                 x[matlevel].Ite(mgr.addZero(), it->second));
      if (p01)
        addPhase(phases, PhasedGT(pa.first.first, pa.second.second),
                 x[matlevel].Ite(it->second, mgr.addZero()));
    } else {
      if (p00)
        addPhase(phases, PhasedGT(pa.first.first, pa.second.first),
                 x[patlevel].Ite(mgr.addZero(),
                                 x[matlevel].Ite(mgr.addZero(), it->second)));
      if (p10)
        addPhase(phases, PhasedGT(pa.first.second, pa.second.first),
                 x[patlevel].Ite(x[matlevel].Ite(mgr.addZero(), it->second),
                                 mgr.addZero()));
      if (p01)
        addPhase(phases, PhasedGT(pa.first.first, pa.second.second),
                 x[patlevel].Ite(mgr.addZero(),
                                 x[matlevel].Ite(it->second, mgr.addZero())));
      if (p11)
        addPhase(phases, PhasedGT(pa.first.second, pa.second.second),
                 x[patlevel].Ite(x[matlevel].Ite(it->second, mgr.addZero()),
                                 mgr.addZero()));
    }
  }
}

ADD SPPeelMarriage::getDistribution(const ParentalAssignment &pa,
                                    Cudd &mgr, ADDvector &x,
                                    const SPPeelPerson *peel_to) const {
  ADD res = mgr.addOne();
  const bool peeling_to_child = peel_to == m_father || peel_to == m_mother;
  if (m_father != peel_to)
    res *= parentalProb(pa.first, m_father->m_phases, mgr,
                        m_father->isFounder(), peeling_to_child);
  if (m_mother != peel_to)
    res *= parentalProb(pa.second, m_mother->m_phases, mgr,
                        m_mother->isFounder(), peeling_to_child);
  assertinternal(res != mgr.addZero());

  for (unsigned int c = 0; c < m_children.size(); c++) {
    const SPPeelPerson *child = m_children[c];
    if (child == peel_to) continue;
    ADD ch_res = mgr.addZero();
    map<PhasedGT, ADD> possible_phases;
    childProb(possible_phases, pa, child, x, mgr);
    for (map<PhasedGT, ADD>::const_iterator it = possible_phases.begin();
         it != possible_phases.end(); it++)
      ch_res += it->second;
    if (ch_res == mgr.addZero())
      return mgr.addZero();
    else
      res *= ch_res;
  }
  return res;
}

void SPPeelMarriage::addParentalPhase(map<PhasedGT, ADD> &phases,
                                      const map<PhasedGT, ADD> &old_phases,
                                      const PhasedGT &h, ADD prob, Cudd &mgr,
                                      bool founder) const {
  ADD pr = prob;
  pr *= parentalProb(h, old_phases, mgr, founder, false);
  addPhase(phases, h, pr);
}

void SPPeelMarriage::
findAssignments(set<ParentalAssignment> &assignments) const {
  // Incorporate phase information on parents
  vector<PhasedGT> father_assignment;
  // father
  SW_START("create_assingments");
  assertinternal(!m_father->m_phases.empty());
  for (map<PhasedGT, ADD>::const_iterator it = m_father->m_phases.begin();
       it != m_father->m_phases.end(); it++)
    father_assignment.push_back(it->first);
  // mother
  for (map<PhasedGT, ADD>::const_iterator it = m_mother->m_phases.begin();
       it != m_mother->m_phases.end(); it++)
    for (unsigned int as = 0; as < father_assignment.size(); as++)
      assignments.insert(ParentalAssignment(father_assignment[as], it->first));

  // finally add children with extra phase information
  for (unsigned int c = 0; c < m_children.size(); c++) {
    set<ParentalAssignment> old_ass(assignments);
    assignments.clear();
    const unsigned int patlevel = m_children[c]->m_patbitlevel;
    const unsigned int matlevel = m_children[c]->m_matbitlevel;
    for (map<PhasedGT, ADD>::const_iterator
           it = m_children[c]->m_phases.begin();
         it != m_children[c]->m_phases.end(); it++)
      addAssignment(assignments, old_ass, it->first.first, it->first.second,
                    patlevel == Person::FIXEDBIT, matlevel == Person::FIXEDBIT);
  }
  SW_STOP("create_assingments");
}

void printAssignments(const set<ParentalAssignment> &assignments) {
  cout << "#assignments = " << assignments.size() << endl;
  for (set<ParentalAssignment>::const_iterator it = assignments.begin();
       it != assignments.end(); it++)
    cout << it->first.first << "\t" << it->first.second << "\t"
         << it->second.first << "\t" << it->second.second << endl;
}

void printPhases(map<PhasedGT, ADD> &phases) {
  for (map<PhasedGT, ADD>::iterator i = phases.begin();
       i != phases.end(); i++) {
    cout << i->first.first << " " << i->first.second;
    i->second.print(2, 2);
  }
}

void SPPeelMarriage::mergeIdentical() {
  m_father->mergeIdentical();
  m_mother->mergeIdentical();
  for (vector<SPPeelPerson *>::const_iterator ci = m_children.begin();
       ci != m_children.end(); ci++)
    (*ci)->mergeIdentical();
}

void SPPeelMarriage::refineAssignments(set<ParentalAssignment> &assignments) {
  set<ParentalAssignment> ass;
  for (set<ParentalAssignment>::iterator i = assignments.begin();
       i != assignments.end(); i++) {
    const uint64_t inter = i->first.first & i->first.second;
    if (inter && i->first.first != i->first.second) {
      ParentalAssignment pa(*i);
      pa.first = PhasedGT(inter, inter);
      ass.insert(pa);
      const uint64_t rem1 = i->first.first & (~inter);
      const uint64_t rem2 = i->first.second & (~inter);
      if (rem1) {
        pa.first = PhasedGT(rem1, inter);
        ass.insert(pa);
        if (rem2) {
          pa.first = PhasedGT(rem1, rem2);
          ass.insert(pa);
        }
      }
      if (rem2) {
        pa.first = PhasedGT(inter, rem2);
        ass.insert(pa);
      }
    } else
      ass.insert(*i);
  }

  assignments.clear();
  for (set<ParentalAssignment>::iterator i = ass.begin();
       i != ass.end(); i++) {
    const uint64_t inter = i->second.first & i->second.second;
    if (inter && i->second.first != i->second.second) {
      ParentalAssignment pa(*i);
      pa.second = PhasedGT(inter, inter);
      assignments.insert(pa);
      const uint64_t rem1 = i->second.first & (~inter);
      const uint64_t rem2 = i->second.second & (~inter);
      if (rem1) {
        pa.second = PhasedGT(rem1, inter);
        assignments.insert(pa);
        if (rem2) {
          pa.second = PhasedGT(rem1, rem2);
          assignments.insert(pa);
        }
      }
      if (rem2) {
        pa.second = PhasedGT(inter, rem2);
        assignments.insert(pa);
      }
    } else
      assignments.insert(*i);
  }

  assertinternal(!assignments.empty());
  for (set<ParentalAssignment>::iterator i = assignments.begin();
       i != assignments.end(); i++) {
    assertinternal(i->first.first == i->first.second ||
                   !(i->first.first & i->first.second));
    assertinternal(i->second.first == i->second.second ||
                   !(i->second.first & i->second.second));
  }
}

void SPPeelMarriage::hideUninformativeBits() {
  for (vector<SPPeelPerson *>::const_iterator ci = m_children.begin();
       ci != m_children.end(); ci++)
    (*ci)->hideUninformativeBit();
}

void SPPeelMarriage::hideUninheritedParent(SPPeelPerson *parent) const {
  bool inherited = false;
  for (vector<SPPeelPerson *>::const_iterator ci = m_children.begin();
       !inherited && ci != m_children.end(); ci++)
    if ((parent == m_father ? (*ci)->m_patbitlevel :
         (*ci)->m_matbitlevel) != Person::FIXEDBIT)
      inherited = true;
  if (!inherited) {
    map<PhasedGT, ADD> new_phases;
    for (map<PhasedGT, ADD>::const_iterator phi = parent->m_phases.begin();
         phi != parent->m_phases.end(); phi++) {
      PhasedGT h(phi->first.first, UNINFORMATIVE);
      map<PhasedGT, ADD>::iterator nphi = new_phases.find(h);
      if (nphi == new_phases.end())
        new_phases[h] = phi->second;
      else
        nphi->second += phi->second;
    }

    parent->m_phases = new_phases;
  }
}

void SPPeelMarriage::hideUninherited(SPPeelPerson *peel_to) {
  if (m_father != peel_to)
    hideUninheritedParent(m_father);
  if (m_mother != peel_to)
    hideUninheritedParent(m_mother);
}

void SPPeelMarriage::peelTo(SPPeelPerson *peel_to, Cudd &mgr, ADDvector &x,
                            bool final_peel) {
  // Merge identical haplotypes
  mergeIdentical();

  // Hide uninformative bits
  hideUninformativeBits();

  // Hide uninherited founder haplotypes (in other ppl than peel_to)
  hideUninherited(peel_to);

  // Create parental assignments
  set<ParentalAssignment> assignments;
  findAssignments(assignments);
  refineAssignments(assignments);

  assertinternal(!assignments.empty());

  // Handle all possible parental assignments
  map<PhasedGT, ADD> possible_phases;
  for (set<ParentalAssignment>::const_iterator it = assignments.begin();
       it != assignments.end(); it++) {
    // Create DD
    SW_START("getDistribution");
    ADD prob = getDistribution(*it, mgr, x, peel_to);
    SW_STOP("getDistribution");
//    prob.print(2, 2);
    // Pass result on
    SW_START("addPhase");
    if (peel_to == m_father)
      addParentalPhase(possible_phases, m_father->m_phases, it->first,
                       prob, mgr, m_father->isFounder() && final_peel);
    else if (peel_to == m_mother)
      addParentalPhase(possible_phases, m_mother->m_phases, it->second,
                       prob, mgr, m_mother->isFounder() && final_peel);
    else {
      map<PhasedGT, ADD> child_phases;
      childProb(child_phases, *it, peel_to, x, mgr);
      for (map<PhasedGT, ADD>::const_iterator it = child_phases.begin();
           it != child_phases.end(); it++) {
        ADD pr = it->second;
        pr *= prob;
        addPhase(possible_phases, it->first, pr);
      }
    }
    SW_STOP("addPhase");
  }
  assertinternal(!possible_phases.empty());
  peel_to->m_phases = possible_phases;
}

void SPPeelMarriage::print() const {
  m_father->print();
  m_mother->print();
  for (vector<SPPeelPerson *>::const_iterator cit = m_children.begin();
       cit != m_children.end(); cit++)
    (*cit)->print();
}

void SPPeelMarriage::printShort() const {
  m_father->printShort();
  m_mother->printShort();
  for (vector<SPPeelPerson *>::const_iterator cit = m_children.begin();
       cit != m_children.end(); cit++)
    (*cit)->printShort();
}

void printVec(const vector<SPPeelMarriage> &v) {
  for (vector<SPPeelMarriage>::const_iterator vi = v.begin(); vi != v.end();
       vi++) {
    vi->printShort();
    cout << endl;
  }
}
