#include "files.h"
#include "haplomodel.h"
#include "haplodist.h"

Haplomodel::Haplomodel(const string &hapf, const string &inhf,
                       const string &ihapf, const string &fndrf) :
    Model("hpt") {
  distribution = Haplodist::gethaplodist(hapf, inhf, ihapf, fndrf);
}

void Haplomodel::print() const {
  ((Haplodist *)distribution)->print();
}
