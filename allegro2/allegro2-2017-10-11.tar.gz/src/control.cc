#include "files.h"
#include "options.h"
#include "asmmodel.h"
#include "asmpoly.h"
#include "asmexp.h"
#include "control.h"
#include "simulation.h"
#include "matrix.h"
#include "outputld.h"
#include "vecutil.h"
#include "probability.h"
#include "utils.h"
#include "calcscore.h"
#include "fmtout.h"
#include "distribution.h"
#include "haldane.h"
#include "calcviterbi.h"
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include "family.h"
#include "Sweeper.hh"
#include "SPPeel.hh"
#include "SPGraph.hh"
#include "cuddutil.h"
#include "montecarlo.h"
#include "recombdist.h"
#include "LDSP.hh"

#include <iterator>

#include "SW.hh"
#ifdef STOPWATCH
StopWatch stop_watch;
#endif // STOPWATCH

Control *control = 0;

const string plurals(Uint x) {return x > 1 ? "s" : "";}

Control::Control() :
    first(0), firstorig(0), maxnumiv(0), vector_maxnumiv(0),
    swapdircreated(false) {
  assertinternal(options != 0);
  if (options->prefile.size() > 0 && options->datfile.size() > 0) {
    // Read dat-file and pre-file
    inputld();
  }
  else if (options->prefile.size() > 0 && options->genotypefile.assigned() &&
           options->mapfile.assigned() && options->freqfile.assigned()) {
    inputdecode();
  }
  else {
    assertinternal(false);
  }
  map.readhaplofreqs();
}

Control::~Control() {
  deletelist(firstorig);
}

Float Control::countvecsneeded() {
  Double count = 0.0;
  count += Calcscore::countvecsneeded(first, maxnumiv);
  return count;
}


void Control::probs() {
  analyzechromosome();
  Distribution::cleanup();
  char str[100];                                //MCT, unlikely but ya know -- future
  strcpy(str, "rm -rf ");                       //
  strcat(str,options->swapdirname.c_str());     //
  system(str);                                  //
}

void Control::analyzechromosome() {
  createswapdir();

  Distribution::setnullconstant(!options->pseudoautosomal);
  setupfamilies();
  Output::map = &map;

  if (options->chromosome != "") {
    writepre("pre", first, &map);
    writedat("dat", &map);
  }
  message("");

  // Assigns vector_maxnumiv to numiv, and maxnumiv
  options->mtbddthreshold = 45;
  findnums();

  cerr << "\rbegin reset map" << flush;
  // Initialize model calculations (do not change this order)
  Distribution::reset(map);

  cerr << "\rbegin options" << flush;

  // Open file for uninformative markers
  if (options->uninformative.assigned()) options->uninformative.open();
  // Open file for inconsistent markers
  if (options->inconsistent.assigned()) options->inconsistent.open();
  // Open file for likelihood function
  if (options->likelihoodfile.assigned()) options->likelihoodfile.open();

  if (options->rfile.assigned()) options->rfile.open();
  if (options->pfile.assigned()) options->pfile.open();

  cerr << "\rstarting mtbddpass" << flush; //Last message here -- 21 bits
  mtbddpass();

  cerr << "\rStarting setup " << flush; //Last message here -- 19 bits
  bool lowmem = Calc::setup(first, vector_maxnumiv);
  cerr << "\rcalc setted" << flush;   //Last message here -- 17-bits

  // Prememory allocation option
  cerr << "\rvectorpass" << flush;
  vectorpass(lowmem);

  cleanupswapdir();

  message("");
  message("All families processed");
  message("");

  options->uninformative.close();
  options->inconsistent.close();
  options->likelihoodfile.close();

  // Open file for delta bounds
  if (options->deltaboundfile.assigned()) options->deltaboundfile.open();
  Model::modeloutput();
  options->deltaboundfile.close();

  SW_REPORT(cout);
}

void Control::vectorpass(bool lowmem) {
  Uint nq, nlq, nlqhat;
  nq = nlq = nlqhat = 0;
  FloatVec lqbuf =  0;
  FloatVec lqhatbuf = 0;
  FloatVec qbuf = 0;
  FloatVec rqhat = 0;
  Floatmatrix *q = 0, *lq = 0, *lqhat = 0;
  DoubleVec simbuf = 0;
  q = lq = lqhat = 0;

  Double count = countvecsneeded() + 1.0;

  if(lowmem){
      options->maxmem = 100;
      options->swap = true;
      mtbddpass();  //-- XXX testing
  }
  else{
      options->swap = false;
  }
  if (options->calcmpt || options->dohaplo || options->doforcedrecomb) {
    string mesg;
    bool recalcallowed = true;//options->markerdistzero || options->chromolist == 0;
    Double allfull = 0;   // Number of vecs needed to be stored in memory
    Double recalc1full = 0; // Number of vecs with some recalculation
    Double recalc2full = 0; // Number of vecs with more recalculation
    Double allone = count;
    Double recalc1one = count;
    Double recalc2one = count;
    Double swapone = count;
    if (options->calcmpt) {
      allfull = 3.0;
      recalc1full = 2.0;
      recalc2full = 1.0;
      recalc1one += 1;
      recalc2one += 2;
      swapone = 3;
      if (options->dohaplo && options->doforcedrecomb) {
        allfull += .5;
        recalc1full += .5;
        recalc2full += .5;
        swapone += 1;
      }
      else if (options->dohaplo || options->doforcedrecomb) swapone += .5;
    }
    else if (options->dohaplo && options->doforcedrecomb) {
      recalc2full = recalc1full = allfull = 1;
      swapone += 1;
    }
    else if (options->dohaplo || options->doforcedrecomb) {
      recalc2full = recalc1full = allfull = .5;
      swapone = .5;
    }
    message("Prememory alloc stage");
    cerr << "\n   options [recalcallowed: " << recalcallowed << "]," << flush;
//    cerr << "[calcmpt: " << options->calcmpt << "]" << flush;
    cerr << "[dohaplo: " << options->dohaplo << "]" << flush;
//    cerr << "[doforcedrecomb: " << options->doforcedrecomb << "]" << flush;
    cerr << "[maxmem: " << options->maxmem << "]" << flush;
    cerr << "[maxmem<<20: " << Double(options->maxmem)*(1<<20) << "]" << flush;
    cerr << "[vectormaxnumiv: " << vector_maxnumiv << "]" << flush;
//    cerr << "[vectormaxnumiv*other: " << Double(vector_maxnumiv)*Double(allfull*map.loci.size() +
//                                                                                  allone)*sizeof(Float)
    cerr << "\n" << endl;



    Double vecsneeded = 3.0;
    if (Double(options->maxmem)*(1 << 20) >=
            Double(vector_maxnumiv)*Double(allfull*map.loci.size() +
                                           allone)*sizeof(Float)) {
        // Plenty of memory
        nq = nlq = nlqhat = vector_maxnumiv*map.loci.size();
        vecsneeded = allfull*map.loci.size() + allone;
        mesg = "Keeping all calculations in memory";
    }
    else if (Double(options->maxmem)*(1 << 20) >=
             Double(vector_maxnumiv)*Double(recalc1full*map.loci.size() +
                                            recalc1one)*sizeof(Float)) {
        // Need to recalculate lq from lqhat
        nq = nlqhat = vector_maxnumiv*map.loci.size();
        nlq = vector_maxnumiv;
        vecsneeded = recalc1full*map.loci.size() + recalc1one;
        mesg = "Recalculating lq, keeping other in memory";
    }
    else if (recalcallowed && Double(options->maxmem)*(1 << 20) >=
             Double(vector_maxnumiv)*Double(recalc2full*map.loci.size() +
                                            recalc2one)*sizeof(Float)) {
        // Need to recalculate lq from lqhat and q from scratch
        nlqhat = vector_maxnumiv*map.loci.size();
        nq = nlq = vector_maxnumiv;
        vecsneeded = recalc2full*map.loci.size() + recalc2one;
        mesg = "Recalculating lq and q, keeping other in memory";
    }
    else if (recalcallowed && Double(options->maxmem)*(1 << 20) >=
             Double(vector_maxnumiv)*(swapone)*sizeof(Float)) {
        // Need to recalculate lq and q, and write lqhat to disk
        nq = nlq = nlqhat = vector_maxnumiv;
        vecsneeded = swapone;
        mesg = "Recalculating lq and q, swapping lqhat to disk";
        options->swap = true;
    }
    else
        fatal(string("Allegro does not have permission to allocate enough ") +
              "memory.\nRequires at least " +
              Double(vector_maxnumiv)*(vecsneeded)*sizeof(Float)/Double(1 << 20) +
              " bytes, but MAXMEMORY is set to " + options->maxmem + "\n");

    message(mesg + " (~" + ceil(Double(vector_maxnumiv)*vecsneeded*
                                sizeof(Float)/(1024.0*1024.0)) + "Mb)");
//    exit(0);

    if (options->estimatememory)
        return;
    if (options->swap)
        createswapdir();
    if (options->calcmpt) {
        lqhatbuf = new Float[nlqhat];
        Calcviterbi::registerbuf(IVVec(lqhatbuf + nlqhat/2), nlqhat);
        lqbuf = new Float[nlq];
        rqhat = new Float[vector_maxnumiv];
        lq = new Floatmatrix(lqbuf, nlq, Floatmatrix::RECALCLQ);
        lqhat = new Floatmatrix(lqhatbuf, nlqhat, options->swapdirname, "lqhat.");
    }
  }
  else {
    if (Float(options->maxmem)*(1 << 20) <
        Float(vector_maxnumiv)*(1 + count)*sizeof(Float))
      fatal(string("Allegro does not have permission to allocate enough ") +
            "memory.\nRequires at least " +
            vector_maxnumiv*(1 + count)*sizeof(Float)/Double(1 << 20) +
            " bytes, but maxmem is set to " + options->maxmem + "\n");
    nq = vector_maxnumiv;
    if (options->pseudoautosomal)
      rqhat = new Float[vector_maxnumiv];
  }
  qbuf = new Float[nq];

  q = new Floatmatrix(qbuf, nq, Floatmatrix::RECALCQ);
  // Initialize simulations
  if (options->simulation) {
    simbuf = new Double[vector_maxnumiv];
    options->simulation->setbuf(simbuf);
  }

  for (Family *fam = first; fam != 0; fam = fam->next) {
    if (fam->numbits <= options->mtbddthreshold) {
      message(string("Processing family ") + fam->id + " (" +
              fam->numbits + " bit" + plurals(fam->numbits) + ")");

      cerr << "\rvectorpass: Creating masks                      " << flush;
      fam->createmasks();

      cerr << "\rvectorpass: making Probability                  " << flush;
      Probability prob(q, lq, lqhat, rqhat, fam, &map);

      cerr << "\rvectorpass: setting graph                         " << flush;
      Distribution::setGraph(prob.graph);

      // Perform simulations
      if (options->simulation != 0) {
        options->simulation->simulate(fam, map);
        continue;
      }

      cerr << "\rvectorpass: making FamilyMap                    " << flush;
      FamilyMap fm(fam->id, &map);

      if (options->montecarlo) Montecarlo::fm = &fm;
      cerr << "\rvectorpass: passed montecarlo options           " << flush;

      // Calculate Likelihood and scorefunctions
      if (!Distribution::nextfam(prob, fam, qbuf)) {
          cerr << "\rvectorpass: no next fam                     " << flush;
          warning("Family '" + fam->id +
                  "' is uninformative for all purposes and will be skipped");
          continue;
      }
      cerr << "\rvectorpass: next fam avail                      " << flush;

      // Calculate single locus probabilities and fromleft (i.e. find l and q)
      cerr << "\rvectorpass: going from left                         \n" << flush;
      if (fromleft(fam, prob, fm, q, lq, lqhat, rqhat)) {
          // 'Fromright' and multipoint analysis
          if (options->calcmpt || options->dohaplo || options->doforcedrecomb){
              cerr << "\nvectorpass: going from right\n" << flush;
              fromright(prob, fm, q, lq, fam);
          }
          cerr << "\nvectorpass: deleting founder graph" << flush;
          prob.deletefoundergraph();
      }
      else {
          cerr << "\rvectorpass: doing copyval" << flush;
          // Family contains no informative markers so we must pass uniform to
          // all distributions that are still interested
          copyval(qbuf, 1.0/Double(fam->numiv()), fam->numiv());
          if (options->calcmpt)
              for (Uint pos = 0; pos < map.positions.size(); pos++)
                  Distribution::set(qbuf, pos, "mpt");
          if (options->dohaplo)
              for (int gam = map.loci.size() - 1; gam >= 0; gam--)
                  Distribution::set(qbuf, gam, "hpt");
          if (options->doforcedrecomb)
              for (int gam = map.loci.size() - 1; gam >= 0; gam--)
                  Distribution::set(qbuf, gam, "fpt");
          if (options->montecarlo) {
              Distribution::set(qbuf, 0, "cpt");
              Distribution::set(qbuf, 0, "cpt");
          }
      }
    }
  }

  delete [] simbuf;
  delete q;
  delete [] qbuf;
  if (options->calcmpt) {
    delete lq;
    delete lqhat;
    delete [] lqbuf;
    delete [] lqhatbuf;
  }
  delete [] rqhat;

  if (options->rfile) options->rfile.close();
  if (options->pfile) options->pfile.close();
}

void Control::mtbddpass() {
    cerr << "\rmtbddpass: started" << flush;
    for (Family *fam = first; fam != 0; fam = fam->next) {
        cerr << "\rmtbddpass fam: " << fam << flush;
        cerr << "\r, fam_numbits=" << fam->numbits << ", options_mtbddtres=" << options->mtbddthreshold << flush;

        if (fam->numbits > options->mtbddthreshold) {
            message(string("Processing family ") + fam->id + " (" +
                    fam->numbits + " bit" + plurals(fam->numbits) + ")");

            fam->createmasks();

            // Perform simulations
            if (options->simulation != 0) {
                options->simulation->simulate(fam, map);
                continue;
            }


            Cudd mgr(fam->numbits, 0, 256, 262144, options->maxmem*(1 << 20)/8);
            mgr.SetMinHit(1);
            mgr.SetEpsilon(.0);
            mgr.SetRoundingPrec(options->mtbddrounding);
            //      mgr.DisableGarbageCollection();

            if (!Distribution::nextfam(fam, mgr)) {
                Calc::cleanupS();
                warning("Family '" + fam->id +
                        "' is uninformative for all purposes and will be skipped");
                continue;
            }

            FamilyMap fm(fam->id, &map);

//            message("Get here well enough1?\n");

            ADDvector sp(map.loci.size());
  //          message("Get here well enough1.5?\n");

            if (dospt(fm, sp, mgr, fam)) {                //21 -bits gets verbose dospt
    //            message("Get here well enough2?\n");

                if (options->calcmpt){
      //              message("Get here well enough3?\n");
                    dompt(fm, sp, mgr, fam);
                }
            }
            else {
        //        message("Get here well enough4?\n");

                // Family contains no informative markers so we must pass uniform to
                // all distributions that are still interested
                ADD unif(mgr.constant(1./Double(fam->numiv())));
  //              message("Get here well enough5?\n");
                if (options->calcmpt){
                    message("Get here well enough6?\n");
                    for (Uint pos = 0; pos < map.positions.size(); pos++){
                        Distribution::set(unif, pos, "mpt");
                    }
                }
                if (options->dohaplo){
        //            message("Get here well enough7?\n");
                    for (int gam = map.loci.size() - 1; gam >= 0; gam--){
                        Distribution::set(unif, gam, "hpt");
                    }
                }
                if (options->doforcedrecomb){
       //             message("Get here well enough8?\n");
                    for (int gam = map.loci.size() - 1; gam >= 0; gam--){
                        Distribution::set(unif, gam, "fpt");
                    }
                }
                if (options->montecarlo) {
     //               message("Get here well enough9?\n");
                    Distribution::set(unif, 0, "cpt");
                    Distribution::set(unif, 0, "cpt");
                }
    //            message("Get here well enough10?\n");
            }
  //          message("Get here well enough?\n");
//            exit(0);
            Calc::cleanupS();
        }
    }
}

bool Control::fromleft(Family *f, Probability &prob, FamilyMap &fm,
                       Floatmatrix *q, Floatmatrix *lq, Floatmatrix *lqhat,
                       FloatVec tmpq) {
  if (!options->calcspt) return true;
  int lastinformative = options->calcmpt ? FamilyMap::NOLEFTMARKER : 0;

  Float L = 0.0; // The likelihood function value for this family
  if (options->lfile.assigned()) options->lfile.open();
  for (Uint gam = 0; gam < map.loci.size(); gam++) {
    FloatVec curq = q->getrow(gam, false);
    cerr << "\rGam Swap: " << gam << "  " << flush;

    L += log(prob.fromhere(&fm, gam, curq));
    if (gam == 0) L -= log(double(f->numiv()));

    if (options->pseudoautosomal) {
      f->pseudonull(tmpq);
      fft(tmpq, tmpq, f->numiv(), f->numbits);
      prob.Ttrans(tmpq, tmpq,
                  recombfraccent(map.positions[gam].positionMale()),
                  recombfraccent(map.positions[gam].positionFemale()));
      fft(tmpq, tmpq, f->numiv(), f->numbits);
      elemprod(tmpq, curq, tmpq, f->numiv());
      assertinternal(normal<Float>(tmpq, f->numiv()) != 0);
      Distribution::set(tmpq, gam, "spt");
    }
    else
      Distribution::set(curq, gam, "spt");
    if (options->calcmpt && fm.informative[gam]) {
      if (lastinformative == FamilyMap::NOLEFTMARKER) {
        // This is the leftmost informative marker
        if (options->pseudoautosomal) {
          f->pseudonull(tmpq);
          fft(tmpq, tmpq, f->numiv(), f->numbits);
          prob.Ttrans(tmpq, tmpq,
                      recombfraccent(map.positions[gam].positionMale()),
                      recombfraccent(map.positions[gam].positionFemale()));
          fft(tmpq, tmpq, f->numiv(), f->numbits);
          elemprod(lq->getrow(gam, false), q->getrow(gam, true), tmpq,
                   f->numiv());
          fft(lqhat->getrow(gam, false), lq->getrow(gam, true), f->numiv(),
              f->numbits);
        }
        else {
          copyvec(lq->getrow(gam, false), q->getrow(gam, true), f->numiv());
          fft(lqhat->getrow(gam, false), lq->getrow(gam, true), f->numiv(),
              f->numbits);
        }
      }
      else { // There are informative markers left of this one
        prob.findlq(lqhat->getrow(lastinformative, true),
                    lqhat->getrow(gam, false), lq->getrow(gam, false),
                    q->getrow(gam, true), L, fm.theta[lastinformative],
                    fm.theta_female[lastinformative], gam);
        L -= log(double(f->numiv())); // fft normalizing constant
        L += f->numfc*log(1 - fm.theta[lastinformative]);
      }
      lqhat->store(gam);
    }
    else if (gam != 0)
      L -= log(double(f->numiv()));
    if (fm.informative[gam])
      lastinformative = gam;
  }
  // Calculate the likelihood function
  if (options->likelihoodfile.assigned()) {
    if (f->numbits > 0 && lastinformative != FamilyMap::NOLEFTMARKER)
      L += log(sum<Float>(lq->getrow(lastinformative, true), f->numiv()));
    options->likelihoodfile << f->id << "\t";
    fmtout(options->likelihoodfile, 24, 20, L, 1, 9.9e300);
    options->likelihoodfile << endl;
  }

  fm.setup(&map);

  if (options->qfile) options->qfile.close();
  if (options->lfile) options->lfile.close();
  if (lastinformative == FamilyMap::NOLEFTMARKER) {
    // skip families with no informative markers
    warning(f->id + " has no informative markers");
    Distribution::curfamuninformative();
    return false;
  }
  return true;
}

bool Control::dospt(FamilyMap &fm, ADDvector &sp, Cudd &mgr,
                    Family *fam) const {
  // The following order is necessary for sp calculations

  message("dospt: starting spt");
  vector<int> level2index;
  message("dospt: finished level2index");
  for (Person *p = fam->firstdescendant; p != 0; p = p->next) {
    if (p->matbitlevel != Person::FIXEDBIT)
      level2index.push_back(p->matbitlevel);
    if (p->patbitlevel != Person::FIXEDBIT)
        level2index.push_back(p->patbitlevel);
  }
  message("dospt: finished for loop1");

  vector<int> straight(level2index.size());
  for (Uint i = 0; i < straight.size(); i++)
    straight[i] = i;


  message("dospt: finished for loop2");
  mgr.ShuffleHeap(&straight[0]);
  message("dospt: finished shutffling heap");
#ifdef DEBUG_OUTPUT
  cerr << "Permutation: ";
  copy(level2index.begin(), level2index.end(),
       ostream_iterator<Uint>(cerr, ", "));
  cerr << endl;
#endif // DEBUG_OUTPUT
  mgr.ShuffleHeap(&level2index[0]);

  SW_START("SP");
  message("dospt: Started sweeping");

  Sweeper sweeper(fam);
  SPGraph spg(fam, mgr);
  bool informative = false;
  for (Uint gam = 0; gam < map.loci.size(); gam++) {
    if (map.loci[gam].markernames.size() == 1) {
      SW_START("SPGraph");
      spg.fromhere(gam, map.loci[gam].pi[fam->populationindex], sp[gam]);
      SW_STOP("SPGraph");
    } else {
      SW_START("LDSP");
      LDSP::fromhere(sp[gam], fam, map.loci[gam].locus2markers,
                     map.loci[gam].ht[fam->populationindex],
                     map.loci[gam].pi[fam->populationindex], mgr);
      SW_STOP("LDSP");
    }
    if (!cuddIsConstant(sp[gam].getNode()))
      informative = true;
    fm.setinformative(gam, !cuddIsConstant(sp[gam].getNode()));

//    SW_START("peel");
//    SPPeel pf(gam, fam, mgr);

//    mgr.SetRoundingPrec(25);
//    sp[gam] = pf.peel(map.pi[fam->populationindex][gam], map.loci.size()allele[gam]);
//    mgr.SetRoundingPrec(10);
//    SW_STOP("peel");

    assertcond(sp[gam] != mgr.addZero(), "Family " + fam->id +
               " has inconsistent genotypes at marker " + map.loci[gam].name);

#ifdef DEBUG_OUTPUT
    cerr << "SP " << gam;
    sp[gam].print(fam->numbits, 1);
#endif // DEBUG_OUTPUT
//    normal(sp[gam]);

    ADD sp_interesting = sweeper.integrateOutUninteresting(sp[gam]);
//    normal(sp_interesting);
    SW_START("Distribution::set_spt");
    Distribution::set(sp_interesting, gam, "spt");
    SW_STOP("Distribution::set_spt");
  }
  SW_STOP("SP");

  mgr.SetMaxGrowth(1.1);
  Cudd_ReduceHeap(mgr.getManager(), CUDD_REORDER_SIFT,
                  options->maxmem*(1 << 20)/8);

  if (!informative) return false;

  // Haplotyping analysis
  if (options->dohaplo || options->doforcedrecomb) {
    Distribution::setGraph(spg.graph);
    Distribution::setSPT(sp);
    assertinternal(map.loci.size() > 0);
    ADDvector fp(map.loci.size());
    for (int gam = map.loci.size() - 1; gam >= 0; gam--) {
      if (options->dohaplo)
        Distribution::set(sp[gam], gam, "hpt");
      if (options->doforcedrecomb)
        fp[gam] = sp[gam].OneZeroMaximum(sp[gam].manager()->addZero());
    }

    if (options->doforcedrecomb) {
      Distribution::setSPT(fp);
      for (int gam = map.loci.size() - 1; gam >= 0; gam--)
        Distribution::set(fp[gam], gam, "fpt");
    }
  }

 return true;
}

unsigned int numFreeNodes(Cudd &mgr) {
  unsigned int n = 0;
  for (DdNode *nf = mgr.getManager()->nextFree; nf != 0; nf= nf->next)
    n++;
  return n;
}

void shrink(Cudd &mgr) {
//   mgr.SetMaxGrowth(1.001);
//   Cudd_ReduceHeap(mgr.getManager(), CUDD_REORDER_SIFT, 0);
  cuddGarbageCollect(mgr.getManager(), 1);

//   for (int i = 0; i < mgr.ReadSize(); i++)
//     cuddShrinkSubtable(mgr.getManager(), i);
}

void Control::dompt(FamilyMap &fm, ADDvector &sp, Cudd &mgr, Family *fam) {
  fm.setup(&map);

  mgr.SetRoundingPrec(options->mtbddrounding);

//   Cudd conv_mgr(fam->numbits);
//   conv_mgr.SetRoundingPrec(options->mtbddrounding);
//   conv_mgr.SetEpsilon(0.0);
  Sweeper sweeper(fam);
  sweeper.setup(sp);

#ifdef DEBUG_OUTPUT
  cerr << endl << "multipoint" << endl;
#endif // DEBUG_OUTPUT
  // conv_mgr.makeVerbose();
//    conv_mgr.AutodynEnable(CUDD_REORDER_SIFT);

  ADDvector left(map.loci.size(), &mgr);
  ADDvector right(map.loci.size(), &mgr);

  vector<RecombAccumulator> left_acc(map.loci.size());
  vector<bool> left_is_ADD(map.loci.size(), true);
  sweeper.firstMarker();
  sweeper.updateFrom(sp[0]);
  left_acc[0] = sweeper.getRacc();
  SW_START("Left_sweep");
  Uint lastinformative = 0;
  for (Uint gam = 1; gam < map.loci.size(); gam++) {
#ifdef DEBUG_OUTPUT
    cerr << "left marker " << gam << endl;
    cerr << "Memory:\t" << memoryUse() << endl;
#endif // DEBUG_OUTPUT
    if (fm.informative[gam]) {
      sweeper.nextMarker(left_acc[gam], fm.theta[lastinformative],
                         fm.theta_female[lastinformative], gam, false, true);
      left_is_ADD[gam] = sweeper.writeFrom(options->swapdirname + "/left." +
                                           gam);
      sweeper.updateFrom(sp[gam]);

      lastinformative = gam;
    }
  }
  sweeper.lastMarker();
  SW_STOP("Left_sweep");

  sweeper.firstMarker();
  bool first_informative_marker = true;
  for (Uint pos = int(map.positions.size() - 1); ; pos--) {
    if (!map.positions[pos].inbetween &&
        fm.informative[map.positions[pos].leftmarker]) {
//  for (int gam = int(map.loci.size()) - 1; gam >= 0; gam--) {
      const Uint gam = fm.leftmarker[pos];
#ifdef DEBUG_OUTPUT
      cerr << "right marker " << gam << endl;
      cerr << "Memory:\t" << memoryUse() << endl;
#endif // DEBUG_OUTPUT
      RecombAccumulator right_acc;

      SW_START("Right_sweep");
      if (first_informative_marker) {
        right_acc = sweeper.getRacc();
        first_informative_marker = false;
      }
      else if (fm.informative[gam])
        sweeper.nextMarker(right_acc, fm.theta[gam], fm.theta_female[gam],
                           gam, false, false);
      SW_STOP("Right_sweep");

      if (map.loci[gam].shouldfindp) {
        ADD p;
        {
          SW_START("Complete");
          Cudd comp_mgr(fam->numbits, 0, 256, 262144,
                        options->maxmem*(1 << 20)/8);
          comp_mgr.SetRoundingPrec(options->mtbddrounding);
          comp_mgr.SetEpsilon(0.0);
          p = sweeper.completeStep(options->swapdirname + "/left." + gam,
                                   left_is_ADD[gam], left_acc[gam], gam,
                                   right_acc, comp_mgr);
          SW_STOP("Complete");
        }

        SW_START("Distribution::set_mpt");
        Distribution::set(p, pos, "mpt");
        SW_STOP("Distribution::set_mpt");
      }

      sweeper.updateFrom(sp[gam]);

      // expexcted crossover count
      const int lastinformative = pos > 0 ? fm.leftmarker[pos - 1] : 0;
      if (options->calcrpt && pos > 0 &&
          lastinformative != FamilyMap::NOLEFTMARKER) {
       const string left_fn = lastinformative == 0 ? "" :
          options->swapdirname + "/left." + lastinformative;
        sweeper.calcRecombDist(left_fn, left_is_ADD[lastinformative],
                               left_acc[lastinformative],
                               sp[lastinformative], lastinformative,
                               fm.theta[lastinformative],
                               fm.theta_female[lastinformative]);
      }

      if (gam > 0)
        remove((options->swapdirname + "/left." + gam).c_str());
    }
    else {
      SW_START("completeUninformative");
      Cudd comp_mgr(fam->numbits, 0, 256, 262144, options->maxmem*(1 << 20)/8);
      comp_mgr.SetRoundingPrec(options->mtbddrounding);
      comp_mgr.SetEpsilon(0.0);

      string left;
      ADD s;
      bool liA = true;
      RecombAccumulator la;
      const int lm = fm.leftmarker[pos];
      if (lm == FamilyMap::NOLEFTMARKER) {
        left = "left.0";
        la = left_acc[0];
        la.reset();
        s = mgr.addOne();
      } else {
        left = options->swapdirname + "/left." + lm;
        liA = left_is_ADD[lm];
        la = left_acc[lm];
        s = sp[lm];
      }
      sweeper.completeUninformative(pos, fm, left, liA, la, s, &map, mgr);
      SW_STOP("completeUninformative");
    }

    shrink(mgr);

    if (pos == 0) break;
  }
  sweeper.lastMarker();
}

void Control::fromright(Probability &prob, const FamilyMap &fm, Floatmatrix *q,
                        Floatmatrix *lq, Family *fam) {
    FloatVec p = 0;
    if (options->calcmpt) {
        p = lq->getrow(map.loci.size() - 1, false);
        lq->getrow(0, false);
    }
    for (int pos = map.positions.size() - 1; pos >= 0; pos--) {

        // Monte carlo simulation
        if (options->montecarlo && !map.positions[pos].inbetween &&
                fm.informative[map.positions[pos].leftmarker]) {
            cerr << "\rMonteCarlo:  " << pos << flush;
            Uint gam = fm.leftmarker[pos];
            Distribution::set(lq->getrow(gam, true), pos, "cpt");
            Distribution::set(q->getrow(gam, true), pos, "cpt");
        }
        // Multipoint calculations
        if (options->calcmpt) {
            cerr << "\rMpt Calc: " << pos << "  " << flush;
            prob.findp(fm, pos, p); // from right (find r and p)
            Distribution::set(p, pos, "mpt");
        }
        // Haplotype and forced recombination calculations
        if ((options->dohaplo || options->doforcedrecomb) &&
                !map.positions[pos].inbetween) {
            cerr << "\rHaplo and recombination: " << pos << flush;

            Uint gam = map.positions[pos].leftmarker;
            FloatVec qp = q->getrow(gam, true);
            if (options->dohaplo)
                Distribution::set(qp, gam, "hpt");
            if (options->doforcedrecomb) {
                for (IV v = 0; v < fam->numiv(); v++) if (qp[v] > 0) qp[v] = 1.0;
                Distribution::set(qp, gam, "fpt");
            }
        }
    }
}

void Control::findnums() {
  cerr << "\r---------findnums: began" << flush;
  Family *fam=first; //normally wthin for, but here to extend scope
  for (fam = first; fam != 0; fam = fam->next) fam->countbits();

  maxnumiv = 0;
  vector_maxnumiv = 0;
  numfam = 0;
  maxbits = -1;
  string largestfam = "";
  options->maxfamidlen = 7;
  options->maxperidlen = 0;

  cerr << "\rfindnums (maxnumiv1,vector_maxnumiv1)=" << maxnumiv  << "," << vector_maxnumiv << flush;

  for (Family *f = first; f != 0; f = f->next) {
      numfam++;
      for (Person *p = f->first; p != 0; p = p->next){
          if (p->id.length() > options->maxperidlen){
              options->maxperidlen = p->id.length();
          }
      }
      cerr << "\rfindnums 1.1 (maxnumiv,vector_maxnumiv)=" << maxnumiv  << "," << vector_maxnumiv << flush;

      if (f->id.length() > options->maxfamidlen){
          //This is never accessed usually
          cerr << "\rfindnums 1.2 (maxnumiv,vector_maxnumiv)=" << maxnumiv  << "," << vector_maxnumiv << flush;
          options->maxfamidlen = f->id.length();
      }
      cerr << "\rfindnums 1.3 (maxnumiv,vector_maxnumiv)=" << maxnumiv  << "," << vector_maxnumiv << flush;

      const IV numiv = f->numiv();
      if (numiv > maxnumiv) {
          cerr << "\rfindnums 1.4 (maxnumiv,vector_maxnumiv)=" << maxnumiv  << "," << vector_maxnumiv << flush;
          maxnumiv = numiv;
      }
      cerr << "\rfindnums 1.5 (maxnumiv,vector_maxnumiv)=" << maxnumiv  << "," << vector_maxnumiv << flush;
      const Uint nb = f->numbits;

      //PROBLEM OCCURS HERE -- 21 bits skips this.
      if (nb <= options->mtbddthreshold && numiv > vector_maxnumiv){
          cerr << "\rfindnums 1.6 (maxnumiv,vector_maxnumiv)=" << maxnumiv  << "," << vector_maxnumiv << flush;
          vector_maxnumiv = numiv;
      }
      if (int(nb) > maxbits) {
          cerr << "\rfindnums 1.7 (maxnumiv,vector_maxnumiv)=" << maxnumiv  << "," << vector_maxnumiv << flush;
          maxbits = nb;
          largestfam = f->id;
      }
  }
  // here is where the problem lies for vector_maxnumiv not beign set properly.

  cerr << "\rfindnums 1.8 (maxnumiv,vector_maxnumiv)=" << maxnumiv  << "," << vector_maxnumiv << flush;

  if (maxnumiv == 0) {
    warning("Nothing to be done");
    exit(0);
  }

  if (numfam == 1)
    message(string("Analysing 1 family (") + largestfam + ", " + maxbits
            + " bit" + plurals(maxbits) + ")");
  else
    message(string("Analysing ") + numfam + " families, the largest is " +
            maxbits + " bit" + plurals(maxbits) + "(" + largestfam + ")");

  cerr << "\rfindnums (maxnumiv3,vector_maxnumiv3)=" << maxnumiv  << "," << vector_maxnumiv << endl;

}

void Control::setupfamilies() {
  first = 0;
  Family *lf = 0;
  for (Family *fam = firstorig; fam != 0; fam = fam->next) {
    if (fam->first == 0) {
      if (lf != 0) lf->next = fam->next;
    }
    else {
//        if (options->chromolist == 0) {
//          string nextid = (fam->next == 0 ? "" : fam->next->id);
//          fam->setup();

//          if (first == 0) lf = first = fam;
//          if (nextid != "")
//            while (lf->next->id != nextid) {
//              if (lf->next->first == 0) lf->next = lf->next->next;
//              else lf = lf->next;
//            }
//        }
//        else {
      if (first == 0) lf = first = new Family(*fam);
      else lf = lf->next = new Family(*fam);
      lf->setup();
      while (lf->next != 0) {
        if (lf->next->first == 0) lf->next = lf->next->next;
        else lf = lf->next;
      }
//        }
    }
  }
  // Remove empty families
  while (first != 0 && first->first == 0) first = first->next;
  lf = first;
  if (lf != 0) {
    while (lf->next != 0)
      if (lf->next->first == 0) lf->next = lf->next->next;
      else lf = lf->next;
  }

//    // Set liability classes
//    for (Family *fam = first; fam != 0; fam = fam->next) {
//      for (Person *p = fam->first; p != 0; p = p->next)
//        p->liability = (options->sexlinked ? 1 - p->sex : 0);
//    }
}

void Control::createswapdir() {
  if (!swapdircreated) {
    message("SWAPDIRNAME " +  options->swapdirname);
    assertcond(mkdir(options->swapdirname.c_str(), 493) == 0,
               "Unable to create swap directory or it already exists!");
    swapdircreated = true;
  }
}

void Control::cleanupswapdir() {
  cout << "swapdircreated=" << swapdircreated << endl;
  if (swapdircreated) {
    rmdir(options->swapdirname.c_str());

    swapdircreated = false;
  }
}

void FamilyMap::setinformative(Uint gam, bool informat) {
  assertinternal(gam < informative.size());
  if (!informat) {
    if (options->uninformative.assigned())
      options->uninformative << markernames[gam] << "\t" << famid << "\n";

    int lastinformative = NOLEFTMARKER;
    for (Uint g = 0; g < gam; g++)
      if (informative[g])
        lastinformative = g;
    if (lastinformative != NOLEFTMARKER) {
      theta[lastinformative] = addrec(theta[lastinformative], theta[gam]);
      theta_female[lastinformative] = addrec(theta_female[lastinformative],
                                             theta_female[gam]);
    }
  }

  informative[gam] = informat;
}

void FamilyMap::setup(Map *map) {
  // This function is only called for informative families
  Uint gam = 0;
  int lastinformative = NOLEFTMARKER;

  // Find next informative marker to the left and calculate thetas
  for (Uint pos = 0; pos < map->positions.size(); pos++) {
    if (!map->positions[pos].inbetween) {
      if (informative[gam])
        lastinformative = gam;

      if (map->loci[gam].shouldfindp) shouldfindp[pos] = true;
      else shouldfindp[pos] = false;

      gam++;
    } else
      shouldfindp[pos] = true;
    leftmarker[pos] = lastinformative;
  }

  // Find next informative marker to the right
  lastinformative = NORIGHTMARKER;
  gam = map->loci.size() - 1;
  for (int pos = map->positions.size() - 1; pos >= 0; pos--) {
    rightmarker[pos] = lastinformative;
    if (!map->positions[pos].inbetween) {
      if (informative[gam]) lastinformative = gam;
      gam--;
    }
  }
}
