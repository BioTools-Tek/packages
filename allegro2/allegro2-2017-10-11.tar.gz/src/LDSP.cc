#include "LDSP.hh"
#include "family.h"
#include "cuddutil.h"

#include <set>

void printblocks(const map<Node *, LDSPBlock> &blocks) {
  for (map<Node *, LDSPBlock>::const_iterator bi = blocks.begin();
       bi != blocks.end(); bi++) {
    cout << bi->first << endl;
    bi->second.print();
  }
}

void LDSPBlock::print() const {
  for (unsigned int i = 0; i < m_nodes.size(); i++)
    cout << "\t" << m_nodes[i];
  cout << endl;

  for (unsigned int j = 0; j < m_haps.size(); j++) {
    for (unsigned int i = 0; i < m_haps[j].size(); i++)
      cout << "\t" << m_haps[j][i];
    cout << endl;
  }
}

double LDSP::fromhere(ADD &sp, Family *fam, const vector<Uint> &markers,
                      const HaploTree &hidx, const vector<Float> &freq,
                      Cudd &mgr) {
  map<Node *, LDSPBlock> init_blocks;
  const Haplotype nogt(markers.size(), 0);
  for (Person *p = fam->first; p != fam->firstdescendant; p = p->next) {
    if (p->genotyped(markers)) {
      init_blocks[p->nod[0]] = init_blocks[p->nod[1]] =
        personblock(p, markers, hidx);
    } else {
      init_blocks[p->nod[0]] = LDSPBlock(p->nod[0], nogt);
      init_blocks[p->nod[1]] = LDSPBlock(p->nod[1], nogt);
    }
  }

  vector<PersonInfo> pi;
  for (Person *p = fam->firstdescendant; p != 0; p = p->next)
    if (p->children != 0 && p->hasgenotypeddesc(markers) ||
        p->genotyped(markers)) {
      pi.push_back(PersonInfo(p));
      if (p->genotyped(markers))
        pi.back().block = personblock(p, markers, hidx);
    }

//  printblocks(init_blocks);

  // Calculate single locus probabilities
  sp = findq(init_blocks, pi.begin(), pi.end(), hidx, freq, mgr);

  return 1.;
}

LDSPBlock LDSP::personblock(Person *p, const vector<Uint> &markers,
                            const HaploTree &hidx) {
  LDSPBlock res;
  res.m_nodes.push_back(p->nod[0]);
  res.m_nodes.push_back(p->nod[1]);

  Haplotype h1(markers.size(), 0);
  Haplotype h2(markers.size(), 0);

  vector<HaploTree const *> ht (1, &hidx);
  buildpersonblock(res, h1, h2, ht, ht, p, markers.begin(), markers.end());

  return res;
}

void LDSP::updateht(vector<HaploTree const *> &new_ht,
                    const vector<HaploTree const *> &ht, Allele a) {
  for (Uint i = 0; i < ht.size(); i++) {
//    ht[i]->print();
    map<Uint, HaploTree>::const_iterator bi = ht[i]->branches.find(a);
    if (bi != ht[i]->branches.end())
      new_ht.push_back(&bi->second);
  }
}

void LDSP::buildpersonblock(LDSPBlock &block, Haplotype &h1, Haplotype &h2,
                            const vector<HaploTree const *> &ht1,
                            const vector<HaploTree const *> &ht2,
                            Person *p, vector<Uint>::const_iterator m_i,
                            vector<Uint>::const_iterator m_end) {
  if (m_i == m_end) {
    block.m_haps.push_back(vector<Haplotype>(2));
    block.m_haps.back()[0] = h1;
    block.m_haps.back()[1] = h2;
  } else {
    const Uint m = *m_i;
    const Allele a1 = p->gen[0][m];
    const Allele a2 = p->gen[1][m];

    vector<HaploTree const *> new_ht1;
    vector<HaploTree const *> new_ht2;
    if (a1 == 0) {
      assertinternal(a2 == 0);
      for (Uint i = 0; i < ht1.size(); i++)
        for (map<Uint, HaploTree>::const_iterator hi = ht1[i]->branches.begin();
             hi != ht1[i]->branches.end(); hi++)
          new_ht1.push_back(&hi->second);
      for (Uint i = 0; i < ht2.size(); i++)
        for (map<Uint, HaploTree>::const_iterator hi = ht2[i]->branches.begin();
             hi != ht2[i]->branches.end(); hi++)
          new_ht2.push_back(&hi->second);

      h1[m] = h2[m] = 0;
      buildpersonblock(block, h1, h2, new_ht1, new_ht2, p, m_i + 1, m_end);
    } else {
      updateht(new_ht1, ht1, a1);
      updateht(new_ht2, ht2, a2);

      if (!new_ht1.empty() && !new_ht2.empty()) {
        h1[m] = a1;
        h2[m] = a2;
        buildpersonblock(block, h1, h2, new_ht1, new_ht2, p, m_i + 1, m_end);
      }

      if (a1 != a2) {
        new_ht1.clear();
        new_ht2.clear();
        updateht(new_ht1, ht1, a2);
        updateht(new_ht2, ht2, a1);

        if (!new_ht1.empty() && !new_ht2.empty()) {
          h1[m] = a2;
          h2[m] = a1;
          buildpersonblock(block, h1, h2, new_ht1, new_ht2, p, m_i + 1, m_end);
        }
      }
    }
  }
}

ADD LDSP::findq(const map<Node *, LDSPBlock> &blocks,
                vector<PersonInfo>::iterator pi,
                vector<PersonInfo>::iterator pi_end,
                const HaploTree &hidx, const vector<Float> &freq,
                Cudd &mgr) {
  if (pi == pi_end) {
    // return graph->symbolic_probability(mgr, 50);
    const double val = probability(blocks, hidx, freq);
    return mgr.constant(val);
  }
  else {
    Person *p = pi->per;
    int Kf = p->patmask ? 1 : 0;
    int Km = p->matmask ? 1 : 0;

    ADD qdd_00 = mgr.addZero();
    ADD qdd_01 = mgr.addZero();
    ADD qdd_10 = mgr.addZero();
    ADD qdd_11 = mgr.addZero();

    for (int K1 = 0; K1 <= Km; K1++) {
      Node *n1 = p->mother->nod[K1];
      p->nod[1] = n1;
      for (int K0 = 0; K0 <= Kf; K0++) {
        Node *n0 = p->father->nod[K0];
        if (!options->sexlinked || p->sex == FEMALE) p->nod[0] = n0;
        else n0 = p->nod[0] = p->nod[1];
        ADD &cur_qdd = (K0 == 0 ? (K1 == 0 ? qdd_00 : qdd_10) :
                        (K1 == 0 ? qdd_01 : qdd_11));
        if (!pi->block.m_haps.empty()) {
          assertinternal(p->nod[0] != p->nod[1]);
          map<Node *, LDSPBlock> new_blocks(blocks);
          LDSPBlock &pat_block(new_blocks.find(p->nod[0])->second);
          LDSPBlock &mat_block(new_blocks.find(p->nod[1])->second);

          pi->block.m_nodes[0] = p->nod[0];
          pi->block.m_nodes[1] = p->nod[1];

          pat_block.constrain(pi->block);
          mat_block.constrain(pi->block);

          LDSPBlock joint_block(pat_block, mat_block);
          joint_block.constrain(pi->block);
          if (!joint_block.m_haps.empty()) {
            joint_block.split(new_blocks);
            cur_qdd = findq(new_blocks, pi + 1, pi_end, hidx, freq, mgr);
          }
        }
        else
          cur_qdd = findq(blocks, pi + 1, pi_end, hidx, freq, mgr);
      }
    }

    ADD result;

    if (Km == 1 && Kf == 1) {
      result = uniqueInter(p->matbitlevel, mgr,
                           uniqueInter(p->patbitlevel, mgr, qdd_11, qdd_10),
          uniqueInter(p->patbitlevel, mgr, qdd_01, qdd_00));
    }
    else if (Km == 1)
      result = uniqueInter(p->matbitlevel, mgr, qdd_10, qdd_00);
    else if (Kf == 1)
      result = uniqueInter(p->patbitlevel, mgr, qdd_01, qdd_00);
    else
      result = qdd_00;

    return result;
  }
}

double LDSP::haploprob(Haplotype::const_iterator h_i,
                       Haplotype::const_iterator h_end, const HaploTree &hidx,
                       const vector<Float> &freq) {
  if (h_i == h_end)
    return freq[hidx.index];
  else {
    double pr = .0;
    if (*h_i == 0) {
      for (map<Uint, HaploTree>::const_iterator ai = hidx.branches.begin();
           ai != hidx.branches.end(); ai++)
        pr += haploprob(h_i + 1, h_end, ai->second, freq);
    } else {
      map<Uint, HaploTree>::const_iterator ai = hidx.branches.find(*h_i);
      if (ai != hidx.branches.end())
        pr = haploprob(h_i + 1, h_end, ai->second, freq);
    }
    return pr;
  }
}

double LDSP::probability(const map<Node *, LDSPBlock> &blocks,
                         const HaploTree &hidx, const vector<Float> &freq) {
  double prob = 1.;
  set<Node *> done;
  for (map<Node *, LDSPBlock>::const_iterator bi = blocks.begin();
       bi != blocks.end(); bi++) {
    if (done.count(bi->first)) continue;
    double pr = .0;
    for (vector<vector<Haplotype> >::const_iterator hi =
           bi->second.m_haps.begin(); hi != bi->second.m_haps.end(); hi++) {
      double pi = 1.;
      for (vector<Haplotype>::const_iterator ki = hi->begin(); ki != hi->end();
           ki++) {
        bool all_zero = true;
        for (Haplotype::const_iterator i = ki->begin(); i != ki->end(); i++)
          if (*i != 0) {
            all_zero = false;
            break;
          }
        if (!all_zero)
          pi *= haploprob(ki->begin(), ki->end(), hidx, freq);
      }
      pr += pi;
    }
    prob *= pr;

    for (unsigned int i = 0; i < bi->second.m_nodes.size(); i++)
      done.insert(bi->second.m_nodes[i]);
  }
  return prob;
}
