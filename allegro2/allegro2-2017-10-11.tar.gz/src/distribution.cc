#include "files.h"
#include "distribution.h"
#include "options.h"
#include "map.h"
#include "calc.h"
#include "family.h"
#include "haldane.h"
#include "vecutil.h"
#include "probability.h"
#include "haplodist.h"
#include "montecarlo.h"
#include "cuddutil.h"

////////////////////////////////////////////////////////////////////////
// Distribution

Distribution::Distributionvector Distribution::distributions;
Graph *Distribution::graph = 0;
bool Distribution::nullconstant = true;
Map const *Distribution::map = 0;

Distribution::Distribution(const string &p) : pt(p) {
  distributions.push_back(this);
}

Distribution::~Distribution() {}

const string &Distribution::getpt() {
  return pt;
}

void Distribution::reset(const Map &mp) {
  map = &mp;
  const Uint nposspt = map->loci.size();
  const Uint nposmpt = map->positions.size();
  for (Uint d = 0; d < distributions.size(); d++) {
    if (distributions[d]->getpt() == "spt" ||
        distributions[d]->getpt() == "hpt" ||
        distributions[d]->getpt() == "fpt" ||
        distributions[d]->getpt() == "cpt" ||
        distributions[d]->getpt() == "rpt")
      distributions[d]->reset(nposspt);
    else if (distributions[d]->getpt() == "mpt" ||
             distributions[d]->getpt() == "dpt")
      distributions[d]->reset(nposmpt);
    else assertinternal(false);
    distributions[d]->families.clear();
  }
}

void Distribution::set(FloatVec pv, Uint pos, const string &p) {
  assertinternal(p == "spt" || p == "mpt" || p == "dpt" || p == "hpt" ||
                 p == "fpt" || p == "cpt");
  for (Uint d = 0; d < distributions.size(); d++)
    if (!distributions[d]->skipcurrentfamily && distributions[d]->getpt() == p)
      distributions[d]->set(pv, pos);
}

void Distribution::set(ADD &pv, Uint pos, const string &p) {
  assertinternal(p == "spt" || p == "mpt" || p == "dpt" || p == "hpt" ||
                 p == "fpt" || p == "cpt");
  const double sum_pv = sum(pv);
  assertinternal(sum_pv > .0);
  for (Uint d = 0; d < distributions.size(); d++)
    if (!distributions[d]->skipcurrentfamily && distributions[d]->getpt() == p)
      distributions[d]->set(pv, sum_pv, pos);
}

void Distribution::setSPT(ADDvector &sp) {
  for (Uint d = 0; d < distributions.size(); d++)
    if (!distributions[d]->skipcurrentfamily)
      distributions[d]->SPT(sp);
}

bool Distribution::famuseful(Family *fam, bool mtbdd) {
  bool useful = false;
  for (Uint d = 0; d < distributions.size(); d++)
    if (distributions[d]->usefamily(fam, mtbdd))
      useful = true;
  return useful;
}

bool Distribution::nextfam(Probability &prob, Family *fam, DoubleVec p0) {
  cout << "nextfam: Calc::calculate(fam)" << endl;
  Calc::calculate(fam);
  cout << "nextfam: Montecarlo::setprob(prob)";
  Montecarlo::setprob(prob);

  if (!famuseful(fam, false)) return false;

  if (isnullconstant()) {
    for (Uint d = 0; d < distributions.size(); d++)
      if (distributions[d]->usefamily(fam, false)) {
        distributions[d]->skipcurrentfamily = false;
        distributions[d]->families.push_back(fam);
        distributions[d]->nextfam(false);
      }
      else
        distributions[d]->skipcurrentfamily = true;
  }
  else {
    // Construct p0
    fam->pseudonull(p0);

    // Evolve p0
    Uint pos = 0;
    Uint gam = 0;
    Float lastposition_male = 0;
    Float lastposition_female = 0;
    while (pos < map->positions.size() && gam < map->loci.size()) {
      bool dompt = false;
      bool dospt = false;
      Float theta_male = 0;
      Float theta_female = 0;
      if (fabs(map->positions[pos].positionAvg() -
               map->loci[gam].positionAvg()) < 1e-10) {
        dompt = dospt = true;
        theta_male = recombfraccent(map->positions[pos].positionMale() -
                                    lastposition_male);
        theta_female = recombfraccent(map->positions[pos].positionFemale() -
                                      lastposition_female);
        lastposition_male = map->positions[pos].positionMale();
        lastposition_female = map->positions[pos].positionFemale();
      }
      else if (map->positions[pos].positionAvg() <
               map->loci[gam].positionAvg()) {
        dompt = true;
        theta_male = recombfraccent(map->positions[pos].positionMale() -
                                    lastposition_male);
        theta_female = recombfraccent(map->positions[pos].positionFemale() -
                                      lastposition_female);
        lastposition_male = map->positions[pos].positionMale();
        lastposition_female = map->positions[pos].positionFemale();
      }
      else {
        dospt = true;
        theta_male = recombfraccent(map->loci[gam].positionMale() -
                                    lastposition_male);
        theta_female = recombfraccent(map->loci[gam].positionFemale() -
                                      lastposition_female);
        lastposition_male = map->loci[gam].positionMale();
        lastposition_female = map->loci[gam].positionFemale();
      }
      if (theta_male > 0 || theta_female > 0) {
        // Convolve p0
        fft(p0, p0, fam->numiv(), fam->numbits);       // hat(p0_i)
        prob.Ttrans(p0, p0, theta_male, theta_female); // hat(p0_i)*hat(T)_i
        fft(p0, p0, fam->numiv(), fam->numbits);       // p0_(i+1)
      }
      // Pass p0 down
      normal<Double>(p0, fam->numiv());
      for (Uint d = 0; d < distributions.size(); d++) {
        if (distributions[d]->usefamily(fam, false)) {
          distributions[d]->families.push_back(fam);
          if (dospt && distributions[d]->pt == "spt")
            distributions[d]->nextfam(false, gam, p0);
          else if (dompt && distributions[d]->pt == "mpt")
            distributions[d]->nextfam(false, pos, p0);
        }
      }
      if (dompt) pos++;
      if (dospt) gam++;
    }
  }

  return true;
}

bool Distribution::nextfam(Family *fam, Cudd &mgr) {
  Calc::calculate(fam, mgr);
#ifdef CHECK_CUDD
  assert(Cudd_DebugCheck(mgr.getManager()) == 0);
#endif // CHECK_CUDD
//   Montecarlo::setprob(prob);

  if (!famuseful(fam, true)) return false;

  for (Uint d = 0; d < distributions.size(); d++)
    if (distributions[d]->usefamily(fam, true)) {
      distributions[d]->skipcurrentfamily = false;
      distributions[d]->families.push_back(fam);
      distributions[d]->nextfam(true);
    }
    else
      distributions[d]->skipcurrentfamily = true;

  return true;
}

void Distribution::curfamuninformative() {
  for (Uint d = 0; d < distributions.size(); d++)
    if (!distributions[d]->skipcurrentfamily &&
        !distributions[d]->useuninformative()) {
      distributions[d]->families.pop_back();
      distributions[d]->skipfam();
      distributions[d]->skipcurrentfamily = true;
    }
}

const string &Distribution::getfamid(Uint ifam) const {
  assertinternal(ifam < families.size());
  return families[ifam]->id;
}

Distribution *Distribution::finddistribution(const string &desc,
                                             const string &pt) {
  for (Uint d = 0; d < distributions.size(); d++)
    if (desc == distributions[d]->describe() &&
        pt == distributions[d]->getpt())
      return distributions[d];
  return 0;
}

bool Distribution::usefamily(Family *fam, bool /*mtbdd*/) const {
  return fam->numbits > 0;
}

void Distribution::cleanup() {
  for (Uint d = 0; d < distributions.size(); d++)
    delete distributions[d];
  distributions.clear();
}

void Distribution::getuninteresting(Family *fam,
                                    ::set<Unreduced> &uninteresting) {
  for (Uint d = 0; d < distributions.size() && !uninteresting.empty(); d++)
    if (distributions[d]->usefamily(fam, true))
      distributions[d]->getuninteresting(uninteresting);
}
