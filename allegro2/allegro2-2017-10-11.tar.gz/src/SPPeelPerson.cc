#include "SPPeelPerson.hh"
#include "SPPeelMarriage.hh"
#include "family.h"

#include <set>

SPPeelPerson::SPPeelPerson(const string &id, const string &father,
                           const string &mother, unsigned int patbitlevel,
                           unsigned int matbitlevel, bool founder, Cudd &mgr,
                           Allele a1, Allele a2) :
    m_id(id), m_father(father), m_mother(mother), m_patbitlevel(patbitlevel),
    m_matbitlevel(matbitlevel), m_founder(founder) {
  if (a1 != ALLELEUNKNOWN) {
    ADD z = mgr.addOne();
    const PhasedGT h(uint64_t(1) << (a1 - 1), uint64_t(1) << (a2 - 1));
    m_phases[h] = z;
    if (a1 != a2) m_phases[PhasedGT(h.second, h.first)] = z;
  } else {
    m_phases[PhasedGT(UNINFORMATIVE, UNINFORMATIVE)] = mgr.addOne();
  }
}

bool SPPeelPerson::isFiner(const SPPeelPerson &p) const {
  for (map<PhasedGT, ADD>::const_iterator hi = m_phases.begin();
       hi != m_phases.end(); hi++)
    for (map<PhasedGT, ADD>::const_iterator pi = p.m_phases.begin();
         pi != p.m_phases.end(); pi++)
      if (!(finer(hi->first.first, pi->first.first) &&
            finer(hi->first.first, pi->first.second) &&
            finer(hi->first.second, pi->first.first) &&
            finer(hi->first.second, pi->first.second)))
        return false;
  return true;
}

void SPPeelPerson::splitPhase(uint64_t h, uint64_t s, ADD x, bool pattrans,
                              uint64_t o) {
  const uint64_t inter = h & s;
  const uint64_t rem = h & (~s);
  assertinternal(inter != 0 && rem != 0 && (inter & rem) == 0);
  m_phases[pattrans ? PhasedGT(inter, o) : PhasedGT(o, inter)] = x;
  m_phases[pattrans ? PhasedGT(rem, o) : PhasedGT(o, rem)] = x;
  m_phases.erase(pattrans ?  PhasedGT(h, o) : PhasedGT(o, h));
}

void SPPeelPerson::makeFinerThan(const SPPeelPerson &p) {
  bool changes = true;
  while (changes) {
    changes = false;
    for (map<PhasedGT, ADD>::const_iterator hi = m_phases.begin();
         !changes && hi != m_phases.end(); hi++)
      for (map<PhasedGT, ADD>::const_iterator pi = p.m_phases.begin();
           !changes && pi != p.m_phases.end(); pi++)
        if (!finer(hi->first.first, pi->first.first)) {
          splitPhase(hi->first.first, pi->first.first, hi->second, true,
                     hi->first.second);
          changes = true;
        } else if (!finer(hi->first.first, pi->first.second)) {
          splitPhase(hi->first.first, pi->first.second, hi->second, true,
                     hi->first.second);
          changes = true;
        } else if (!finer(hi->first.second, pi->first.first)) {
          splitPhase(hi->first.second, pi->first.first, hi->second, false,
                     hi->first.first);
          changes = true;
        } else if (! finer(hi->first.second, pi->first.second)) {
          splitPhase(hi->first.second, pi->first.second, hi->second, false,
                     hi->first.first);
          changes = true;
        }
  }
}

ADD SPPeelPerson::sumProb(Cudd &mgr) const {
  ADD res = mgr.addZero();
  for (map<PhasedGT, ADD>::const_iterator it = m_phases.begin();
       it != m_phases.end(); it++)
    res += it->second;
  return res;
}

void SPPeelPerson::print() {
  for (map<PhasedGT, ADD>::iterator i = m_phases.begin();
       i != m_phases.end(); i++) {
    cout << m_id << "\t" << i->first.first << " " << i->first.second;
    i->second.print(6, 2);
  }
}

void SPPeelPerson::printShort() const {
  cout << m_id << "   "
       << (m_patbitlevel == Person::FIXEDBIT || isFounder() ? "X" :
           string("") + m_patbitlevel)
       << "/"
       << (m_matbitlevel == Person::FIXEDBIT || isFounder() ? "X" :
           string("") + m_matbitlevel);
  for (map<PhasedGT, ADD>::const_iterator i = m_phases.begin();
       i != m_phases.end(); i++)
    cout << "   " << i->first.first << "/" << i->first.second;
  cout << endl;
}

bool SPPeelPerson::isLeaf(const vector<SPPeelMarriage> &fam) const {
  unsigned int num_mar = 0;
  for (unsigned int i = 0; i < fam.size() && num_mar < 2; i++)
    if (fam[i].contains(this))
      num_mar++;
  return num_mar < 2;
}

unsigned int SPPeelPerson::numPhasedGTs() const {
  unsigned int n = 0;
  for (map<PhasedGT, ADD>::const_iterator phi = m_phases.begin();
       phi != m_phases.end(); phi++)
    n += (POPCOUNT(phi->first.first)*
          POPCOUNT(phi->first.second));
  return n;
}

void SPPeelPerson::mergeIdentical() {
  bool match_found;
  do {
    match_found = false;

    for (map<PhasedGT, ADD>::iterator i = m_phases.begin();
         i != m_phases.end(); i++) {
      for (map<PhasedGT, ADD>::iterator j = m_phases.begin();
           j != i; j++)
        if (i->second == j->second) {
          const PhasedGT ih = i->first;
          const PhasedGT jh = j->first;
          ADD x = i->second;
          if (ih.first == jh.first) {
            assertinternal((ih.second & jh.second) == 0);
            m_phases[PhasedGT(ih.first, ih.second | jh.second)] = x;
            match_found = true;
          }
          if (ih.second == jh.second) {
            assertinternal((ih.first & jh.first) == 0);
            m_phases[PhasedGT(ih.first | jh.first, ih.second)] = x;
            match_found = true;
          }
          if (match_found) {
            m_phases.erase(ih);
            m_phases.erase(jh);
            break;
          }
        }
      if (match_found) break;
    }
  } while (match_found);
}

void SPPeelPerson::hideUninformativeBit() {
  bool patbit_informative = false;
  bool matbit_informative = false;
  for (map<PhasedGT, ADD>::const_iterator hi = m_phases.begin();
       !patbit_informative && !matbit_informative && hi != m_phases.end();
       hi++) {
    if (hi->first.first != UNINFORMATIVE)
      patbit_informative = true;
    if (hi->first.second != UNINFORMATIVE)
      matbit_informative = true;
  }

  if (!patbit_informative) m_patbitlevel = Person::FIXEDBIT;
  if (!matbit_informative) m_matbitlevel = Person::FIXEDBIT;
}
