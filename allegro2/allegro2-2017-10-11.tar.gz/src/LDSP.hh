#ifndef _LDSP
#define _LDSP 1

#include "basic.h"
#include "map.h"
#include "cuddObj.hh"

class Node;

class LDSPBlock {
public:
  vector<Node *> m_nodes;
  vector<vector<Haplotype> > m_haps;

  LDSPBlock() {}
  LDSPBlock(Node *n, Haplotype a) {
    m_nodes.push_back(n);
    m_haps.push_back(vector<Haplotype>(1, a));
  }
//  LDSPBlock(Node *n1, Node *n2
  LDSPBlock(vector<Node *> nodes, vector<vector<Haplotype> > haps) :
      m_nodes(nodes), m_haps(haps) {}
  LDSPBlock(const LDSPBlock &a, const LDSPBlock &b) : m_nodes(a.m_nodes) {
    m_nodes.insert(m_nodes.end(), b.m_nodes.begin(), b.m_nodes.end());
    for (vector<vector<Haplotype> >::const_iterator ai = a.m_haps.begin();
         ai != a.m_haps.end(); ai++)
      for (vector<vector<Haplotype> >::const_iterator bi = b.m_haps.begin();
           bi != b.m_haps.end(); bi++) {
        vector<Haplotype> haps(*ai);
        haps.insert(haps.end(), bi->begin(), bi->end());
        m_haps.push_back(haps);
      }
  }

  void constrain(const LDSPBlock &block) {
    // Find pairs of indices that represent the same Node in the two blocks
    map<unsigned int, unsigned int> overlap;
    for (unsigned int i = 0; i < m_nodes.size(); i++)
      for (unsigned int j = 0; j < block.m_nodes.size(); j++)
        if (m_nodes[i] == block.m_nodes[j]) {
          overlap[i] = j;
          break;
        }

    vector<vector<Haplotype> > res_haps;
    for (vector<vector<Haplotype> >::const_iterator h = m_haps.begin();
         h != m_haps.end(); h++) {
      for (vector<vector<Haplotype> >::const_iterator k = block.m_haps.begin();
           k != block.m_haps.end(); k++) {
        bool consistent = true;
        vector<Haplotype> rh(*h);
        for (unsigned int i = 0; i < rh.size() && consistent; i++) {
          const map<unsigned int, unsigned int>::const_iterator
            oi = overlap.find(i);
          if (oi != overlap.end()) {
            if (!(*h)[i].isConsistent((*k)[oi->second]))
              consistent = false;
            if (consistent) {
//              assertinternal(oi != overlap.end());
              assertinternal(i < h->size());
              assertinternal(oi->second < k->size());
              rh[i] = (*h)[i].intersection((*k)[oi->second]);
            }
          }
        }
        if (consistent)
          res_haps.push_back(rh);
      }
    }

    m_haps = res_haps;
//    return LDSPBlock(block.m_nodes, res_haps);

//    result.clear();
//    if (!res_haps.empty())
//      LDSPBlock(block.m_nodes, res_haps).split(result);
  }

  void split(map<Node *, LDSPBlock> &result) {
    assert(!m_haps.empty());

    LDSPBlock rb;
    for (unsigned int i = 0; i < m_nodes.size(); i++) {
      bool fixed = true;
      for (unsigned int h = 1; fixed && h < m_haps.size(); h++)
        if (m_haps[h][i] != m_haps[h][i - 1])
          fixed = false;

      if (fixed)
        result[m_nodes[i]] = LDSPBlock(m_nodes[i], m_haps.front()[i]);
      else
        rb.m_nodes.push_back(m_nodes[i]);
    }

    if (!rb.m_nodes.empty()) {
      rb.m_haps.resize(m_haps.size(), vector<Haplotype>(rb.m_nodes.size()));
      for (unsigned int h = 0; h < m_haps.size(); h++) {
        for (unsigned int i = 0, i_rb = 0; i < m_nodes.size(); i++)
          if (m_nodes[i] == rb.m_nodes[i_rb]) {
            rb.m_haps[h][i_rb] = m_haps[h][i];
            i_rb++;
          }
      }

      for (unsigned int i = 0; i < m_nodes.size(); i++)
        result[m_nodes[i]] = rb;
    }
  }

  void print() const;

};

class PersonInfo {
public:
  Person *per;
  LDSPBlock block;

  PersonInfo(Person *p) : per(p) {}
};

class LDSP {
private:
  static LDSPBlock personblock(Person *p, const vector<Uint> &markers,
                           const HaploTree &hidx);
  static void buildpersonblock(LDSPBlock &block, Haplotype &h1, Haplotype &h2,
                               const vector<HaploTree const *> &ht1,
                               const vector<HaploTree const *> &ht2,
                               Person *p, vector<Uint>::const_iterator m_i,
                               vector<Uint>::const_iterator m_end);
  static void updateht(vector<HaploTree const *> &new_ht,
                       const vector<HaploTree const *> &ht, Allele a);

  static ADD findq(const map<Node *, LDSPBlock> &blocks,
                   vector<PersonInfo>::iterator pi,
                   vector<PersonInfo>::iterator pi_end,
                   const HaploTree &hidx, const vector<Float> &freq,
                   Cudd &mgr);

  static double haploprob(Haplotype::const_iterator h_i,
                          Haplotype::const_iterator h_end,
                          const HaploTree &hidx, const vector<Float> &freq);
  static double probability(const map<Node *, LDSPBlock> &blocks,
                            const HaploTree &hidx, const vector<Float> &freq);
public:
  static double fromhere(ADD &sp, Family *fam, const vector<Uint> &markers,
                         const HaploTree &hidx, const vector<Float> &freq,
                         Cudd &mgr);

};

// Node *pat_node;
// Node *mat_node;

// LDSPBlock indiv_block;

// map<Node *, LDSPBlock> blocks;

// LDSPBlock &pat_block(blocks[pat_node]);
// LDSPBlock &mat_block(blocks[mat_node]);

// pat_block.constrain(indiv_block);
// mat_block.constrain(indiv_block);

// LDSPBlock joint_block(pat_block, mat_block);
// joint_block.constrain(indiv_block);

// joint_block.split(blocks);
// // blocks[pat_node] = blocks[mat_node] = joint_block;

#endif
