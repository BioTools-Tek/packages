#include "family.h"
#include "files.h"
#include "forceddist.h"
#include "map.h"
#include "options.h"
#include "singlelocus.h"
#include "utils.h"
#include "vecutil.h"
#include "fmtout.h"

Forceddist::Forceddist(const string &forced, const string &famforced) :
    Viterbidist("fpt"), overallforced(0) {
  forcedfile.setname(forced, "forced.out");
  famforcedfile.setname(famforced, "f" + forcedfile.name);
}

void Forceddist::reset(Uint np) {
  if (forcedfile.is_open()) {
    forcedfile.close();
    famforcedfile.close();
  }
  forcedfile.open();
  famforcedfile.open();
  delete [] overallforced;
  overallforced = new Uint[map->loci.size()];
  zero(overallforced, map->loci.size());
  Viterbidist::reset(np);
}

Forceddist *Forceddist::getforceddist(const string &forced,
                                      const string &famforced) {
  for (Uint d = 0; d < distributions.size(); d++)
    optassert(distributions[d]->getpt() != "fpt",
              "More than one FORCEDXOVERS lines.");
  return new Forceddist(forced, famforced);
}

Forceddist::~Forceddist() {
  delete [] overallforced;
}

void Forceddist::forcedrecombout() {
  Uint total = 0;
  for (Uint gam = 0; gam < map->loci.size() - 1; gam++) {
    Uint forced = countrecombs(curfamily(), path[gam], path[gam + 1]);
    overallforced[gam] += forced;
    total += forced;
    famforcedfile << curfamily()->id << "\t";
    famforcedfile.setf(ios::right, ios::adjustfield);
    fmtout(famforcedfile, 7, 3, map->loci[gam].positionAvg(), 0);
    fmtout(famforcedfile, 9, forced);
    famforcedfile << "  " << map->loci[gam].name << "\n";
  }
  famforcedfile << curfamily()->id << "\t" << "Total:\t" << total << "\t"
                      << map->loci.back().name << "\n";
}

void Forceddist::overallforcedrecombout() {
  Uint total = 0;
  for (Uint gam = 0; gam < map->loci.size() - 1; gam++) {
    total += overallforced[gam];
    fmtout(forcedfile, 7, 3, map->loci[gam].positionAvg(), 0);
    fmtout(forcedfile, 9, overallforced[gam]);
    forcedfile << "  " << map->loci[gam].name << "\n";
  }
  forcedfile << "Total:\t" << total << "\t" << map->loci.back().name << "\n";
}

void Forceddist::print() const {
  message("FORCEDXOVERS " + forcedfile.name + " " + famforcedfile.name);
}

void Forceddist::set(FloatVec pv, Uint pos) {
  Viterbidist::set(pv, pos);
  if (pos == 0) forcedrecombout();
}

void Forceddist::set(ADD &pv, double sum_pv, Uint pos) {
  Viterbidist::set(pv, sum_pv, pos);
  if (pos == 0) forcedrecombout();
}

void Forceddist::gettheta(Uint, Float &tht, Float &tht_female) const {
  tht = tht_female = .1;
}
