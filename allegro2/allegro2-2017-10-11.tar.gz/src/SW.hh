#ifndef _SW
#define _SW

#ifdef STOPWATCH
#include "StopWatch.hh"

#define SW_START(x) stop_watch.start(x)
#define SW_STOP(x) stop_watch.stop(x)
#define SW_REPORT(x) stop_watch.report(x)

#else // STOPWATCH

#define SW_START(x)
#define SW_STOP(x)
#define SW_REPORT(x)

#endif // STOPWATCH

#endif // _SW
