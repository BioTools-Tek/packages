#include "findscore.h"
#include "calcscore.h"
#include "files.h"
#include "options.h"

void Scoreperson::resetdstat() {
  if (per->founder()) {
    Double initcount = per->dstat == AFFECTED ? 1.0 : 0.0;
    nod[0]->setinitcount(initcount);
    nod[1]->setinitcount(initcount);
    if (next != 0)
      ((Scoreperson *)next)->resetdstat();
  }
}

Scoreperson::Scoreperson(Person *p, Scoreperson *first) :
    Pairwiseperson<Founderallele>(p, first) {
  if (isfounder()) {
    Double initcount = per->dstat == AFFECTED ? 1.0 : 0.0;
    nod[0]->setinitcount(initcount);
    if (!options->sexlinked || per->sex == FEMALE)
      nod[1]->setinitcount(initcount);
  }
}

void Scoreperson::calcsall(IV v, Double B, DoubleVec S) {
  int Kf = per->patmask ? 1 : 0;
  int Km = per->matmask ? 1 : 0;

  for (int K1 = 0; K1 <= Km; K1++) {
    if (K1) v += per->matmask;
    if (mother != 0) nod[1] = mother->nod[K1];
    for (int K0 = 0; K0 <= Kf; K0++) {
      if (K0) v += per->patmask;
      if (father != 0 && (!options->sexlinked || per->sex == FEMALE))
        nod[0] = father->nod[K0];
      else if (father != 0) nod[0] = nod[1];
      if (per->dstat == AFFECTED) {
        if (next == 0) {
          S[v] += B*(nod[0]->count + 1.0);
          if (!options->sexlinked || per->sex == FEMALE)
            S[v] += B*(nod[1]->count + 1.0);
        }
        else {
          Double Bnew = B;
          nod[0]->addsall(Bnew);
          ((Scoreperson *)next)->calcsall(v, Bnew, S);
          nod[0]->remove();
          if (!options->sexlinked || per->sex == FEMALE) {
            Bnew = B;
            nod[1]->addsall(Bnew);
            ((Scoreperson *)next)->calcsall(v, Bnew, S);
            nod[1]->remove();
          }
        }
      }
      else {
        if (next == 0) S[v] += B;
        else ((Scoreperson *)next)->calcsall(v, B, S);
      }
    }
    v &= ~per->patmask;
  }
}

void Scoreperson::calcsrobdom(IV v, Double B, DoubleVec S) {
  int Kf = per->patmask ? 1 : 0;
  int Km = per->matmask ? 1 : 0;

  for (int K1 = 0; K1 <= Km; K1++) {
    if (K1) v += per->matmask;
    if (mother != 0) nod[1] = mother->nod[K1];
    for (int K0 = 0; K0 <= Kf; K0++) {
      if (K0) v += per->patmask;
      if (father != 0 && (!options->sexlinked || per->sex == FEMALE))
        nod[0] = father->nod[K0];
      else if (father != 0) nod[0] = nod[1];
      Double Bnew = B;
      if (per->dstat == AFFECTED) {
        nod[0]->addsrobdom(Bnew);
        if (nod[0] != nod[1]) nod[1]->addsrobdom(Bnew);
      }
      if (next == 0) S[v] += Bnew;
      else ((Scoreperson *)next)->calcsrobdom(v, Bnew, S);
      if (per->dstat == AFFECTED) {
        nod[0]->removesrobdom();
        if (nod[0] != nod[1]) nod[1]->removesrobdom();
      }
    }
    v &= ~per->patmask;
  }
}

void Scoreperson::calcsmnallele(IV v, Double B, DoubleVec S) {
  int Kf = per->patmask ? 1 : 0;
  int Km = per->matmask ? 1 : 0;

  for (int K1 = 0; K1 <= Km; K1++) {
    if (K1) v += per->matmask;
    if (mother != 0) nod[1] = mother->nod[K1];
    for (int K0 = 0; K0 <= Kf; K0++) {
      if (K0) v += per->patmask;
      if (father != 0 && (!options->sexlinked || per->sex == FEMALE))
        nod[0] = father->nod[K0];
      else if (father != 0) nod[0] = nod[1];
      Double Bnew = B;
      if (per->dstat == AFFECTED) {
        nod[0]->addsmnallele(Bnew);
        if (!options->sexlinked || per->sex == FEMALE)
          nod[1]->addsmnallele(Bnew);
      }
      if (next == 0) S[v] += Bnew;
      else ((Scoreperson *)next)->calcsmnallele(v, Bnew, S);
      if (per->dstat == AFFECTED) {
        nod[0]->remove();
        if (!options->sexlinked || per->sex == FEMALE)
          nod[1]->remove();
      }
    }
    v &= ~per->patmask;
  }
}

void Scoreperson::calcspairs(IV v, Double B, DoubleVec S, bool homoz) {
  int Kf = per->patmask ? 1 : 0;
  int Km = per->matmask ? 1 : 0;

  for (int K1 = 0; K1 <= Km; K1++) {
    if (K1) v += per->matmask;
    nod[1] = mother->nod[K1];
    for (int K0 = 0; K0 <= Kf; K0++) {
      if (K0) v += per->patmask;
      if (!options->sexlinked || per->sex == FEMALE) nod[0] = father->nod[K0];
      else nod[0] = nod[1];
      if (per->dstat == AFFECTED) {
        Double Bnew = B + nod[0]->count;
        Bnew += (!homoz && (!options->sexlinked || per->sex == FEMALE) ||
                 ((homoz && options->sexlinked) && (per->sex)) == MALE ?
                 nod[1]->count : 0);
        nod[0]->addspairs();
        if (!options->sexlinked || per->sex == FEMALE) {
          Bnew += homoz ? nod[1]->count : 0;
          nod[1]->addspairs();
        }
        if (next == 0) S[v] += Bnew;
        else ((Scoreperson *)next)->calcspairs(v, Bnew, S, homoz);
        if (!options->sexlinked || per->sex == FEMALE) nod[1]->remove();
        nod[0]->remove();
      }
      else {
        if (next == 0) S[v] += B;
        else ((Scoreperson *)next)->calcspairs(v, B, S, homoz);
      }
    }
    v &= ~per->patmask;
  }
}

void Scoreperson::calcspairs_ps(IV v, Double B, DoubleVec S,
                                Double w_mm, Double w_mf, Double w_ff) {
  int Kf = per->patmask ? 1 : 0;
  int Km = per->matmask ? 1 : 0;

  for (int K1 = 0; K1 <= Km; K1++) {
    if (K1) v += per->matmask;
    nod[1] = mother->nod[K1];
    for (int K0 = 0; K0 <= Kf; K0++) {
      if (K0) v += per->patmask;
      nod[0] = father->nod[K0];
      if (per->dstat == AFFECTED) {
        Double Bnew = B;
        Bnew += w_mf*nod[1]->count_pat + w_mm*nod[1]->count_mat;
        if (!options->sexlinked || per->sex == FEMALE) {
          Bnew += w_ff*nod[0]->count_pat + w_mf*nod[0]->count_mat;
          nod[0]->addps_pat();
        }
        nod[1]->addps_mat();
        if (next == 0) S[v] += Bnew;
        else ((Scoreperson *)next)->calcspairs_ps(v, Bnew, S, w_mm, w_mf, w_ff);
        if (!options->sexlinked || per->sex == FEMALE)
          nod[0]->removeps_pat();
        nod[1]->removeps_mat();
      }
      else {
        if (next == 0) S[v] += B;
        else ((Scoreperson *)next)->calcspairs_ps(v, B, S, w_mm, w_mf, w_ff);
      }
    }
    v &= ~per->patmask;
  }
}

DdNode *Scoreperson::calcsall(double B, DdManager *mgr) {
  Uint Kf = per->patmask ? 1 : 0;
  Uint Km = per->matmask ? 1 : 0;

  DdNode *qdd_00 = 0, *qdd_01 = 0, *qdd_10 = 0, *qdd_11 = 0;

//   assert(Cudd_DebugCheck(mgr) == 0);

  for (Uint K1 = 0; K1 <= Km; K1++) {
    if (mother != 0) nod[1] = mother->nod[K1];
    for (Uint K0 = 0; K0 <= Kf; K0++) {
      if (father != 0 && (!options->sexlinked || per->sex == FEMALE))
        nod[0] = father->nod[K0];
      else if (father != 0) nod[0] = nod[1];
      DdNode *&cur_qdd = (K0 == 0 ? (K1 == 0 ? qdd_00 : qdd_10) :
                          (K1 == 0 ? qdd_01 : qdd_11));
      assert(cur_qdd == 0);
      if (per->dstat == AFFECTED) {
        if (next == 0) {
          double Bnew = B*(nod[0]->count + 1.0);
          if (!options->sexlinked || per->sex == FEMALE)
            Bnew += B*(nod[1]->count + 1.0);
          cur_qdd = cuddUniqueConst(mgr, Bnew);
        }
        else {
          double Bnew = B;
          nod[0]->addsall(Bnew);
          cur_qdd = ((Scoreperson *)next)->calcsall(Bnew, mgr);
          nod[0]->remove();
          if (!options->sexlinked || per->sex == FEMALE) {
            Bnew = B;
            nod[1]->addsall(Bnew);
            cuddRef(cur_qdd);
            DdNode *alt = ((Scoreperson *)next)->calcsall(Bnew, mgr);
            cuddRef(alt);
//             cout << "cur_qdd"; Cudd_PrintDebug(mgr, cur_qdd, 2, 2);
//             cout << "alt"; Cudd_PrintDebug(mgr, alt, 2, 2);
            DdNode *s = Cudd_addApply(mgr, Cudd_addPlus, cur_qdd, alt);
//             cout << "s"; Cudd_PrintDebug(mgr, s, 2, 2);
            Cudd_RecursiveDeref(mgr, alt);
            Cudd_RecursiveDeref(mgr, cur_qdd);
            cur_qdd = s;
            nod[1]->remove();
          }
        }
      }
      else {
        if (next == 0) cur_qdd = cuddUniqueConst(mgr, B);

        else cur_qdd = ((Scoreperson *)next)->calcsall(B, mgr);
      }
      assert(cur_qdd != 0);
      cuddRef(cur_qdd);
//       assert(Cudd_DebugCheck(mgr) == 0);
    }
  }

  return collectresults(mgr, qdd_00, qdd_01, qdd_10, qdd_11, Kf, Km);
}

DdNode *Scoreperson::calcsrobdom(double B, DdManager *mgr) {
  Uint Kf = per->patmask ? 1 : 0;
  Uint Km = per->matmask ? 1 : 0;

  DdNode *qdd_00 = 0, *qdd_01 = 0, *qdd_10 = 0, *qdd_11 = 0;

  for (Uint K1 = 0; K1 <= Km; K1++) {
    if (mother != 0) nod[1] = mother->nod[K1];
    for (Uint K0 = 0; K0 <= Kf; K0++) {
      if (father != 0 && (!options->sexlinked || per->sex == FEMALE))
        nod[0] = father->nod[K0];
      else if (father != 0) nod[0] = nod[1];
      DdNode *&cur_qdd = (K0 == 0 ? (K1 == 0 ? qdd_00 : qdd_10) :
                          (K1 == 0 ? qdd_01 : qdd_11));
      double Bnew = B;
      if (per->dstat == AFFECTED) {
        nod[0]->addsrobdom(Bnew);
        if (nod[0] != nod[1]) nod[1]->addsrobdom(Bnew);
      }
      if (next == 0) cur_qdd = cuddUniqueConst(mgr, Bnew);
      else cur_qdd = ((Scoreperson *)next)->calcsrobdom(Bnew, mgr);
      if (per->dstat == AFFECTED) {
        nod[0]->removesrobdom();
        if (nod[0] != nod[1]) nod[1]->removesrobdom();
      }
      cuddRef(cur_qdd);
    }
  }

//   assert(Cudd_DebugCheck(mgr) == 0);
  return collectresults(mgr, qdd_00, qdd_01, qdd_10, qdd_11, Kf, Km);
}

DdNode *Scoreperson::calcsmnallele(double B, DdManager *mgr) {
  Uint Kf = per->patmask ? 1 : 0;
  Uint Km = per->matmask ? 1 : 0;

  DdNode *qdd_00 = 0, *qdd_01 = 0, *qdd_10 = 0, *qdd_11 = 0;

  for (Uint K1 = 0; K1 <= Km; K1++) {
    if (mother != 0) nod[1] = mother->nod[K1];
    for (Uint K0 = 0; K0 <= Kf; K0++) {
      if (father != 0 && (!options->sexlinked || per->sex == FEMALE))
        nod[0] = father->nod[K0];
      else if (father != 0) nod[0] = nod[1];
      DdNode *&cur_qdd = (K0 == 0 ? (K1 == 0 ? qdd_00 : qdd_10) :
                          (K1 == 0 ? qdd_01 : qdd_11));
      double Bnew = B;
      if (per->dstat == AFFECTED) {
        nod[0]->addsmnallele(Bnew);
        if (!options->sexlinked || per->sex == FEMALE)
          nod[1]->addsmnallele(Bnew);
      }
      if (next == 0) cur_qdd = cuddUniqueConst(mgr, Bnew);
      else cur_qdd = ((Scoreperson *)next)->calcsmnallele(Bnew, mgr);
      if (per->dstat == AFFECTED) {
        nod[0]->remove();
        if (!options->sexlinked || per->sex == FEMALE)
          nod[1]->remove();
      }
      cuddRef(cur_qdd);
    }
  }

  return collectresults(mgr, qdd_00, qdd_01, qdd_10, qdd_11, Kf, Km);
}

DdNode *Scoreperson::calcspairs(double B, bool homoz, DdManager *mgr) {
  Uint Kf = per->patmask ? 1 : 0;
  Uint Km = per->matmask ? 1 : 0;

  DdNode *qdd_00 = 0, *qdd_01 = 0, *qdd_10 = 0, *qdd_11 = 0;

  for (Uint K1 = 0; K1 <= Km; K1++) {
    nod[1] = mother->nod[K1];
    for (Uint K0 = 0; K0 <= Kf; K0++) {
      if (!options->sexlinked || per->sex == FEMALE) nod[0] = father->nod[K0];
      else nod[0] = nod[1];
      DdNode *&cur_qdd = (K0 == 0 ? (K1 == 0 ? qdd_00 : qdd_10) :
                          (K1 == 0 ? qdd_01 : qdd_11));
      if (per->dstat == AFFECTED) {
        double Bnew = B + nod[0]->count;
        Bnew += ((!homoz && (!options->sexlinked || per->sex == FEMALE)) ||
                 ((homoz && options->sexlinked) && per->sex) == MALE ?
                 nod[1]->count : 0);
        nod[0]->addspairs();
        if (!options->sexlinked || per->sex == FEMALE) {
          Bnew += homoz ? nod[1]->count : 0;
          nod[1]->addspairs();
        }
        if (next == 0)
          cur_qdd = cuddUniqueConst(mgr, Bnew);
        else
          cur_qdd = ((Scoreperson *)next)->calcspairs(Bnew, homoz, mgr);
        if (!options->sexlinked || per->sex == FEMALE) nod[1]->remove();
        nod[0]->remove();
      }
      else {
        if (next == 0)
          cur_qdd = cuddUniqueConst(mgr, B);
        else
          cur_qdd = ((Scoreperson *)next)->calcspairs(B, homoz, mgr);
      }
      cuddRef(cur_qdd);
    }
  }

  return collectresults(mgr, qdd_00, qdd_01, qdd_10, qdd_11, Kf, Km);
}

// Not implemented for X-linked
DdNode *Scoreperson::calcspairs_ps(double B, double w_mm, double w_mf,
                                   double w_ff, DdManager *mgr) {
  Uint Kf = per->patmask ? 1 : 0;
  Uint Km = per->matmask ? 1 : 0;

  DdNode *qdd_00 = 0, *qdd_01 = 0, *qdd_10 = 0, *qdd_11 = 0;

  for (Uint K1 = 0; K1 <= Km; K1++) {
    nod[1] = mother->nod[K1];
    for (Uint K0 = 0; K0 <= Kf; K0++) {
      nod[0] = father->nod[K0];
      DdNode *&cur_qdd = (K0 == 0 ? (K1 == 0 ? qdd_00 : qdd_10) :
                          (K1 == 0 ? qdd_01 : qdd_11));
      if (per->dstat == AFFECTED) {
        Double Bnew = B;
        Bnew += w_mf*nod[1]->count_pat + w_mm*nod[1]->count_mat;
        if (!options->sexlinked || per->sex == FEMALE) {
          Bnew += w_ff*nod[0]->count_pat + w_mf*nod[0]->count_mat;
          nod[0]->addps_pat();
        }
        nod[1]->addps_mat();
        if (next == 0) cur_qdd = cuddUniqueConst(mgr, Bnew);
        else cur_qdd = ((Scoreperson *)next)->calcspairs_ps(Bnew, w_mm,
                                                            w_mf, w_ff, mgr);
        if (!options->sexlinked || per->sex == FEMALE)
          nod[0]->removeps_pat();
        nod[1]->removeps_mat();
      }
      else {
        if (next == 0) cur_qdd = cuddUniqueConst(mgr, B);
        else cur_qdd = ((Scoreperson *)next)->calcspairs_ps(B, w_mm, w_mf,
                                                            w_ff, mgr);
      }
      cuddRef(cur_qdd);
    }
  }

  return collectresults(mgr, qdd_00, qdd_01, qdd_10, qdd_11, Kf, Km);
}

void Scoreperson::calcsharing(double B, DdNode *&S1, DdNode *&S2, Person *p,
                              Person *q, DdManager *mgr) {
  Uint Kf = per->patmask ? 1 : 0;
  Uint Km = per->matmask ? 1 : 0;

  DdNode *qdd_1_00 = 0, *qdd_1_01 = 0, *qdd_1_10 = 0, *qdd_1_11 = 0;
  DdNode *qdd_2_00 = 0, *qdd_2_01 = 0, *qdd_2_10 = 0, *qdd_2_11 = 0;

  for (Uint K1 = 0; K1 <= Km; K1++) {
    nod[1] = mother != 0 ? mother->nod[K1] : 0;
    for (Uint K0 = 0; K0 <= Kf; K0++) {
      if (!options->sexlinked || per->sex == FEMALE)
        nod[0] = father != 0 ? father->nod[K0] : 0;
      else
        nod[0] = nod[1];
      DdNode *&cur_1_qdd = (K0 == 0 ? (K1 == 0 ? qdd_1_00 : qdd_1_10) :
                            (K1 == 0 ? qdd_1_01 : qdd_1_11));
      DdNode *&cur_2_qdd = (K0 == 0 ? (K1 == 0 ? qdd_2_00 : qdd_2_10) :
                            (K1 == 0 ? qdd_2_01 : qdd_2_11));
      if (per == p || per == q) {
        double Bnew = B + (nod[0] == 0 ? .0 : nod[0]->count);
        Bnew += (nod[1] != 0 && (!options->sexlinked || per->sex == FEMALE) ?
                 nod[1]->count : .0);
        if (nod[0] != 0) nod[0]->addspairs();
        if (nod[1] != 0 && (!options->sexlinked || per->sex == FEMALE))
          nod[1]->addspairs();
        if (next == 0) {
          cur_1_qdd = cur_2_qdd = mgr->zero;
          if (Bnew > .5 && Bnew < 1.5)
            cur_1_qdd = mgr->one;
          else if (Bnew > 1.5)
            cur_2_qdd = mgr->one;
        } else
          ((Scoreperson *)next)->calcsharing(Bnew, cur_1_qdd, cur_2_qdd, p, q,
                                             mgr);
        if (nod[1] != 0 && (!options->sexlinked || per->sex == FEMALE))
          nod[1]->remove();
        if (nod[0] != 0)
          nod[0]->remove();
      }
      else {
        if (next == 0) {
          cur_1_qdd = cur_2_qdd = mgr->zero;
          if (B > .5 && B < 1.5)
            cur_1_qdd = mgr->one;
          else if (B > 1.5)
            cur_2_qdd = mgr->one;
        } else
          ((Scoreperson *)next)->calcsharing(B, cur_1_qdd, cur_2_qdd, p, q,
                                             mgr);
      }
      cuddRef(cur_1_qdd);
      cuddRef(cur_2_qdd);
    }
  }

  S1 = collectresults(mgr, qdd_1_00, qdd_1_01, qdd_1_10, qdd_1_11, Kf, Km);
  S2 = collectresults(mgr, qdd_2_00, qdd_2_01, qdd_2_10, qdd_2_11, Kf, Km);
}
