#ifndef _PARAMETRIC
#define _PARAMETRIC
#include "basic.h"

class Linkagemodel : public Model {
public:
  Linkagemodel(const string &p) : Model(p), lod(0) {}
  virtual void output();
  virtual bool getsexlinked() const;

protected:
  DoubleVec lod;
  DoubleVec alphahat;
  DoubleVec hlod;

  virtual bool heterogeneity() const {return false;}
  virtual void totline(ostream &f, Uint pos);
  virtual void famline(ostream &f, Uint ifa, Uint pos);
  virtual void totheader(ostream &f);
  virtual void famheader(ostream &f);
  string getX() const {return getsexlinked() ? "X" : "";}
  DoubleVec LOD(bool dohet);
};

#endif // _PARAMETRIC
