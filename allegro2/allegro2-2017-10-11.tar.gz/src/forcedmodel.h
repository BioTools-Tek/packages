#ifndef _FORCEDMODEL
#define _FORCEDMODEL
#include "basic.h"
#include "model.h"

class Forcedmodel : public Model {
public:
  Forcedmodel(const string &forced, const string &famforced);
  
  virtual void output();
  // prints description
  virtual void print() const;
protected:
  virtual void totline(ostream &/*f*/, Uint /*pos*/) {}
  virtual void famline(ostream &/*f*/, Uint /*ifa*/, Uint /*pos*/) {}
  virtual void totheader(ostream &/*f*/) {}
  virtual void famheader(ostream &/*f*/) {}
};

#endif // _FORCEDMODEL
