#include "files.h"
#include "distribution.h"
#include "asmmodel.h"
#include "options.h"
#include <iostream>
#include <iomanip>
#include "fmtout.h"
#include "modelweight.h"
#include "entropy.h"

const Double ALLEGROLOG10 = log(10.0);

ASMmodel::ASMmodel(const string &pt, const string &mo) :
    Model(pt), model(mo) {}

void spacetodot(string &s) {
  for (Uint i = 0; i < s.length(); i++)
    if (s[i] == ' ') s[i] = '.';
}

void ASMmodel::setupfiles(const string &outf, const string &foutf) {
  string desc = distribution->describe().c_str();
  spacetodot(desc);
  setfiles(outf, foutf, model + desc + "." +
           modelweight->describe() + "." + pt, "allele sharing model output");

  string on = outfile.name;
  string::size_type lastslash = on.find_last_of("/");
  string fname;
  if (lastslash == string::npos) fname = "i" + on;
  else fname = (on.substr(0, lastslash + 1) + "i" + on.substr(lastslash + 1));
  ioutfile.setname(fname, fname);
}

void ASMmodel::print() const {
  string famf = ((options->famfiles == OB_NOTSET && famfiles) ||
                 options->famfiles == OB_ON) ? " " + foutfile.name : "";
  string info = (options->faminfo ? " " + ioutfile.name : "");
  message("MODEL " + pt + " " + model + " " + distribution->describe() + " " +
          modelweight->describe() + " " + outfile.name + famf +
          info);
}

void ASMmodel::initialize() {
  if (options->entropy)
    entropy = Entropy::getentropy(pt);

  dhat = new Double[npos()];
  zlr = new Double[npos()];
  npl = new Double[npos()];
  lod = new Double[npos()];
  flod = newmatrix<Double>(nfam(), npos());
  wnpl = newmatrix<Double>(nfam(), npos());
  if (Distribution::isnullconstant()) {
    nullmean = new DoubleVec[npos()];
    nullsd = new DoubleVec[npos()];
    weight = new DoubleVec[npos()];
    nullmean[0] = new Double[nfam()];
    nullsd[0] = new Double[nfam()];
    weight[0] = new Double[nfam()];
    for (Uint pos = 1; pos < npos(); pos++) {
      nullmean[pos] = nullmean[0];
      nullsd[pos] = nullsd[0];
      weight[pos] = weight[0];
    }
  }
  else {
    nullmean = newmatrix<Double>(npos(), nfam());
    nullsd = newmatrix<Double>(npos(), nfam());
    weight = newmatrix<Double>(npos(), nfam());
  }
  faminfo = newmatrix<Double>(nfam(), npos());
  information = newmatrix<Double>(4, npos());
  // Initialize weights
  modelweight->initialize(distribution->families);
}

void ASMmodel::cleanup() {
  delete [] dhat;
  delete [] zlr;
  delete [] npl;
  delete [] lod;
  deletematrix(flod);
  deletematrix(wnpl);
  if (Distribution::isnullconstant()) {
    delete [] nullmean[0];
    delete [] nullsd[0];
    delete [] weight[0];
    delete [] nullmean;
    delete [] nullsd;
    delete [] weight;
  }
  else {
    deletematrix(nullmean);
    deletematrix(nullsd);
    deletematrix(weight);
  }
  deletematrix(faminfo);
  deletematrix(information);
}

void ASMmodel::assignweights() const {
  for (Uint pos = 0; pos < (Distribution::isnullconstant() ? 1 : npos());
       pos++) {
    Double sumofsquares = 0.0;
    for(Uint fam = 0; fam < nfam(); fam++) {
      weight[pos][fam] = modelweight->assign(getfamid(fam), nullsd[pos][fam]);
      sumofsquares += square(weight[pos][fam]);
    }
    sumofsquares = sqrt(sumofsquares/Double(nfam()));
    if (sumofsquares != 0.0)
      for(Uint fam = 0; fam < nfam(); fam++)
        weight[pos][fam] /= sumofsquares;
  }
}

void ASMmodel::compute_final_stats() {
  for(Uint pos = 0; pos < npos(); pos++) {
    Double scale = 0.0;
    for(Uint fam = 0; fam < nfam(); fam++)
      scale += (weight[pos][fam]*weight[pos][fam]);
    scale = sqrt(scale);

    npl[pos] = .0;
    for(Uint fam=0; fam < nfam(); fam++)
      npl[pos] += wnpl[fam][pos];
    npl[pos] /= scale;
  }

  Double constant = 2.*log(10.);
  for(Uint pos = 0; pos < npos(); pos++) {
    if(dhat[pos] < .0) {
      zlr[pos] = -1.*sqrt(constant*lod[pos]);
    } else {
      zlr[pos] = sqrt(constant*lod[pos]);
    }
  }
}

void ASMmodel::output() {
  initialize();
  assignweights();
  run();
  compute_fam_info();
  Output::output();
  if (options->faminfo) printfaminfo();
  cleanup();
}

ASMmodel::~ASMmodel() {
  delete modelweight;
}

void ASMmodel::totline(ostream &f, Uint pos) {
  fmtout(f, 10, 4, lod[pos]);
  fmtout(f, 9, 4, dhat[pos]);
  fmtout(f, 9, 4, npl[pos]);
  fmtout(f, 9, 4, zlr[pos]);
  if (donplexactp) fmtout(f, 10, 6, nplexactps[pos], 1, 0.001);
  if (dolodexactp) fmtout(f, 10, 6, lodexactps[pos], 1, 0.001);
  if (model == "exp" || model.substr(0, 4) == "poly")
    fmtout(f, 9, 4, information[2][pos]);
  if (options->entropy) fmtout(f, 9, 4, entropy->info(pos));
  f << "   ";
}

Float sgn(Float x) {return x < 0 ? -1.0 : 1.0;}

void ASMmodel::famline(ostream &f, Uint ifa, Uint pos) {
  Double fl = flod[ifa][pos]*sgn(dhat[pos]);
  Double Z = sqrt(2*ALLEGROLOG10*fabs(fl));
  Z *= sgn(fl);
  f.setf(ios::right, ios::adjustfield);
  fmtout(f, 10, 4, fl);
  fmtout(f, 9, 4, wnpl[ifa][pos]/(weight[pos][ifa] != 0 ?
                                  weight[pos][ifa] : 1.0));
  fmtout(f, 9, 4, Z);
  fmtout(f, 9, 4, faminfo[ifa][pos]);
  if (options->entropy) fmtout(f, 9, 4, entropy->faminfo(ifa, pos));
  f << "   ";
}

void ASMmodel::totheader(ostream &f) {
  f << "     LOD     dhat      NPL      Zlr  ";
  if (donplexactp) f << "nplexactp ";
  if (dolodexactp) f << "lodexactp ";
  if (model == "exp" || model.substr(0, 4) == "poly") f << "   info ";
  if (options->entropy) f << "  entropy";
  f << "   ";
}

void ASMmodel::famheader(ostream &f) {
  f << "     LOD      NPL      Zlr    ";
  f << " info ";
  if (options->entropy) f << "  entropy";
  f << "   ";
}
