#include "BFunction.hh"
#include "options.h"
#include "cuddutil.h"
#include "vecutil.h"
#include "ZUtils.hh"
#include "Unreduced.hh"

// This is a hack to fix a problem in older version of gcc <cmath>
#ifndef HAVE_SIGNBIT_IN_CMATH
#ifdef HAVE___SIGNBITD
#define signbit(x) __signbitd(x)
#elif HAVE___SIGNBIT
#define signbit(x) __signbit(x)
#else
#error "No signbit function available!"
#endif
#endif // HAVE_SIGNBIT_IN_CMATH

/////////////////////////////////////////////////////////////////////////////
// BFunction
BFunction::~BFunction() {
  if (m_own_swap_file && m_swap_file != "")
    remove(m_swap_file.c_str());
}

/////////////////////////////////////////////////////////////////////////////
// ADDFunction
void ADDFunction::writeToFile(const string &fn, bool swap) {
  SW_START("ADDFunction::writeToFile");
  writeADD(fn, m_add);
  SW_STOP("ADDFunction::writeToFile");
  if (swap) {
    m_own_swap_file = true;
    m_swap_file = fn;
    m_add = ADD();
  }
}

void ADDFunction::transfer(Cudd &mgr) {
  m_add = addTransfer(m_add, mgr);
  m_manager = &mgr;
}

ADD &ADDFunction::getADD() {
  if (!inMemory()) {
    SW_START("ADDFunction::getADD");
    m_add = readADD(m_swap_file, *m_manager);
    SW_STOP("ADDFunction::getADD");
    if (m_own_swap_file)
      remove(m_swap_file.c_str());
    m_swap_file = "";
  }
  return m_add;
}

ADDFunction::ADDFunction(ADDFunction &f, const string &f_swap_file) :
    BFunction(f.m_manager) {
  m_add = f.getADD();
  if (f_swap_file != "")
    f.writeToFile(f_swap_file, true);
}

void ADDFunction::inplaceMult(ADD &x) {
  if (!inMemory()) getADD();
  ::inplaceMult(m_add, addTransfer(x, *m_manager), m_manager->ReadSize()/3);
}

void ADDFunction::integrateOut(const set<Unreduced> &bits) {
  if (!inMemory()) getADD();

  SW_START("ADDFunction::integrateOut");
  for (set<Unreduced>::const_iterator bit = bits.begin(); bit != bits.end();
       bit++)
    if (bit->type == Unreduced::REGULAR) {
      ADD bv(m_manager->addVar(bit->begin));
      ADD res_0 = m_add.Cofactor(~bv);
      ADD res_1 = m_add.Cofactor(bv);
      m_add = res_0 + res_1;
    }//  else  no point really ...
//       res += bit->transform(res);
  SW_STOP("ADDFunction::integrateOut");
}

DdNode *diffManagerProd(DdNode *a, DdManager *a_mgr,
                        DdNode *b, DdManager *b_mgr, CuddCacheNN_N &cache) {
  if (cuddIsConstant(b)) {
    if (cuddIsConstant(a))
      return cuddUniqueConst(a_mgr, cuddV(a)*cuddV(b));
    else if (cuddV(b) == 1.)
      return a;
    else if (cuddV(b) == .0)
      return a_mgr->zero;
  } else if (cuddIsConstant(a) && cuddV(a) == .0)
    return a;

  const int a_level = cuddI(a_mgr, a->index);
  const int b_level = cuddI(b_mgr, b->index);

  const bool use_cache = a_mgr->size > a_level + a_mgr->size/4;
  if (use_cache) {
    CuddCacheNN_N::const_iterator ci = cache.find(make_pair(a, b));
    if (ci != cache.end()) return ci->second;
  }

  DdNode *T, *E;
  int index;
  if (a_level == b_level) {
    index = a->index;
    T = diffManagerProd(cuddT(a), a_mgr, cuddT(b), b_mgr, cache);
    cuddRef(T);
    E = diffManagerProd(cuddE(a), a_mgr, cuddE(b), b_mgr, cache);
  } else if (a_level < b_level) {
    index = a->index;
    T = diffManagerProd(cuddT(a), a_mgr, b, b_mgr, cache);
    cuddRef(T);
    E = diffManagerProd(cuddE(a), a_mgr, b, b_mgr, cache);
  } else { // a_level > b_level
    index = b->index;
    T = diffManagerProd(a, a_mgr, cuddT(b), b_mgr, cache);
    cuddRef(T);
    E = diffManagerProd(a, a_mgr, cuddE(b), b_mgr, cache);
  }
  cuddRef(E);
  DdNode *res = (T == E) ? T : cuddUniqueInter(a_mgr, index, T, E);
  cuddDeref(T);
  cuddDeref(E);

  if (use_cache) {
    if (cache.size() > (1 << 20)) cache.clear();
    cache[make_pair(a, b)] = res;
  }

  return res;
}

ADD diffManagerProd(ADD &left, ADD &right) {
  CuddCacheNN_N &cache =
    CuddCacheManager::getCacheNN_N("diffManagerProd",
                                   left.manager()->getManager());
  DdNode *res = diffManagerProd(left.getNode(), left.manager()->getManager(),
                                right.getNode(), right.manager()->getManager(),
                                cache);
  CuddCacheManager::removeCache("diffManagerProd",
                                left.manager()->getManager());

  return ADD(left.manager(), res);
}

void ADDFunction::inplaceMultBF(BFunction &x) {
  if (!inMemory()) getADD();

  if (x.type() == ADD_FUN) {
    assertinternal(m_manager == m_add.manager());
    if (m_manager == &x.manager())
      inplaceMult(dynamic_cast<ADDFunction &>(x).getADD());
    else {
      assertinternal(equal(m_manager->getManager()->perm,
                           m_manager->getManager()->perm +
                           m_manager->ReadSize(),
                           x.manager().getManager()->perm));
      m_add = diffManagerProd(m_add, dynamic_cast<ADDFunction &>(x).getADD());
    }
  } else
    todo("ADD_FUN.inplaceMultBF(VECTOR_FUN) shouldn't be needed");
}

void ADDFunction::transferTo(Cudd &mgr) {
  if (!inMemory()) getADD();
  m_add = addTransfer(m_add, mgr);
  m_manager = &mgr;
}

inline double dotProduct(DdManager *mgr, DdNode *x, DdNode *y,
                         CuddCacheNN_D &dotprod_cache,
                         CuddCacheN_D &sum_cache) {
  if (cuddIsConstant(x)) {
    const double vx = cuddV(x);
    return vx == .0 ? .0 : vx*sum(mgr, y, sum_cache);
  } else if (cuddIsConstant(y)) {
    const double vy = cuddV(y);
    return vy == .0 ? .0 : vy*sum(mgr, x, sum_cache);
  }

  const int x_level = mgr->perm[x->index];
  const int y_level = mgr->perm[y->index];
  const bool use_cache = mgr->size > min(x_level, y_level) + mgr->size/4;
  if (use_cache) {
    if (y < x) swap(x, y);
    CuddCacheNN_D::const_iterator ci = dotprod_cache.find(make_pair(x, y));
    if (ci != dotprod_cache.end()) return ci->second;
  }

  double res;
  if (x_level == y_level)
    res = .5*(dotProduct(mgr, cuddT(x), cuddT(y), dotprod_cache, sum_cache) +
              dotProduct(mgr, cuddE(x), cuddE(y), dotprod_cache, sum_cache));
  else if (x_level < y_level)
    res = .5*(dotProduct(mgr, cuddT(x), y, dotprod_cache, sum_cache) +
              dotProduct(mgr, cuddE(x), y, dotprod_cache, sum_cache));
  else // x_level > y_level
    res = .5*(dotProduct(mgr, x, cuddT(y), dotprod_cache, sum_cache) +
              dotProduct(mgr, x, cuddE(y), dotprod_cache, sum_cache));

  if (use_cache) {
    if (dotprod_cache.size() > (1 << 17)) dotprod_cache.clear();
    dotprod_cache[make_pair(x, y)] = res;
  }

  return res;
}

inline double dotProduct(ADD x, ADD y) {
  assertinternal(x.manager()->getManager() == y.manager()->getManager());
  DdNode *xn = x.getNode();
  DdNode *yn = y.getNode();
  DdManager *man = x.manager()->getManager();

  CuddCacheNN_D &dotprod_cache = CuddCacheManager::getCacheNN_D("dotProduct",
                                                                man);
  CuddCacheN_D &sum_cache = CuddCacheManager::getCacheN_D("sum", man);

  const double res = ((uint64_t(1) << man->size)*
                      dotProduct(man, xn, yn, dotprod_cache, sum_cache));

//  cout << "dotprod\t" << sum(x*y) << "\t" << res << endl;

  return res;
}

double ADDFunction::dotProduct(BFunction &x) {
  assertinternal(x.type() == ADD_FUN);
  return ::dotProduct(m_add, dynamic_cast<ADDFunction &>(x).getADD());
}

inline double dotProductRec(DdManager *mgr, DdNode *x, DdNode *y, int rec_level,
                            CuddCacheNN_D &dotprodrec_cache,
                            CuddCacheNN_D &dotprod_cache,
                            CuddCacheN_D &sum_cache) {
  if (cuddIsConstant(x)) {
    const double vx = cuddV(x);
    return vx == .0 ? .0 : vx*sum(mgr, y, sum_cache);
  } else if (cuddIsConstant(y)) {
    const double vy = cuddV(y);
    return vy == .0 ? .0 : vy*sum(mgr, x, sum_cache);
  }

  const int x_level = mgr->perm[x->index];
  const int y_level = mgr->perm[y->index];
  if (x_level > rec_level || y_level > rec_level)
    dotProduct(mgr, x, y, dotprod_cache, sum_cache);

  const bool use_cache = mgr->size > min(x_level, y_level) + mgr->size/4;
  if (use_cache) {
    if (y < x) swap(x, y);
    CuddCacheNN_D::const_iterator ci = dotprodrec_cache.find(make_pair(x, y));
    if (ci != dotprodrec_cache.end()) return ci->second;
  }

  double res;
  if (x_level == y_level) {
    DdNode *y_T = cuddT(y);
    DdNode *y_E = cuddE(y);
    if (y_level == rec_level) swap(y_T, y_E);
    res = .5*(dotProductRec(mgr, cuddT(x), y_T, rec_level, dotprodrec_cache,
                            dotprod_cache, sum_cache) +
              dotProductRec(mgr, cuddE(x), y_E, rec_level, dotprodrec_cache,
                            dotprod_cache, sum_cache));
  } else if (x_level < y_level)
    res = .5*(dotProductRec(mgr, cuddT(x), y, rec_level, dotprodrec_cache,
                            dotprod_cache, sum_cache) +
              dotProductRec(mgr, cuddE(x), y, rec_level, dotprodrec_cache,
                            dotprod_cache, sum_cache));
  else // x_level == y_level
    res = .5*(dotProductRec(mgr, x, cuddT(y), rec_level, dotprodrec_cache,
                            dotprod_cache, sum_cache) +
              dotProductRec(mgr, x, cuddE(y), rec_level, dotprodrec_cache,
                            dotprod_cache, sum_cache));

  if (use_cache) {
    if (dotprodrec_cache.size() > (1 << 17)) dotprodrec_cache.clear();
    dotprodrec_cache[make_pair(x, y)] = res;
  }

  return res;
}

inline double dotProductRec(ADD x, ADD y, int rec_level) {
  assertinternal(x.manager()->getManager() == y.manager()->getManager());
  DdNode *xn = x.getNode();
  DdNode *yn = y.getNode();
  DdManager *man = x.manager()->getManager();

  CuddCacheNN_D &dotprod_cache = CuddCacheManager::getCacheNN_D("dotProduct",
                                                                man);
  CuddCacheNN_D dotprodrec_cache;
//    CuddCacheManager::getCacheNN_D("dotProductRec", man);
  CuddCacheN_D &sum_cache = CuddCacheManager::getCacheN_D("sum", man);

  const double res = ((uint64_t(1) << man->size)*
                      dotProductRec(man, xn, yn, rec_level, dotprodrec_cache,
                                    dotprod_cache, sum_cache));

  return res;
}

double ADDFunction::dotProductRec(BFunction &x, const Unreduced &bit) {
  assertinternal(x.type() == ADD_FUN);
  if (bit.type == Unreduced::REGULAR)
    return ::dotProductRec(m_add, dynamic_cast<ADDFunction &>(x).getADD(),
                           m_manager->getManager()->perm[bit.begin]);
  else
    return ::dotProduct(m_add,
                        bit.transform(dynamic_cast<ADDFunction &>(x).getADD()));
}

/////////////////////////////////////////////////////////////////////////////
// VectorFunction
VectorFunction::VectorFunction(VectorFunction &f, const string &f_swap_file) :
    BFunction(f.m_manager), m_invperm(new int[f.m_num_bits]),
    m_perm(new int[f.m_num_bits]), m_num_bits(f.m_num_bits),
    m_num_informative_bits(f.m_num_informative_bits) {
  memcpy(m_invperm, f.m_invperm, m_num_bits*sizeof(int));
  memcpy(m_perm, f.m_perm, m_num_bits*sizeof(int));

  if (f_swap_file == "") {
    if (f.inMemory()) {
      m_vector = new double[IV(1) << m_num_bits];
      memcpy(m_vector, f.m_vector,
             (IV(1) << m_num_informative_bits)*sizeof(double));
    } else {
      assertinternal(!m_own_swap_file);
      m_swap_file = f.m_swap_file;
      m_vector = 0;
      getVector();
    }
  } else {
    f.writeToFile(f_swap_file, false);
    m_vector = f.m_vector;
    f.m_vector = 0;
    f.m_own_swap_file = true;
    f.m_swap_file = f_swap_file;
  }
}

VectorFunction::VectorFunction(const string &file_name, Cudd &mgr) :
    BFunction(&mgr, file_name), m_vector(0), m_num_bits(mgr.ReadSize()) {
  m_invperm = new int[m_num_bits];
  m_perm = new int[m_num_bits];

  gzFile file = gzopen(file_name.c_str(), "rb");
  unsigned int numbits;
  read(file, numbits);
  assertinternal(numbits == m_num_bits);
  readArray(file, m_perm, m_num_bits);

  resetInvperm();

  gzclose(file);
}

VectorFunction::VectorFunction(ADD &add) :
    BFunction(add.manager()), m_num_bits(m_manager->ReadSize()) {
  m_invperm = new int[m_num_bits];
  m_perm = new int[m_num_bits];

//   memcpy(m_invperm, m_manager->getManager()->invperm, m_numbits*sizeof(int));
  memcpy(m_perm, m_manager->getManager()->perm, m_num_bits*sizeof(int));

  int *support = Cudd_SupportIndex(add.manager()->getManager(),
                                        add.getNode());
  m_num_informative_bits = 0;
  for (Uint i = 0; i < m_num_bits; i++)
    if (support[i])
      m_num_informative_bits++;
    else {
      for (Uint j = 0; j < m_num_bits; j++)
        if (m_perm[j] > m_perm[i])
          m_perm[j]--;
      m_perm[i] = -1;
    }
  free(support);

  resetInvperm();

//  m_vector = new double[IV(1) << m_num_informative_bits];
  m_vector = new double[IV(1) << m_num_bits];
  addToVector(m_vector, add, m_perm);
}

void VectorFunction::transfer(Cudd &mgr) {
  shuffle(mgr.getManager()->invperm);
  m_manager = &mgr;
}

void VectorFunction::resetInvperm() {
  m_num_informative_bits = 0;
  for (Uint i = 0; i < m_num_bits; i++)
    if (m_perm[i] != -1) {
      m_num_informative_bits++;
      m_invperm[m_perm[i]] = i;
    }

  for (Uint i = m_num_informative_bits; i < m_num_bits; i++)
    m_invperm[i] = -1;
}

IV VectorFunction::expandMask(Uint begin, Uint end) {
  IV res(0);
  for (Uint i = begin; i < end; i++)
    res |= IV(1) << (m_num_informative_bits - 1 - i);
  return res;
}

ADD VectorFunction::asADD(ADD &zo) {
  if (!inMemory()) getVector(); //***********************//

  if (inMemory()) {
    SW_START("asADD");
    m_manager->SetRoundingPrec(options->mtbddrounding);
    ADD add(m_manager->addZero());

    assertinternal(int(m_num_bits) == m_manager->ReadSize());
    if (!orderMatchesManager(*m_manager)) {
      if (m_manager->ReadMemoryInUse() <
          (IV(1) << (3 + m_num_informative_bits))/16)
        fixManagerOrder();
//        m_manager->ShuffleHeap(m_invperm);
      else
        shuffle(m_manager->getManager()->invperm);
    }

    ADD zo_tmp = addTransfer(zo, *m_manager);
    vectorToADD(add, m_vector, m_invperm, zo_tmp);
    SW_STOP("asADD");
    return add;
  } else {
    todo("");
//    const string swap_file = i->second.m_bf->swapFile();
  }
}

void VectorFunction::buildXNodesUtil(vector<IV> &ivs, IV v, IV mi,
                                     IV uninformative_mask) {
  while (!(mi & uninformative_mask) && mi <= uninformative_mask)
    mi <<= 1;
  if (mi > uninformative_mask)
    ivs.push_back(v);
  else {
    buildXNodesUtil(ivs, v, mi << 1, uninformative_mask);
    buildXNodesUtil(ivs, v | mi, mi << 1, uninformative_mask);
  }
}

void VectorFunction::buildXNodes(map<DdNode *, vector<IV> > &x_nodes, DdNode *x,
                                 IV v, int target_lvl, IV uninformative_mask) {
  const int x_index = x->index;
  const int x_lvl =
    x_index == CUDD_CONST_INDEX ? CUDD_CONST_INDEX : m_perm[x_index];
  assertinternal(x_lvl >= 0);

  if (x_lvl >= target_lvl) {
    vector<IV> &ivs(x_nodes[x]);
    if (uninformative_mask == 0)
      ivs.push_back(v);
    else
      buildXNodesUtil(ivs, v, 1, uninformative_mask);
  } else {
    DdNode *T = cuddT(x);
    DdNode *E = cuddE(x);

    const int T_index = T->index;
    const int E_index = E->index;

    const int T_lvl = min(target_lvl, T_index == CUDD_CONST_INDEX ? target_lvl :
                          m_perm[T_index]);
    const int E_lvl = min(target_lvl, E_index == CUDD_CONST_INDEX ? target_lvl :
                          m_perm[E_index]);

    buildXNodes(x_nodes, T, v | (IV(1) << (m_num_informative_bits - 1 - x_lvl)),
                target_lvl, uninformative_mask | expandMask(x_lvl + 1, T_lvl));
    buildXNodes(x_nodes, E, v,
                target_lvl, uninformative_mask | expandMask(x_lvl + 1, E_lvl));
  }
}

double VectorFunction::multiply(ADD &x, bool dp) {
  if (cuddIsConstant(x.getNode())) {
    const double xv = cuddV(x.getNode());
    if (dp)
      return xv*sum(x);
    else {
      if (xv != 1.)
        scalvec(m_vector, xv, m_vector, IV(1) << m_num_informative_bits);
      return .0;
    }
  }

  if (!inMemory()) getVector();

  // Check if vector representation needs to be expanded to accomodate
  // multiplication by x
  int *x_support = Cudd_SupportIndex(x.manager()->getManager(), x.getNode());
  vector<int> expand_bits;
  for (Uint i = 0; i < m_num_bits; i++)
    if (x_support[i] && m_perm[i] == -1)
      expand_bits.push_back(i);
  free(x_support);
  expand(expand_bits);

  // Reorder x or this so that multiplication may be performed
  ADD y(x);
  if (!orderMatchesManager(*x.manager())) {
    if (!orderMatchesManager(*m_manager)) {
      if (m_manager->ReadMemoryInUse() <
          (IV(1) << (3 + m_num_informative_bits))/16)
        fixManagerOrder();
      else
        shuffle(m_manager->getManager()->invperm);
    }
    y = addTransfer(x, *m_manager);
  }

  // actual multiplication
  SW_START("inplaceMult");
  DdNode *yn = y.getNode();

  const Uint target_level = m_num_informative_bits/2;
  map<DdNode *, vector<IV> > x_nodes;
  vector<Float> x_values(1 << (m_num_informative_bits - target_level));

  buildXNodes(x_nodes, yn, 0, target_level,
              expandMask(0, min(cuddIsConstant(yn) ? int(target_level) :
                                m_perm[yn->index], int(target_level))));

  int *perm = new int[m_num_bits];
  for (Uint i = 0; i < m_num_bits; i++)
    if (m_perm[i] != -1 && m_perm[i] >= int(target_level))
      perm[i] = m_perm[i] - target_level;
    else
      perm[i] = -1;

  IV n = 0;
  double res = .0;
  for (map<DdNode *, vector<IV> >::const_iterator xni = x_nodes.begin();
       xni != x_nodes.end(); xni++) {
    n += xni->second.size();

    ADD add_i(y.manager(), xni->first);
    const vector<IV> &vs(xni->second);
    if (add_i == y.manager()->addOne()) {
      if (dp)
        for (Uint i = 0; i < vs.size(); i++) {
          Float *vector_i = m_vector + vs[i];
          res += sum<Float>(vector_i, x_values.size());
        }
    } else if (add_i == y.manager()->addZero()) {
      if (!dp)
        for (Uint i = 0; i < vs.size(); i++) {
          Float *vector_i = m_vector + vs[i];
          memset(vector_i, 0, x_values.size()*sizeof(Float));
        }
    } else {
      addToVector(&*x_values.begin(), add_i, perm);

      for (Uint i = 0; i < vs.size(); i++) {
        Float *vector_i = m_vector + vs[i];
        if (dp)
          res += dotprod(vector_i, &*x_values.begin(), x_values.size());
        else
          elemprod(vector_i, vector_i, &*x_values.begin(), x_values.size());
      }
    }
  }
  assertinternal(n == (IV(1) << target_level));
  delete [] perm;

  SW_STOP("inplaceMult");

  return res;
}

void VectorFunction::inplaceMultBF(BFunction &x) {
  if (!inMemory()) getVector();

  if (x.type() == ADD_FUN)
    inplaceMult(dynamic_cast<ADDFunction &>(x).getADD());
  else {
    VectorFunction &xv(dynamic_cast<VectorFunction &>(x));
    // Assumes both are in same order
//     assertinternal(equal(m_perm, m_perm + m_numbits,
//                          dynamic_cast<VectorFunction &>(x).m_perm));
    vector<int> expand_bits;
    assertinternal(xv.m_num_bits == m_num_bits);
    bool equiv = true;
    for (Uint i = 0; i < m_num_bits; i++)
      if (xv.m_perm[i] != -1 && m_perm[i] == -1)
        expand_bits.push_back(i);
      else if (xv.m_perm[i] != m_perm[i])
        equiv = false;
    expand(expand_bits);

    SW_START("elemprod");
    if (equiv)
      elemprod(m_vector, m_vector, xv.getVector(), IV(1) << m_num_bits);
    else
      todo("");
    SW_STOP("elemprod");
  }
}

// tb[b] is the new level for bit b
void VectorFunction::shuffle(IV v, char *tb) {
  double last_val = m_vector[v];
  while (true) {
    IV next_v = 0;
    for (Uint b = 0; b < m_num_informative_bits; b++)
      if (v & (IV(1) << b))
        next_v |= IV(1) << tb[b];

    if (next_v == v) {
      m_vector[v] = -m_vector[v];
      break;
    } else {
      double &next_val = m_vector[next_v];
      if (signbit(next_val)) break;
      const double tmp_val(next_val);
      next_val = -last_val;
#ifdef DEBUG_OUTPUT
      assertinternal(signbit(next_val));
#endif // DEBUG_OUTPUT
      last_val = tmp_val;
#ifdef DEBUG_OUTPUT
      assertinternal(!signbit(last_val));
#endif // DEBUG_OUTPUT
      v = next_v;
    }
  }
}

void VectorFunction::shuffle(int *invperm) {
  if (orderMatches(invperm))
    return;

  SW_START("VectorFunction::shuffle");

  char *tb = new char[m_num_informative_bits];
  for (Uint b = 0, ib = 0; b < m_num_bits; b++) {
    const int index = invperm[m_num_bits - 1 - b];
    if (index != -1 && m_perm[index] != -1) {
      const int old_lvl = m_num_informative_bits - 1 - m_perm[index];
      assertinternal(old_lvl != -1 && old_lvl < int(m_num_informative_bits));
      tb[old_lvl] = ib;
      ib++;
    }
  }

  const IV numiv(IV(1) << m_num_informative_bits);

#ifdef DEBUG_OUTPUT
  for (IV v = 0; v < numiv; v++)
    assertinternal(!signbit(m_vector[v]));
#endif // DEBUG_OUTPUT

  for (IV v = 0; v < numiv; v++)
    if (!signbit(m_vector[v]))
      shuffle(v, tb);

  for (IV v = 0; v < numiv; v++) {
#ifdef DEBUG_OUTPUT
    assertinternal(signbit(m_vector[v]));
#endif // DEBUG_OUTPUT
    m_vector[v] = -m_vector[v];
  }

  delete [] tb;

  for (Uint i = 0, ii = 0; i < m_num_bits; i++) {
    const int index(invperm[i]);
    if (index != -1 && m_perm[index] != -1) {
      m_perm[index] = ii;
      ii++;
    }
  }
  resetInvperm();

  SW_STOP("VectorFunction::shuffle");
}

void VectorFunction::asStraightVector(double */*res*/) {
  todo("");
//   if (!inMemory()) getVector();
//   int *tmp_invperm = new int[m_numbits];
//   memcpy(tmp_invperm, m_invperm, m_numbits*sizeof(int));

//   int *straight_invperm = new int[m_numbits];
//   for (Uint i = 0; i < m_numbits; i++)
//     straight_invperm[i] = m_numbits - 1 - i;

//   shuffle(straight_invperm);
//   memcpy(res, m_vector, (IV(1) << m_numbits)*sizeof(double));

//   shuffle(tmp_invperm);

//   delete [] straight_invperm;
//   delete [] tmp_invperm;
}

void VectorFunction::writeToFile(const string &fn, bool swap) {
  SW_START("VectorFunction::writeToFile");
  gzFile file = gzopen(fn.c_str(), "wb");
  write(file, (unsigned int)(m_num_bits));
  writeArray(file, m_perm, m_num_bits);

//   const double nc = vecmax<double, IV, double *>(m_vector, IV(1) << m_numbits);
//   assertinternal(nc > .0);
//   write(file, nc);
//   const double inc = 1./nc;

//   const IV numiv = IV(1) << m_numbits;
//   for (IV v = 0; v < numiv; v++)
//     write(file, float(m_vector[v]*inc));
  writeArray(file, m_vector, IV(1) << m_num_informative_bits);

  if (swap) {
    m_swap_file = fn;
    m_own_swap_file = true;
    delete [] m_vector;
    m_vector = 0;
  }

  gzclose(file);
  SW_STOP("VectorFunction::writeToFile");
}

double *VectorFunction::getVector() {
  if (!inMemory()) {
    SW_START("VectorFunction::getVector");
    gzFile file = gzopen(m_swap_file.c_str(), "rb");
    unsigned int numbits;
    read(file, numbits);
    assertinternal(numbits == m_num_bits);
    readArray(file, m_perm, m_num_bits);
    resetInvperm();
    assertinternal(m_vector == 0);
//    m_vector = new double[IV(1) << m_num_informative_bits];
    m_vector = new double[IV(1) << m_num_bits];

//     double nc;
//     read(file, nc);
//     assertinternal(nc > .0);
//     const IV numiv = IV(1) << m_numbits;
//     for (IV v = 0; v < numiv; v++) {
//       float val;
//       read(file, val);
//       m_vector[v] = val*nc;
//     }
    readArray(file, m_vector, IV(1) << m_num_informative_bits);

    if (m_own_swap_file) {
//        cerr << "RRRRRRRRRRRRRRR getVector removing " << m_swap_file << endl;
      remove(m_swap_file.c_str());
    }
    m_swap_file = "";

    gzclose(file);
    SW_STOP("VectorFunction::getVector");
  }
  return m_vector;
}

void VectorFunction::integrateOut(const set<Unreduced> &bits) {
  SW_START("VectorFunction::integrateOut");
  for (set<Unreduced>::const_iterator bit = bits.begin(); bit != bits.end();
       bit++)
    if (bit->type == Unreduced::REGULAR) {
      const int bl = m_perm[bit->begin];
      if (bl == -1) continue;
      const IV bvl = IV(1) << (m_num_informative_bits - 1 - bl);
      const IV numiv = IV(1) << m_num_informative_bits;
      const IV bvl_next = bvl << 1;
      for (IV w = 0; w < numiv; w += bvl_next)
        for (IV v = 0; v < bvl; v++) {
          const IV wv(v | w);
          m_vector[v | (w >> 1)] = m_vector[wv] + m_vector[wv | bvl];
        }

//       for (IV w = 0; w < numiv; w += bvl)
//         for (IV v = 0; v < bvl; v++)
//           m_vector[v | (w >> 1)] += m_vector[v | w];

      m_perm[bit->begin] = -1;
      for (Uint i = 0; i < m_num_bits; i++)
        if (m_perm[i] > bl) {
          m_perm[i]--;
          m_invperm[m_perm[i]] = i;
        } else if (m_perm[i] == bl)
          m_perm[i] = -1;

      m_num_informative_bits--;
      m_invperm[m_num_informative_bits] = -1;
    }//  else  no point really ...
  SW_STOP("VectorFunction::integrateOut");
}

void VectorFunction::expand(const vector<int> &expand_bits) {
  if (expand_bits.empty()) return;
  if (!inMemory()) getVector();

  const IV old_numiv = IV(1) << m_num_informative_bits;
  const Uint num_new_bits = expand_bits.size();
  const IV new_numiv = IV(1) << num_new_bits;
  for (IV v = old_numiv - 1; v < old_numiv; v--) {
    const IV shifted_v = v << num_new_bits;
    for (IV w = 0; w < new_numiv; w++)
      m_vector[shifted_v | w] = m_vector[v];
  }

  for (Uint i = 0; i < num_new_bits; i++) {
    assertinternal(m_perm[expand_bits[i]] == -1);
    m_perm[expand_bits[i]] = m_num_informative_bits + i;
  }
  resetInvperm();
}

bool VectorFunction::orderMatches(int *invperm) const {
  int *active_invperm = new int[m_num_bits];

  Uint active_i = 0;
  for (Uint i = 0; i < m_num_bits; i++)
    if (invperm[i] != -1 && m_perm[invperm[i]] != -1) {
      active_invperm[active_i] = invperm[i];
      active_i++;
    }

  for (; active_i < m_num_bits; active_i++)
    active_invperm[active_i] = -1;

  const bool result = equal(m_invperm, m_invperm + m_num_bits, active_invperm);

  delete [] active_invperm;

  return result;
}

void VectorFunction::fixManagerOrder() {
  int *invperm = new int[m_num_bits];
  memcpy(invperm, m_invperm, m_num_informative_bits*sizeof(int));
  for (Uint i = 0, n = 0; i < m_num_bits; i++)
    if (m_perm[i] == -1) {
      invperm[m_num_informative_bits + n] = i;
      n++;
    }

  m_manager->ShuffleHeap(invperm);

  delete [] invperm;
}

void VectorFunction::expand() {
  vector<int> expand_bits;
  for (Uint i = 0; i < m_num_bits; i++)
    if (m_perm[i] == -1)
      expand_bits.push_back(i);

  expand(expand_bits);
}

int *VectorFunction::support() {
  int *res = (int *)malloc(m_num_bits*sizeof(int));
  for (Uint i = 0; i < m_num_bits; i++)
    res[i] = m_perm[i] == -1 ? 0 : 1;
  return res;
}

double VectorFunction::dotProduct(BFunction &x) {
  if (!inMemory()) getVector();

  if (x.type() == VECTOR_FUN) {
    VectorFunction &vf(dynamic_cast<VectorFunction &>(x));

    vector<int> this_expand, x_expand;
    for (Uint i = 0; i < m_num_bits; i++)
      if (m_perm[i] == -1 && vf.m_perm[i] != -1)
        this_expand.push_back(i);
      else if (m_perm[i] != -1 && vf.m_perm[i] == -1)
        x_expand.push_back(i);
    expand(this_expand);
    vf.expand(x_expand);

    if (!orderMatches(vf.m_invperm)) {
      if (vf.orderMatchesManager(vf.manager()))
        shuffle(vf.m_invperm);
      else
        vf.shuffle(m_invperm);
    }

    return ((IV(1) << (m_num_bits - m_num_informative_bits))*
            ::dotprod(m_vector, vf.getVector(),
                      IV(1) << m_num_informative_bits));
  } else
    return multiply(dynamic_cast<ADDFunction &>(x).getADD(), true);
}

double VectorFunction::dotProductRec(BFunction &x, const Unreduced &rec_bit) {
  if (!inMemory()) getVector();

  if (x.type() == VECTOR_FUN) {
    VectorFunction &vf(dynamic_cast<VectorFunction &>(x));

//     vector<int> this_expand, x_expand;
//     for (Uint i = 0; i < m_num_bits; i++)
//       if (m_perm[i] == -1 && vf.m_perm[i] != -1)
//         this_expand.push_back(i);
//       else if (m_perm[i] != -1 && vf.m_perm[i] == -1)
//         x_expand.push_back(i);
//     expand(this_expand);
//     vf.expand(x_expand);
    expand();
    vf.expand();

    if (!orderMatches(vf.m_invperm)) {
      if (vf.orderMatchesManager(vf.manager()))
        shuffle(vf.m_invperm);
      else
        vf.shuffle(m_invperm);
    }

    IV bit;
    const IV numiv(IV(1) << m_num_informative_bits);
    if (rec_bit.type == Unreduced::REGULAR)
      bit = IV(1) << (m_num_informative_bits - 1 - m_perm[rec_bit.begin]);
    else if (!rec_bit.flips.empty())
      bit = IV(1) << (m_num_informative_bits - 1 -
                      m_perm[rec_bit.flips.front()]);
    else
      bit = numiv;
    const IV prev_bit = bit << 1;
    double res = .0;
    double *f = m_vector;
    double *g = vf.getVector();
    if (rec_bit.type == Unreduced::REGULAR) {
      for (IV v = 0; v < numiv; v += prev_bit)
        for (IV w = 0; w < bit; w++) {
          const IV vw0 = v | w;
          const IV vw1 = vw0 | bit;
          res += f[vw0]*g[vw1] + f[vw1]*g[vw0];
        }
    } else if (rec_bit.type == Unreduced::FR) {
      IV mask = 0;
      for (unsigned int i = 0; i < rec_bit.flips.size(); i++)
        mask |= IV(1) << (m_num_informative_bits - 1 -
                          m_perm[rec_bit.flips[i]]);
      for (IV v = 0; v < numiv; v += prev_bit)
        for (IV w = 0; w < bit; w++) {
          const IV vw0 = v | w;
          const IV vw1 = vw0 ^ mask;
          res += f[vw0]*g[vw1] + f[vw1]*g[vw0];
        }
    } else {
      if (bit == numiv) {
        for (IV v = 0; v < numiv; v++) {
          IV w = v;
          for (unsigned int i = 0; i < rec_bit.swaps_src.size(); i++) {
            const IV bs = IV(1) << (m_num_informative_bits - 1 -
                                    m_perm[rec_bit.swaps_src[i]]);
            const IV bd = IV(1) << (m_num_informative_bits - 1 -
                                    m_perm[rec_bit.swaps_dest[i]]);

            const bool s = bs & v;
            const bool d = bd & v;
            if (s != d) {
              if (s) {
                w |= bd;
                w &= ~bs;
              } else {
                w &= ~bd;
                w |= bs;
              }
            }
          }
          res += f[v]*g[w];
          if (v != w)
            res += f[w]*g[v];
        }
      } else {
        IV mask = 0;
        for (unsigned int i = 0; i < rec_bit.flips.size(); i++)
          mask |= IV(1) << (m_num_informative_bits - 1 -
                            m_perm[rec_bit.flips[i]]);
        for (IV v = 0; v < numiv; v += prev_bit)
          for (IV w = 0; w < bit; w++) {
            const IV vw0 = v | w;
            IV vw1 = vw0 ^ mask;
            for (unsigned int i = 0; i < rec_bit.swaps_src.size(); i++) {
              const IV bs = IV(1) << (m_num_informative_bits - 1 -
                                      m_perm[rec_bit.swaps_src[i]]);
              const IV bd = IV(1) << (m_num_informative_bits - 1 -
                                      m_perm[rec_bit.swaps_dest[i]]);

              const bool s = bs & vw0;
              const bool d = bd & vw0;
              if (s != d) {
                if (s) {
                  vw1 |= bd;
                  vw1 &= ~bs;
                } else {
                  vw1 &= ~bd;
                  vw1 |= bs;
                }
              }
            }
            res += f[vw0]*g[vw1] + f[vw1]*g[vw0];
          }
      }
    }

    return res;
  } else {
    ADD x_trans;
    ADD xa(dynamic_cast<ADDFunction &>(x).getADD());
    if (rec_bit.type == Unreduced::REGULAR) {
      ADD bv(xa.manager()->addVar(rec_bit.begin));
      x_trans = bv.Ite(xa.Cofactor(~bv), xa.Cofactor(bv));
    } else
      x_trans = rec_bit.transform(xa);
    return multiply(x_trans, true);
  }
}
