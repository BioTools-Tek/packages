#ifndef _RECOMBDIST
#define _RECOMBDIST
#include "basic.h"
#include "vecutil.h"
#include "options.h"
#include "distribution.h"

class Plist;
class Foundercouple;
class Sweeper;
class RecombAccumulator;

class Recombdist : public Distribution {
public:
  static Recombdist *getrecombdist();

  virtual ~Recombdist();
  static void set(FloatVec Fp, FloatVec rqh, FloatVec lqh, Uint gam,
                  Float theta, Float theta_female, const string &pt);
  static void set(const string &left, const RecombAccumulator &ral,
                  Sweeper &sweeper, Uint gam, double theta,
                  double theta_female, const string &pt);

  void calcxovers();

  Uint bitsum_male() const;
  Uint bitsum_female() const;
  Uint nbits(Uint ifa) const {return familydata[ifa]->nbits;}
  Uint nbits_male(Uint ifa) const {return familydata[ifa]->nbits_male;}
  Uint nbits_female(Uint ifa) const {return familydata[ifa]->nbits_female;}
  Float xoversum(Uint pos) const;
  Float xoversum_female(Uint pos) const;
  Float xover(Uint ifa, Uint pos) {return familydata[ifa]->xover[pos];}
  Float xover_female(Uint ifa, Uint pos)
    {return familydata[ifa]->xover_female[pos];}
  virtual string describe() const {return "recomb";}
protected:
  Recombdist();

  virtual void set(FloatVec Fp, FloatVec rqh, FloatVec lqh, Uint gam,
                   Float theta, Float theta_female);
  virtual void set(const string &left, const RecombAccumulator &ral,
                   Sweeper &sweeper, Uint gam, double theta,
                   double theta_female);

  virtual void reset(Uint np);
  virtual void nextfam(bool mtbdd, Uint pos = 0, DoubleVec p0 = 0);
  virtual void set(FloatVec, Uint /*pos*/) {assertinternal(false);}
  virtual void set(ADD &/*pv*/, double /*sum_pv*/, Uint /*pos*/) {
    assertinternal(false);
  }
  virtual void skipfam();

  Uint numbits;
  int lastcalcmarker; // Last calculated marker no. or - 1

  class Familydata {
  protected:
    Uint npos;
  public:
    Familydata(Uint np) : npos(np) {
      recomb = new Double[npos];
      copyval(recomb, -1, npos);
      xover = new Double[npos];
      if (options->sexspecific) {
        recomb_female = new Double[npos];
        copyval(recomb_female, -1, npos);
        xover_female = new Double[npos];
      }
    }
    Familydata(const Familydata &fd) : npos(fd.npos) {
      recomb = new Double[npos];
      xover = new Double[npos];
      if (options->sexspecific) {
        recomb_female = new Double[npos];
        xover_female = new Double[npos];
      }
     }
    ~Familydata() {
      delete [] recomb;
      delete [] xover;
      if (options->sexspecific) {
        delete [] recomb_female;
        delete [] xover_female;
      }
    }
    FloatVec recomb;
    FloatVec recomb_female;
    FloatVec xover;
    FloatVec xover_female;
    Uint nbits;
    Uint nbits_male;
    Uint nbits_female;
    Uint numsc;
    Uint numsc_male;
    Uint numsc_female;
  };
  typedef vector<Familydata *> Familydatavector;
  Familydatavector familydata;

  FloatVec thfactor;
  FloatVec thpower;
  FloatVec thf;    // Points to middle of thfactor;
  FloatVec thp;
  FloatVec thfactor_female;
  FloatVec thpower_female;
  FloatVec thf_female;    // Points to middle of thfactor_female;
  FloatVec thp_female;
  FloatVec F;
  FloatVec rqhat;
  FloatVec lqhat;

  IV mask_male;
  IV mask_female;

  void addtosum(Double& sum, Double& C, Double prod, Double count, IV r,
                Person *f, IV maskJ, IV masknotJ, Uint nJ);
  void addtosum_sexspecific(Double& sum_male, Double& sum_female,
                            Double& C, Double prod, Double count_male,
                            Double count_female, IV r, Person *f);
  void addtosum_sexlinked(Double& sum, Double& C, Double prod,
                          Double count, IV r, Person *f);
  void fcaddtosum(Double& sum, Double& C, Foundercouple *fc, BoolVec J,
                  Uint iJ, IV maskJ, IV masknotJ, Uint nJ, Uint gam);
  void calcFpi(BoolVec J);
  void fillin(Uint gam);
  void fillin(Uint type, FloatVec rec, Uint n, Uint ml, Uint mr);
  static Float recombtoxovers(Float theta, Float rec, Uint nb, Uint nsc);
  void createfj(Plist *c, Foundercouple *fc, BoolVec J, Uint iJ, IV r, IV pir);
  void createfjrest(IV lastfcbit, IV r, IV pir);

  virtual void getuninteresting(::set<Unreduced> &/*uninteresting*/) {}

};

#endif // _RECOMBDIST
