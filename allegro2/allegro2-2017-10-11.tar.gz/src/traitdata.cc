#include "traitdata.h"
#include "files.h"
#include "fmtout.h"

Traitdata *traitdata;

Traitdata::Traitdata(const Stringvector &traitfiles) {
  for (Uint i = 0; i < traitfiles.size(); i++) {
    Infile trfile;
    trfile.setname(traitfiles[i]);
    trfile.open();
    trfile >> ws;

    Uint linenumber = 0;
    vector<string> tc;
    while (!trfile.eof()) {
      linenumber++;
      string linebuffer;
      getline(trfile, linebuffer);
      trfile >> ws;
      ISTRINGSTREAM line(linebuffer);
      line >> ws;
      assertinternal(!line.eof());

      string pn;
      line >> pn;
      string lpn = pn;
      lowercase(lpn);
      if (linenumber == 1 && lpn == "pn") {
        while (!line.eof()) {
          string traitname;
          line >> traitname >> ws;
          assertcond(data.find(traitname) == data.end(), "Trait " +
                     traitname + " duplicated in " + traitfiles[i]);
          tc.push_back(traitname);
        }
      }
      else {
        if (linenumber == 1)
          tc.push_back("");
        char tv[1000];
        for (Uint i = 0; i < tc.size(); i++) {
          assertcond(!line.eof(), string("too few trait values in line ") +
                     linenumber + " of '" + traitfiles[i] + "'");
          line >> tv >> ws;
          if (strcmp(tv, "NA") != 0)
            data[tc[i]][pn] = atof(tv);
        }
      }
    }

    trfile.close();

    for (Uint i = 0; i < tc.size(); i++)
      if (data.find(tc[i]) == data.end()) {
        warning("Data for trait '" + tc[i] +
                "' not available for any individual!");
        data[tc[i]];
      }
  }
}
