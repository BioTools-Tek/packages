#ifndef _SPPEEL_HH
#define _SPPEEL_HH

#include "family.h"
#include "SPPeelPerson.hh"

#include <set>

class SPResult;

class SPPeel {
public:
  SPPeel(Uint gam, Family *fam, Cudd &mgr);
  SPPeel(const vector<SPPeelMarriage> &fam, SPPeelPerson *split_on,
         PhasedGT selected_haplotype, Cudd &mgr);
  ~SPPeel();

  void addPerson(const string &id, const string &father, const string &mother,
                 unsigned int patbitlevel, unsigned int matbitlevel,
                 bool founder, Allele a1, Allele a2) {
    assert(m_family.find(id) == m_family.end());
    m_family[id] = new SPPeelPerson(id, father, mother, patbitlevel,
                                    matbitlevel, founder, m_mgr, a1, a2);
  }

  ADD peel(const FloatVec &allele_freq, Uint nalleles);

protected:
  typedef map<string, SPPeelPerson *> PeelFamily;
  PeelFamily m_family;
  Cudd &m_mgr;

  SPPeelPerson *findPerson(const string &id);

  static bool finerThanRelatives(const SPPeelPerson &p,
                                 const vector<SPPeelMarriage> &fam);
  static void makeFinerThanRelatives(SPPeelPerson &p,
                                     const vector<SPPeelMarriage> &fam);
  static SPPeelPerson *findLoopBreaker(const vector<SPPeelMarriage> &fam);

  string addParent(SPPeelPerson *founder, SPPeelPerson *split_on,
                   PhasedGT selected_haplotype, unsigned int &split_count);

  static void propagateGenotypes(vector<SPPeelMarriage> &fam);
  static bool updatePossiblePhases(SPPeelPerson *p, const set<PhasedGT> &ass);
  static void uniquify(set<PhasedGT> &ass);

};

#endif // _SPPEEL_HH
