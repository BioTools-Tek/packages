#ifndef _SINGLELOCUS
#define _SINGLELOCUS
#include <iostream>
#include "basic.h"
#include "cuddutil.h"
#include "family.h"

#include "cuddObj.hh"

#include <set>

class Node;

class Edge {
//protected:
public:
  Allele a0;
  Allele a1;
  Node *n0; // Node and Edge pointers are only used in haplotyping part
  Node *n1;
  Edge *next;
  Float prob;

  Edge(Allele b0, Allele b1, FloatVec freq) :
      a0(b0), a1(b1), prob(sqrt(2.0*freq[a0 - 1]*freq[a1 - 1])) {}
  Edge(Allele b0, Allele b1, Node *m0, Node *m1) :
      a0(b0), a1(b1), n0(m0), n1(m1), next(0), prob(1.0) {}
  friend class Node;
};

class Elist : public Plist {
public:
  Elist(Person *q, Plist *ch) : Plist(q, ch) {};
  ~Elist() {delete next;}

  Edge *edge;
};

class Block;

class Node {
public:
  Node *next;
  bool genotyped; // v1
  Allele allele;
  Edge *edge;
  Uint index;

  void getBlock(vector<unsigned int> &b1, vector<unsigned int> &b2);

  // v2
  Block *block;
  Uint group;

  bool setallele2(Allele a);
  void unsetallele2();
protected:
  Node *neighbour; // Neighbour in single locus peel

  Node(Node *n = 0) : next(n), genotyped(false), allele(ALLELEUNKNOWN),
    edge(0), neighbour(0), block(0) {}
  inline bool setallele(Allele a) {
    if (neighbour) {
      if (edge->a0 == a) neighbour->allele = edge->a1;
      else if (edge->a1 == a) neighbour->allele = edge->a0;
      else return false;
    }
    allele = a;
    return true;
  }
  inline void unsetallele() {
    allele = ALLELEUNKNOWN;
    if (neighbour) neighbour->allele = ALLELEUNKNOWN;
  }

  bool haplosetallele(Allele a);
  void clearallele();
  friend class Graph;
};

class Block {
public:
  const Allele a0;
  const Allele a1;

  set<Node *> group0;
  set<Node *> group1;

  Block(Allele b0, Allele b1) : a0(b0), a1(b1) {}
  Block(const Block &a, const Block &b, unsigned int config);
  
  double prob(DoubleVec freq) {
    return (pow(freq[a0 - 1], double(group0.size()))*
            pow(freq[a1 - 1], double(group1.size())) +
            pow(freq[a1 - 1], double(group0.size()))*
            pow(freq[a0 - 1], double(group1.size())));
  }

  double symbolic_prob_first() {
    return pow(10.0, a0) * double(group0.size()) +
           pow(10.0, a1) * double(group1.size());
  }

  double symbolic_prob_second() {
    return pow(10.0, a1) * double(group0.size()) +
           pow(10.0, a0) * double(group1.size());
  }

  bool addNode(Node *n, Uint group) {
    if (group == 0) {
      if (group1.count(n) > 0) return false;
      else {
        group0.insert(n);
        n->block = this;
        n->group = 0;
        return true;
      }
    }
    else {
      assertinternal(group == 1);
      if (group0.count(n) > 0) return false;
      else {
        group1.insert(n);
        n->block = this;
        n->group = 1;
        return true;
      }
    }
  }
  void setalleles(Uint config) {
    set<Node *> &g0 = (config == 0 ? group0 : group1);
    set<Node *> &g1 = (config == 0 ? group1 : group0);
    for (set<Node *>::iterator i = g0.begin(); i != g0.end(); i++)
      (*i)->allele = a0;
    for (set<Node *>::iterator i = g1.begin(); i != g1.end(); i++)
      (*i)->allele = a1;
  }
  void unsetalleles() {
    for (set<Node *>::iterator i = group0.begin(); i != group0.end(); i++)
      (*i)->allele = ALLELEUNKNOWN;
    for (set<Node *>::iterator i = group1.begin(); i != group1.end(); i++)
      (*i)->allele = ALLELEUNKNOWN;
  }
  void resetnodes() {
    for (set<Node *>::iterator i = group0.begin(); i != group0.end(); i++) {
      (*i)->block = this;
      (*i)->group = 0;
    }
    for (set<Node *>::iterator i = group1.begin(); i != group1.end(); i++) {
      (*i)->block = this;
      (*i)->group = 1;
    }
  }
  void removeNode(Node *n) {
    Uint num;
    if (n->group == 0) {
      num = group0.count(n);
      assertinternal(num > 0);
      group0.erase(n);
      assertinternal(group0.count(n) == num - 1);
    }
    else {
      num = group1.count(n);
      assertinternal(num > 0);
      group1.erase(n);
      assertinternal(group1.count(n) == num - 1);
    }
    if (num == 1) n->block = 0;
  }
};

class Graph {
public:
  FloatVec allelefreq;
  Node *first;
  Graph(Person *frst);
  ~Graph();

  void setallelefreq(FloatVec af) {allelefreq = af;}

  inline Double probability() const {
    Double prob = 1.0;
    for (Node *cur = first; cur != 0; cur = cur->next) {
      if (!cur->genotyped && cur->allele != ALLELEUNKNOWN)
        prob *= allelefreq[cur->allele - 1];
      else if (cur->edge != 0)
        prob *= cur->edge->prob;
    }
    return prob;
  }

  inline double probability2() const {
    double prob = 1.0;
    set<Block *> blocks;
    for (Node *cur = first; cur != 0; cur = cur->next) {
      if (cur->allele != ALLELEUNKNOWN)
        prob *= allelefreq[cur->allele - 1];
      else if (cur->block != 0)
        blocks.insert(cur->block);
    }
    for (set<Block *>::iterator bi = blocks.begin(); bi != blocks.end(); bi++)
      prob *= (*bi)->prob(allelefreq);
    return prob;
  }

  inline ADD symbolic_probability(Cudd &mgr, long level) const {
    double prob = 0.0;
    set<Block *> blocks;
    for (Node *cur = first; cur != 0; cur = cur->next) {
      if (cur->allele != ALLELEUNKNOWN)
        prob += pow(10.0, cur->allele);
      else if (cur->block != 0)
        blocks.insert(cur->block);
    }

    ADD add = mgr.constant(prob);
    ADD add0k1 = mgr.constant(0.1);
    for (set<Block *>::iterator bi = blocks.begin();
         bi != blocks.end(); bi++) {
      double p1 = (*bi)->symbolic_prob_first();
      double p2 = (*bi)->symbolic_prob_second();
      if (fabs(p2 - p1) < 0.01) {
        add = add + mgr.constant(p1 + 0.1);
      } else {
        ADD tmp_t = add + mgr.constant(p1);
        ADD tmp_e = add + mgr.constant(p2);
        add = uniqueInter(level--, mgr, tmp_t, tmp_e);
      }
    }
    return add;
  }

  Node *addnode(); // adds one node
  void addfounderedge(Node *n0, Node *n1, Allele b0, Allele b1) const;
  void addfounderedge2(Node *n0, Node *n1, Allele b0, Allele b1) const;
  inline void addedge(Node *n0, Node *n1, Edge *e) const {
    // Only call this function if the alleles of n0 and n1 have not been set
    n1->edge = n0->edge = e;
    n0->neighbour = n1;
    n1->neighbour = n0;
  }
  
  inline bool addgenotype(Node *n0, Node *n1, Allele b0, Allele b1,
                          bool &n0set, bool &n1set) const {
    n0set = n1set = false;
    if (n0->allele != b0) {
      if (n0->allele == ALLELEUNKNOWN && n0->setallele(b0)) n0set = true;
      else return false;
    }
    if (n1->allele != b1) {
      if (n1->allele == ALLELEUNKNOWN && n1->setallele(b1)) n1set = true;
      else {
        if (n0set) {
          n0->unsetallele();
          n0set = false;
        }
        return false;
      }
    }
    return true;
  }

  inline void removegenotype(Node *n0, Node *n1, bool n0set, bool n1set) const {
    if (n0set) n0->unsetallele();
    if (n1set) n1->unsetallele();
  }
  inline void removeedge(Node *n0, Node *n1) const {
    n1->edge = n0->edge = 0;
    n0->neighbour = n1->neighbour = 0;
  }
  void reset();
  void reset2();

  // Haplotyping methods:
  bool addgenotype(Node *n0, Node *n1, Allele a0, Allele a1);
  void assignalleles(bool pickmle);
  void haploreset();

  friend class Node;
};

#endif //SINGLELOCUS
