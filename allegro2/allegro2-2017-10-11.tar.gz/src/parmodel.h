#ifndef _PARMODEL
#define _PARMODEL
#include "basic.h"
#include "paramdist.h"

class Trait;

class Parmodel : public Linkagemodel {
public:
  Parmodel(const string &p, bool ht, const string &of, const string &fof,
           Double f = -1, Double p0 = -1, Double p1 = -1,
           Double p2 = -1, Double p0_male = -1, Double p1_male = -1);
  virtual void print() const;
  void settrait(Trait *tr)
    {((Paramdist *)distribution)->settrait(tr);}
  Trait *gettrait() {return ((Paramdist *)distribution)->gettrait();}

  static void setdefaulttrait(Trait *tr);
  static Trait *getdefaulttrait() {return defaulttrait;}
protected:
  static Trait *defaulttrait;

  virtual bool heterogeneity() const {return heterogen;}
  bool heterogen;
};

#endif // _PARMODEL
