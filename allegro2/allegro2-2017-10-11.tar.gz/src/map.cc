#include <iostream>
#include <iomanip>
#include "basic.h"
#include "map.h"
#include "files.h"
#include "options.h"
#include "vecutil.h"
#include "haldane.h"
#include "utils.h"
#include <algorithm>

Map::Map() {
  start();
}

void Map::start() {
  loci.clear();
  positions.clear();
  unit = options->unit;
}

void Map::allocate(Uint n) {
  positions.resize(n);
}

void Map::readstepfile(Infile& f) {
  assertcond(!options->sexspecific,
             "stepfile currently doesn't work with secspesific recombination rates");
  const Float eps = 1e-4;
  vector<Float> stp;

  f.open();
  while (!f.eof()) {
    Float st;
    f >> st >> ws;
    stp.push_back(st);
    assertcond(f.eof() || f.good(), "Illegal number in stepfile " + f.name);
    if (stp.size() > 1)
      assertcond(stp[stp.size() - 1] > stp[stp.size() - 2],
                 "Numbers in stepfile " + f.name + "not increasing");
  }
  assertcond(stp.size() > 0, "Empty stepfile");
  allocate(stp.size() + loci.size());
  Uint is = 0;
  Uint im = 0;
  Uint j = 0;
  int leftmrk = -1;
  for (j = 0; is < stp.size() || im < loci.size(); j++) {
    if (is < stp.size() && im < loci.size() &&
        fabs(loci[im].positionAvg() - stp[is]) < eps) {
      leftmrk = im;
      positions[j].setPosition(loci[im].positionMale(), 0);
      positions[j].inbetween = false;
      im++;
      is++;
    }
    else if (im >= loci.size() || (is < stp.size() &&
                                   stp[is] < loci[im].positionAvg())) {
      assertinternal(is < stp.size());
      positions[j].setPosition(stp[is], 0);
      positions[j].inbetween = true;
      is++;
    }
    else {
      assertinternal(im < loci.size());
      leftmrk = im;
      loci[im].shouldfindp = false;
      positions[j].inbetween = false;
      positions[j].setPosition(loci[im].positionAvg(), 0);
      im++;
    }
    positions[j].leftmarker = leftmrk;
  }
  positions.resize(j);
  f.close();
}

void Map::maxsteplength() {
  IntVec nstep;
  nstep = new int[loci.size()];
  Uint numposition = 0;
  for (Uint i = 0; i < loci.size() - 1; i++) {
    const Float distance = loci[i + 1].positionAvg() - loci[i].positionAvg();
    nstep[i] = int(distance/options->maxsteplength);
    numposition += nstep[i];
  }
  allocate(numposition);
  Uint j = 0;
  for (Uint i = 0; i < loci.size() - 1; i++) {
    const Float distance_male = (loci[i + 1].positionMale() -
                                 loci[i].positionMale());
    const Float distance_female = (loci[i + 1].positionFemale() -
                                   loci[i].positionFemale());
    for (int k = 0; k <= nstep[i]; k++) {
      positions[j + k].setPosition(loci[i].positionMale() +
                                   k*distance_male/(nstep[i] + 1), 1);
      positions[j + k].setPosition(loci[i].positionFemale() +
                                   k*distance_female/(nstep[i] + 1), 2);
      positions[j + k].leftmarker = i;
      positions[j + k].inbetween = k > 0;
    }
    j += nstep[i] + 1;
    positions[j].setPosition(loci.back().positionMale(), 1);
    positions[j].setPosition(loci.back().positionFemale(), 2);
  }
  assertinternal(j == numposition - 1);
  positions[j].leftmarker = loci.size() - 1;
  positions[j].inbetween = false;
  delete [] nstep;
}

void Map::fixedstep() {
  // find position, leftmarker, shouldfindp, inbetween for fixed no.
  // of steps between markers
  allocate(loci.size() + (loci.size() - 1)*(options->steps - 1));
  Uint nstep = options->steps - 1;
  Uint j = 0;
  for (Uint i = 0; i < loci.size() - 1; i++) {
//    const Float distance = loci[i + 1].positionAvg() - loci[i].positionAvg();
    const Float distance_male = (loci[i + 1].positionMale() -
                                 loci[i].positionMale());
    const Float distance_female = (loci[i + 1].positionFemale() -
                                   loci[i].positionFemale());
    assertinternal(distance_male > .0 && distance_female > .0);
    for (Uint k = 0; k <= nstep; k++) {
      positions[j + k].setPosition(loci[i].positionMale() +
                                   k*distance_male/(nstep + 1), 1);
      positions[j + k].setPosition(loci[i].positionFemale() +
                                   k*distance_female/(nstep + 1), 2);
      positions[j + k].leftmarker = i;
      positions[j + k].inbetween = k > 0;
    }
    j += nstep + 1;
  }
  positions[j].setPosition(loci[loci.size() - 1].positionMale(), 1);
  positions[j].setPosition(loci[loci.size() - 1].positionFemale(), 2);
  positions[j].leftmarker = loci.size() - 1;
  positions[j].inbetween = false;
}

void Map::createpos() {
  if (options->maxsteplength > 0)
    maxsteplength();
  else if (options->stepfile.assigned())
    readstepfile(options->stepfile);
  else
    fixedstep();
}

void Map::init(Uint N) {
  loci.resize(N);
}

void Map::reset() {
  start();
}

void Map::addmarker(Uint m, Uint nump, FloatVec p, const string &mn) {
  assertinternal(m < loci.size());
  loci[m].numallele = nump;
  loci[m].name = mn;
  loci[m].markernames.push_back(mn);
  loci[m].locus2markers.push_back(m);

  addpopulationfreq(m, 0, nump, p);
}

void Map::addpopulationfreq(Uint m, Uint popidx, Uint nump, FloatVec p) {
  if (popidx >= loci[m].pi.size()) {
    loci[m].pi.resize(popidx + 1);
    loci[m].pi[popidx];
  }
  loci[m].pi[popidx] = vector<Float>(p, p + nump);
  const Float normconst = sum<Float>(p, nump);
  assertcond(normconst > 0 || nump == 0,
             "No possible alleles at marker " + loci[m].name);
  for (Uint j = 0; j < nump; j++)
    loci[m].pi[popidx][j] = p[j]/normconst;
}

void Map::adddist(Float firstmarker_pos, FloatVec dist, int isex) {
  // isex = 0 for sex-averaged, 1 for male, 2 for female.  add the
  // intermarker distance and finish initialization Should be called
  // once with isex=0 or twice, first with isex=1 and the with
  // isex=2. The first call is used to determine whether unit is cM or
  // recomb (unless the unit is specified in options).
  nsex = options->sexspecific ? 3 : 1;
  if (unit == DEFAULT && isex <= 1) {
    unit = RECOMBINATION;
    for (Uint i = 0; i < loci.size() - 1; i++)
      if (dist[i] > 0.5) {
        unit = CENTIMORGAN;
        break;
      }
  }
  for (Uint i = 0; i < loci.size() - 1; i++)
    loci[i].setTheta(unit == RECOMBINATION ? dist[i] :
                     recombfraccent(dist[i]), isex);
  for (Uint i = 0; i < loci.size(); i++)
    loci[i].shouldfindp = true;


  // set position of first locus
  loci.front().setPosition(firstmarker_pos, isex);

  // After theta has been set for both sexes
  if (isex == 2 || isex == 0) {
    // join markers at he same locus
    for (vector<LocusInfo>::iterator g = loci.begin(); g + 1 != loci.end();)
      if (g->thetaMale() > 0) {
        assertcond(g->thetaFemale() > 0,
                   "recombination fraction > 0 for males but 0 for females");
        g++;
      } else {
        assertcond(g->thetaFemale() == 0,
                   "recombination fraction 0 for males but > 0 for females");

        vector<LocusInfo>::iterator next(g + 1);
        g->merge(*next);

        g = loci.erase(next);
        g--;
      }

    // calculate positions of loci
    for (Uint g = 1; g < loci.size(); g++)
      if (isex == 0)
        loci[g].setPosition(loci[g - 1].positionAvg() +
                            centimorgan(loci[g - 1].thetaMale()), 0);
      else {
        loci[g].setPosition(loci[g - 1].positionMale() +
                            centimorgan(loci[g - 1].thetaMale()), 1);
        loci[g].setPosition(loci[g - 1].positionFemale() +
                            centimorgan(loci[g - 1].thetaFemale()), 2);
      }

    createpos();
  }
}

extern Double runif();

Allele Map::randomallele(Uint gam) const {
  Double rnd = runif();
  Double sum = 0;
  for (Uint j = 0; j < loci[gam].numallele - 1; j++) {
    sum = sum + loci[gam].pi[0][j]; // Note change to allow simulation from multiple pops
    if (sum > rnd) return j + 1;
  }
  return loci[gam].numallele;
}

void Map::readhaplofreqs() {
  if (options->haplofreqfile.empty()) return;

#define HFERROR string("HAPLOFREQFILE input ") + curline + ": "

  for (Uint pop = 0; pop < options->haplofreqfile.size(); pop++) {
    Infile hf;
    hf.setname(options->haplofreqfile[pop]);
    hf.open();
    assertcond(hf, "Unable to open HAPLOFREQFILE '" +
               options->haplofreqfile[pop] + "'");

    ISTRINGSTREAM *inputline = 0;
    Uint curline = 0;
    hf >> ws;
    while (!hf.eof()) {
      getnextline(hf, curline, inputline, "HAPLOFREQFILE");
      hf >> ws;

      double freq;
      readnumeric(freq, *inputline, HFERROR +
                  "Unable to read haplotype frequency");

      vector<pair<Allele, string> > haplotype;
      while (!inputline->eof()) {
        int a;
        readnumeric(a, *inputline, HFERROR + "Unable to read marker allele");
        assertcond(!inputline->eof() && !inputline->fail(),
                   "Unexpected end of line, when expecting marker name");

        string m;
        *inputline >> m >> ws;

        haplotype.push_back(make_pair(a, m));
      }
      assertinternal(!haplotype.empty());

      Uint g = 0;
      while (g < loci.size() &&
             find(loci[g].markernames.begin(), loci[g].markernames.end(),
                  haplotype.front().second) == loci[g].markernames.end())
        g++;

      if (g < loci.size()) {
        assertcond(haplotype.size() == loci[g].markernames.size(),
                   HFERROR + "markers in haplotype don't match map");
        Haplotype ht(haplotype.size());
        for (Uint i = 0; i < haplotype.size(); i++) {
          Uint j = 0;
          while (j < haplotype.size() &&
                 haplotype[i].second != loci[g].markernames[j])
            j++;
          assertcond(j < haplotype.size(),
                     HFERROR + "markers in haplotype don't match map");
          ht[j] = haplotype[i].first;
        }
        if (loci[g].ht.size() != loci[g].pi.size())
          loci[g].ht.resize(loci[g].pi.size());
        loci[g].ht[pop].insert(ht, loci[g].pi[pop].size());
        loci[g].pi[pop].push_back(freq);
      }
    }
    delete inputline;
  }
}

void HaploTree::print() const {
  printutil("");
}
