#ifndef _UNREDUCED
#define _UNREDUCED

#include "basic.h"
#include "SW.hh"

#include <limits.h>

#include "cuddObj.hh"

typedef unsigned int ReducedIndex;

//////////////////////////////////////////////////////////////////////
class Unreduced {
private:
  // For reductions
  ADD frTransform(ADD) const;
  ADD fcrTransform(ADD) const;

  bool intense;
  bool female;

public:
  enum Type {REGULAR, FR, FCR};
  Type type;

  // The beginning of the range of indices influenced by this reduced bit
  ReducedIndex begin;

  // For reductions
  vector<ReducedIndex> flips;

  // For Founder couple reduction
  vector<ReducedIndex> swaps_src;
  vector<ReducedIndex> swaps_dest;

  // Regular constructor
  Unreduced(ReducedIndex b) :
      intense(false), female(false), type(REGULAR),
      begin(b) {}

  // Founder reduction constructor
  Unreduced(const vector<ReducedIndex> &f) :
      flips(f), intense(false), female(false),
      type(FR), begin(f.empty() ? INT_MAX : *min_element(f.begin(), f.end())) {
    assert(begin != INT_MAX);
  }

  // Founder couple reduction constructor
  Unreduced(const vector<ReducedIndex> &f, const vector<ReducedIndex> &src,
            const vector<ReducedIndex> &dest) :
      flips(f), intense(false), female(false), type(FCR),
      swaps_src(src), swaps_dest(dest),
      begin(f.empty() ? INT_MAX : *min_element(f.begin(), f.end())) {
    const ReducedIndex src_min =
      *min_element(swaps_src.begin(), swaps_src.end());
    const ReducedIndex dest_min =
      *min_element(swaps_dest.begin(), swaps_dest.end());
    begin = min(begin, min(src_min, dest_min));
  }

  bool isIntense() const {return intense;}
  void makeIntense() {intense = true;}

  bool isFemale() const {return female;}
  void makeFemale() {female = true;}

  bool swaps(const Unreduced &fr) const {
    assertinternal(type == FCR);
    return fr.flips == swaps_src || fr.flips == swaps_dest;
  }

  bool influences(const ReducedIndex bit) const {
    if (bit < begin) return false;
    else if (type == REGULAR) return bit == begin;
    else {
      if (find(flips.begin(), flips.end(), bit) != flips.end()) return true;
      if (type == FR) return false;
      else {
        return (find(swaps_src.begin(), swaps_src.end(), bit) !=
                swaps_src.end() ||
                find(swaps_dest.begin(), swaps_dest.end(), bit) !=
                swaps_dest.end());
      }
    }
  }
  bool influences(const vector<ReducedIndex> &bits) const {
    for (unsigned int i = 0; i < bits.size(); i++)
      if (influences(bits[i]))
        return true;
    return false;
  }

  friend bool operator<(const Unreduced &a, const Unreduced &b) {
    return a.begin < b.begin || (a.begin == b.begin && a.type < b.type);
  }
  friend bool operator==(const Unreduced &a, const Unreduced &b) {
    return a.begin == b.begin && a.type == b.type;
  }
  friend ostream &operator<<(ostream &out, const Unreduced &a) {
    out << a.type << "\t" << a.begin;
    return out;
  }

  ADD transform(ADD) const;
  bool informative(ADD x) const {
    assertinternal(type != REGULAR);
    return x != transform(x);
  }

  ADD expandZO(ADD &zo) const {
    SW_START("Unreduced::expandZO");
    ADD on, off;
    if (type == REGULAR) {
      ADD var = zo.manager()->addVar(begin);
      on = zo.Cofactor(var);
      off = zo.Cofactor(~var);
    } else {
      on = zo;
      off = transform(zo);
    }
    ADD res = on | off;
    SW_STOP("Unreduced::expandZO");
    return res;
  }

};

#endif // _UNREDUCED
