#include <iostream>
#include <fstream>
#include <iomanip>
#include "files.h"
#include "control.h"
#include "warning.h"
#include "options.h"
#include "trait.h"
#include "model.h"
#include "linkagedist.h"
#include "linkagemodel.h"
#include "parmodel.h"
#include "simulation.h"
#include "genotypes.h"
#include "family.h"
#include "traitdata.h"
#include "utils.h"

// return the index of i in the list usemarkers, if it is in the list,
// and -1 otherwise
int Control::markerused(Uint i, const UintVec usemarkers, Uint totuse) {
  for (Uint j = 0; j < totuse; j++)
    if (i == usemarkers[j]) return j;
  return -1;
}

Trait *trait;

// To input Linkage style datafiles (*.pre and *.dat files)
// Assumes the SAME format as given to GeneHunter (i.e. dat-file 
// with marker name included)
void Control::getdat(Infile& dat, UintVec &usemarkers, Uint &totuse,
                     Uint &totnum, Uint popidx) {
  // marker names, recombination and alleles frequencies go into 'map'
  // disease gene frequency, penetrance, etc. go into 'trait'
  // the 'usemarkers' which markers are used (i.e. line 2 in datafile)
  // tempory variables:
  dat.open();
  Uint ignoreUint;
  string ignorestring;
#define DATERROR string("DATFILE input ") + curline + ": "
  ISTRINGSTREAM *inputline = 0;
  Uint curline = 0;

  // line 1:
  getnextline(dat, curline, inputline, "DATFILE");
  int sexlinked;
  if (popidx == 0) { // Only read for first datfile
    readnumeric(totnum, *inputline, DATERROR +
                "Unable to to read number of markers");
    readnumeric(ignoreUint, *inputline, DATERROR + "ignore 1");
    readnumeric(sexlinked, *inputline, DATERROR +
                "Unable to read sexlinked flag");
    readnumeric(ignoreUint, *inputline, DATERROR + "ignore 2");
    --totnum; // total number of markers in datafile
    assertcond(totnum > 0, DATERROR + "invalid number of markers (" +
	       totnum + ")");
    assertcond(sexlinked == 0 || sexlinked == 1, DATERROR +
	       "sex-linked flag must be either 0 or 1");
    options->sexlinked = sexlinked == 1;
  }

  // line 2: nothing
  getnextline(dat, curline, inputline, "DATFILE");

  // line 3: which markers are used in the map (the number of markers is unknown)
  Uint unnamedmarkeridx = 1;
  int linkagelocusidx = -1;
  getnextline(dat, curline, inputline, "DATFILE");
  if (popidx == 0) { // Only read for first datfile
    totuse = 0;
    usemarkers = new Uint[totnum];
    while(!inputline->eof()) {
      // The following line may be incorrect
      assertcond(totuse <= totnum, DATERROR +
		 "More markers to use than specified in line 1");
      Uint marker = 0;
      readnumeric(marker, *inputline, DATERROR +
		  "Unable to read which markers to use");
      assertcond(marker != 0, DATERROR +
		 "Do not include disease locus (locus 1) in list of markers " +
		 "to analyse");
      if (marker == 1)
        linkagelocusidx = totuse;
      else {
        usemarkers[totuse] = marker;
        assertcond(usemarkers[totuse] <= totnum + 1,
                   DATERROR + "Illegal marker number " + usemarkers[totuse]);
        usemarkers[totuse]--;
        totuse++;
      }
    }
    map.init(totuse);
  }

  // 4, 5:  gene frequencies
  Float df;
  getnextline(dat, curline, inputline, "DATFILE");
  getnextline(dat, curline, inputline, "DATFILE");
  if (popidx == 0) { // Only read for first datfile
    readnumeric(df, *inputline, DATERROR + "Unable to read disease gene freq");
    assertcond(df >= 0.0 && df <= 1.0, DATERROR +
	       "Invalid prevelance (disease gene freq. = " + df + ")");
  }

  // line 6:
  getnextline(dat, curline, inputline, "DATFILE");
  if (popidx == 0) { // Only read for first datfile
    Uint nliab;
    readnumeric(nliab, *inputline, DATERROR +
		"Unable to read number of liability classes");
    trait = new Trait(nliab*(options->sexlinked ? 2 : 1), df, sexlinked);

    // penetrance
    for (Uint i = 0; i < nliab; i++) {
      Uint i1 = options->sexlinked ? 2*i : i;
      getnextline(dat, curline, inputline, "DATFILE");
      readnumeric(trait->penetrance[i1][0], *inputline, DATERROR +
		  "Unable to read penetrance number " + i);
      readnumeric(trait->penetrance[i1][1], *inputline, DATERROR +
		  "Unable to read penetrance number " + i);
      readnumeric(trait->penetrance[i1][2], *inputline, DATERROR +
		  "Unable to read penetrance number " + i);
      assertcond(trait->penetrance[i1][0] >= 0 &&
                 trait->penetrance[i1][1] >= 0 &&
                 trait->penetrance[i1][2] >=0, DATERROR + "Invalid penetrance");
      if (options->sexlinked) {
        Uint i2 = i1 + 1;
        getnextline(dat, curline, inputline, "DATFILE");
        readnumeric(trait->penetrance[i2][0], *inputline, DATERROR +
                    "Unable to read penetrance number " + i);
        readnumeric(trait->penetrance[i2][1], *inputline, DATERROR +
                    "Unable to read penetrance number " + i);
        assertcond(trait->penetrance[i2][0] >= 0 &&
                   trait->penetrance[i2][1] >= 0,
                   DATERROR + "Invalid penetrance");
      }
    }
  }
  else {
    for (Uint i = 0; i < trait->nliability; i++)
      getnextline(dat, curline, inputline, "DATFILE");
  }
  // input marker frequencies and names:

  for (Uint i = 1; i <= totnum; i++) {
    // e.g.: 3  4 # D22S420
    getnextline(dat, curline, inputline, "DATFILE");
    int midx = markerused(i, usemarkers, totuse);
    if (midx != -1) { // use this marker
      Uint markertype;
      Uint allelecount;
      readnumeric(markertype, *inputline, DATERROR +
                  "Unable to read penetrance");
      assertcond(markertype == 3, DATERROR + "Unknown marker type " +
                 markertype);
      readnumeric(allelecount, *inputline, DATERROR +
                  "Unable to read penetrance");
      string markername;
      *inputline >> ignorestring >> ws >> markername;
      if (markername == "") {
        markername = string("M") + unnamedmarkeridx;
        unnamedmarkeridx++;
      }
      FloatVec alfreq = new Float[allelecount];
      getnextline(dat, curline, inputline, "DATFILE");
      for(Uint k = 0; k < allelecount; k++) {
        // e.g.: 0.1 0.5 0.4
        readnumeric(alfreq[k], *inputline, DATERROR +
          "Unable to read allele frequency for marker " + markername);
        assertcond(alfreq[k] >= 0.0 && alfreq[k] <= 1.0, DATERROR +
		      "Invalid allele frequency for marker " + markername);
      }
      if (popidx == 0)
        map.addmarker(midx, allelecount, alfreq, markername);
      else
        map.addpopulationfreq(midx, popidx, allelecount, alfreq);
      delete [] alfreq;
    }
    else {
      // Ignore allele frequencies
      getnextline(dat, curline, inputline, "DATFILE");
    }
  }

  if (popidx == 0) { // Only read for first datfile
    // end line - 2: recomb rates sex specific ? (two numbers: 0  0 )
    getnextline(dat, curline, inputline, "DATFILE");
    Uint sexspec;
    readnumeric(sexspec, *inputline, DATERROR +
                "Unable to read sex-difference type");
    if (sexspec > 0) options->sexspecific = true;

    // end line - 1: recombination (or cM):
    FloatVec dist;
    dist = new Float[totuse];

    Uint nsex = options->sexspecific ? 2 : 1;

    for (Uint jsex = 1; jsex <= nsex; jsex++) {
      getnextline(dat, curline, inputline, "DATFILE");
      if (linkagelocusidx == 0) {
        Float curdist = -1.0;
        readnumeric(curdist, *inputline, DATERROR +
                    "Unable to read distance from disease locus to first marker");
      }
      Float lastdist = 0.0;
      for(Uint j = 0; j < totuse - 1; j++) {
        Float curdist = -1.0;
        readnumeric(curdist, *inputline, DATERROR +
                    "Unable to read intermarker distance number " + (j + 1));
        assertcond(curdist >= 0, DATERROR +
                   "Negative distance between markers: " +
                   Floattostring(curdist, 4));
        if (linkagelocusidx > 0 && j == Uint(linkagelocusidx)) {
          j--;
          lastdist = curdist;
        }
        else {
          if (options->unit == CENTIMORGAN || options->unit == DEFAULT)
            dist[j] = curdist + lastdist;
          else
            dist[j] = curdist + lastdist - 2*curdist*lastdist;
          lastdist = 0.0;
//           if (dist[j] == 0)
//             warning("Distance between two markers set to 0 in datfile!");
          if (dist[j] > 1000) {
            warning("Distance between two markers greater than 1000cM in datfile, set to 1000cM!");
            dist[j] = 1000;
          }
        }
      }
      map.adddist(.0, dist, nsex == 1 ? 0 : jsex);
    }
    delete [] dist;

    // end line: (e.g. 1 0.10000 0.450000)
    getnextline(dat, curline, inputline, "DATFILE");

    Parmodel::setdefaulttrait(trait);
    if (options->simulation != 0) options->simulation->trait = trait;
  }
  delete inputline;
  dat.close();
}

void Control::getpre(Infile& pre, const UintVec usemarkers, const Uint totuse,
                     const Uint totnum, Uint popidx,
                     String2Marker *string2marker, String2PN *string2pn,
                     Chromosome *ch) {
  string fid, pid;
  Stringvector faid;
  Stringvector moid;

  int sex, ds, liab = 0;
  Allele *a1 = 0;
  Allele *a2 = 0;
  if (totnum > 0) {
    a1 = new Allele[totnum];
    a2 = new Allele[totnum];
  }
#define PREERROR string("PREFILE input ") + curline + ": "

  pre.open();
  Uint k = 0, curline = 0;
  Family *last = firstorig;
  while (last != 0 && last->next != 0) last = last->next;
  Family *fam = last;
  pre >> fid;
  bool firstfamily = true;

  Boolvector uninformative;
  while (true) {
    bool familychange = pre.eof() || firstfamily || fam->id != fid;
    if (familychange) {
      bool ok = true;
      if (!firstfamily) {
        // Set genotyped flag
        if (options->chromosome == "") {
          uninformative.clear();
          uninformative.resize(map.loci.size());
          for (Uint gam = 0; gam < map.loci.size(); gam++) {
            const Allele a = (fam->first->genotyped(gam) ?
                              fam->first->gen[0][gam] : ALLELEUNKNOWN);
            uninformative[gam] = true;
            for (Person *p = fam->first; p != 0 && uninformative[gam];
                 p = p->next)
              uninformative[gam] = uninformative[gam] &&
                ((a == ALLELEUNKNOWN && !p->genotyped(gam)) ||
                 ((a != ALLELEUNKNOWN && p->genotyped(gam)) &&
                 ((a == p->gen[0][gam]) && (a == p->gen[1][gam]))));
          }
        }
        else {
          assertinternal(string2pn != 0);
          for (Person *p = fam->first; p != 0; p = p->next) {
            String2PN::const_iterator q = string2pn->find(p->id);
            if (q != string2pn->end()) {
              if (options->affectionfile.assigned())
                p->origdstat = p->dstat = q->second.dstat;
            }
            else {
              if (options->affectionfile.assigned())
                p->origdstat = p->dstat = UNKNOWN;
            }
            assertcond(p->dstat <= 2, string("Illegal affection status of ") +
                       p->dstat + " for person " + p->id);

            int nogt[] = {options->unknownrepeat, options->unknownrepeat};
            const Uint numendmarkers = (options->addendmarkers ? 1 : 0);
            // Set liability classes
            p->liability = options->sexlinked ? 1 - p->sex : 0;
            // Set genotypes for genotyped people
            q = string2pn->find(p->id);
            if (q != string2pn->end() && q->second.genotyped()) {
              p->allocgenotypes(map.loci.size());
              Uint midx = numendmarkers;
              vector<string>::const_iterator mn = ch->markers.begin();
              while (midx < map.loci.size() - numendmarkers) {
                assertinternal(mn != ch->markers.end());
                Marker &marker = (*string2marker)[*mn];
                IntVec als = q->second.get_rep(marker.idx);
                if (als == 0) als = nogt;
                if (als[0] != options->unknownrepeat) {
                  Int2int::iterator fr = marker.rep2allele.find(als[0]);
                  assertinternal(fr != marker.rep2allele.end());
                  fr = marker.rep2allele.find(als[1]);
                  assertinternal(fr != marker.rep2allele.end());
                  assertinternal(marker.rep2allele[als[0]] != 0 &&
                                 marker.rep2allele[als[1]] != 0);
                  p->gen[0][midx] = marker.rep2allele[als[0]];
                  p->gen[1][midx] = marker.rep2allele[als[1]];
                }
                else {
                  p->gen[0][midx] = p->gen[1][midx] = ALLELEUNKNOWN;
                }
                // Increment midx and m
                mn++;
                midx++;
              }
            }
          }
        }
        fam->organize(faid, moid);
        faid.clear();
        moid.clear();
      }
      firstfamily = false;
      if (!ok) {
        if (fam == firstorig) {
          delete fam;
          fam = firstorig = 0;
        }
        else {
          delete fam;
          fam = last;
        }
      }
      if (!pre.eof()) {
        // start of a new family ...
        if (fam == 0) {
          last = fam = new Family(fid, popidx);
          firstorig = fam;
        }
        else {
          last = fam->next = new Family(fid, popidx);
          fam = fam->next;
        }
      }
      else break;
      k = 0;
    }
    ISTRINGSTREAM *inputline = 0;
    getnextline(pre, curline, inputline, "PREFILE");   // e.g.: Fam1 PN1 Fa1 Mo1
    string fathersid, mothersid;
    *inputline >> pid >> fathersid >> mothersid;
    faid.push_back(fathersid);
    moid.push_back(mothersid);
    readnumeric(sex, *inputline, PREERROR + "Unable to read sex");
    assertcond(sex == 1 || sex == 2,
               "Illegal sex for " + pid  + " in family " + fid);
    if (!options->affectionfile.assigned())
      readnumeric(ds, *inputline, PREERROR + "Unable to read disease status");
    bool genotyped = false;
    if (options->datfile.size() > 0) {
      if (trait->nliability > (options->sexlinked ? 2 : 1)) {
        readnumeric(liab, *inputline, PREERROR +
                    "Unable to read liability class");
        liab--;
        if (options->sexlinked)
          liab = 2*liab + (sex == 1 ? 1 : 0);
//         if (options->sexlinked && sex == 1)
//           liab += trait->nliability/2;
      } else
        liab = options->sexlinked ? 2 - sex : 0;

      for (Uint i = 1; i <= totnum && (i < 2 || options->simulation == 0);
           i++) {
        int midx = markerused(i, usemarkers, totuse);
        if (midx == -1) {
          Uint dumb;
          readnumeric(dumb, *inputline, PREERROR +
                      "Unable to read first allele for marker number " + i);
          readnumeric(dumb, *inputline, PREERROR +
                      "Unable to read second allele for marker number " + i);
        }
        else {
          int al1, al2;
          readnumeric(al1, *inputline, PREERROR +
                      "Unable to read first allele for marker number " + i);
          readnumeric(al2, *inputline, PREERROR +
                      "Unable to read second allele for marker number " + i);
          assertcond(al1 >= 0 && al1 <= int(map.loci[midx].numallele),
                     string("Illegal allele value ") + al1 +
                     " for marker number " + i);
          assertcond(al2 >= 0 && al2 <= int(map.loci[midx].numallele),
                     string("Illegal allele value ") + al2 +
                     " for marker number " + i);
          if (al1 != 0) genotyped = true;
          if (al1 < al2) {
            a1[midx] = al1;
            a2[midx] = al2;
          }
          else {
            a1[midx] = al2;
            a2[midx] = al1;
          }
        }
      }
    } else
      liab = options->sexlinked ? 2 - sex : 0;

    k++;
    assertcond(liab >= 0 && liab < 10000, string("Invalid liability class ")
               + liab + " for person " + pid + " in family " + fid);
    Person *p = fam->addperson(pid, Sex(sex-1), Diseasestatus(ds), liab,
                               traitdata->hastraitvalue(pid));
    if (options->chromosome == "") {
      if (genotyped) p->setgenotypes(a1, a2, totuse);
      else p->setgenotypes(0, 0, totuse);
    }
    pre >> fid;

    delete inputline;
  }

  pre.close();
}

void Control::inputld() {
  UintVec usemarkers;
  Uint totnum, totuse;

  for (Uint popidx = 0; popidx < options->prefile.size(); popidx++) {
    Infile datfile, prefile;
    datfile.setname(options->datfile[popidx]);
    getdat(datfile, usemarkers, totuse, totnum, popidx);
    prefile.setname(options->prefile[popidx]);
    getpre(prefile, usemarkers, totuse, totnum, popidx);
  }

  assertcond(firstorig != 0, "\nNo informative families to analyse!");
  delete [] usemarkers;
}
