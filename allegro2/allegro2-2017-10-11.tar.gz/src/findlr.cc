#include "probability.h"
#include "files.h"
#include "distribution.h"
#include "options.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include "matrix.h"
#include "map.h"
#include "recombdist.h"
#include "haldane.h"
#include "fmtout.h"
#include "family.h"
#include "control.h"

void Probability::check(const string &s, int gam, FloatVec d, Float *L) {
  static int checkcount = 10;
  checkcount++;
  if (options->checkcondition > 0 &&
      (checkcount % options->checkcondition) == 0) {
    Float sm = 1/normal<Float>(d, numiv);
    if (s == "lq") {
      l_nc[gam] *= sm;
    }
    if (L != 0) *L += -log(sm);
  }

#ifdef DEBUG
  for (IV v = 0; v < numiv; v++)
    assertinternal(finite(d[v]) && !isnan(d[v]));

  Float sum = 0.0;
  for (IV i = 0; i < numiv; i++) sum += d[i];
  clog.setf(ios::scientific);
  clog << "check-" << s << "[" << gam << "]: " << sum << endl;
  clog.flush();
#endif // DEBUG
}

// Recursive function to calculate pi(x) for a single founder couple
void Probability::calculatefctrans(FloatVec D, FloatVec S, Float tht) {
  for (Foundercouple *fc = fam->firstfoundercouple; fc != 0; fc = fc->next) {
    Uint n = POPCOUNT(fc->wife->mask);
    // First loop over bits of husband and wife
    for (IV w = 0; w <= fc->wife->mask; w += fc->wife->lastbit)
      for (IV h = (w >> n); h <= fc->husband->mask; h += fc->husband->lastbit)
        fcinnerprod(D, S, tht, h | w, fc->pi(h | w), fc);
  }
}

// Calculate founder couple transition for a founder couple
void Probability::fcinnerprod(FloatVec D, FloatVec S, Float tht, IV a, IV b,
                              Foundercouple *fc) {
  Float fac = tht/(1.0 - tht);
  Float sfac, wfac;
  IV inc1, inc2, to2;
  if (POPCOUNT(fc->wife->mask) == 0) {
    inc1 = 1;
    inc2 = to2 = numiv;
  }
  else {
    inc1 = fc->wife->mask + fc->wife->lastbit;
    inc2 = 1;
    to2 = fc->lastcbit();
  }
  for (IV v = 0; v < numiv; v += inc1) {
    for (IV w = v; w < v + to2; w += inc2) {
      if (POPCOUNT(w & fc->mask) % 2) {
        sfac = -fac;
        wfac = (1.0 - 2.0*tht)/(1.0 - tht);
      }
      else {
        sfac = fac;
        wfac = 1/(1.0 - tht);
      }
      if (fc == fam->firstfoundercouple) {
        if (a == b) D[a | w] = S[a | w]*factors[wtstar[a | w]]*wfac;
        else {
          D[a | w] = (S[a | w] + sfac*S[b | w])*factors[wtstar[a | w]];
          D[b | w] = (S[b | w] + sfac*S[a | w])*factors[wtstar[b | w]];
        }
      }
      else {
        if (a == b) D[a | w] = D[a | w]*wfac;
        else {
          Float tmp = D[a | w];
          D[a | w] = tmp + sfac*D[b | w];
          D[b | w] = D[b | w] + sfac*tmp;
        }
      }
    }
  }
}

void Probability::Ttrans(FloatVec D, FloatVec S, Float tht_male,
                         Float tht_female) {
  // Note D == S was allowed, but not used, earlier
  assertinternal(!options->foundercouples || D != S);

  if (options->sexspecific) {
    assertinternal(fam->numfc == 0);
    assertinternal(tht_female >= 0);
    Float factor = 1.0 - 2.0*tht_male;
    Float factor_female = 1.0 - 2.0*tht_female;
    factors[0] = 1.0;
    factors_female[0] = 1.0;
    for (Uint i = 1; i <= 2*numbits; i++) {
      factors[i] = factors[i - 1]*factor;
      factors_female[i] = factors_female[i - 1]*factor_female;
    }
    for (IV v = 0; v < numiv; v++)
      D[v] = S[v]*factors[wtstar[v]]*factors_female[wtstar_female[v]];
  }
  else {
    const Float tht = tht_male;
    const Float factor = 1.0 - 2.0*tht;
//  factors[0] = 1.0/Float(numiv); // to effect renormalization in inverse Fourier transform
    factors[0] = 1.0;
    for (Uint i = 1; i <= 2*numbits; i++)
      factors[i] = factors[i - 1]*factor;

    if (fam->numfc == 0)
      for (IV v = 0; v < numiv; v++)
        D[v] = S[v]*factors[wtstar[v]];
    else
      calculatefctrans(D, S, tht);
  }
}

void Probability::outputvec(ostream& str, int gam, FloatVec x, IV N) {
  str.setf(ios::scientific);
  str.precision(12);
  if (!options->montecarlo) normal<Float>(x, N);
  for (IV k = 0; k < N; k++) {
    str << gam << "\t" << k << "\t" << x[k] << "\n";
  }
}

void fixnumericalfft(FloatVec lq, Uint numiv) {
  for (IV v = 0; v < numiv; v++)
    if (lq[v] < .0) lq[v] = 1e-300;
}

void Probability::findlq(FloatVec lqhatlast, FloatVec lqhat, FloatVec lq,
                         FloatVec q, Float &L, Float theta,
                         Float theta_female, Uint gam) {
  // hat(l[gam-1] . q[gam-1])
  Ttrans(lq, lqhatlast, theta, theta_female);
  // hat(l[gam-1] . q[gam-1]) . hat(T[gam-1])
  fft(lq, lq, numiv, numbits); // l[gam]

  fixnumericalfft(lq, numiv);

  if (options->montecarlo) l_nc[gam] = sum<Float>(lq, numiv);
  if (options->lfile && gam <= options->maxlocusforoutput)
    outputvec(options->lfile, gam, lq, numiv);
  elemprod(lq, lq, q, numiv);  // l[gam] . q[gam]
  // Check if lq and q are incompatable because of numerical instability
  bool allzeroes = true;
  for (IV v = 0; v < numiv && allzeroes; v++)
    if (lq[v] != 0) allzeroes = false;
  assertcond(!allzeroes, "The distance between markers " +
             map->loci[gam].name + " and " + map->loci[gam + 1].name +
             " is only " + Floattostring(theta, 12) +
             ", and is causing numerical inconsistencies");
//     if (theta[lastinformative] < .0004) L += log(normal<Float>(lq, numiv));
  check("lq", gam, lq, &L);
  fft(lqhat, lq, numiv, numbits); // hat(l[gam] . q[gam])
}

void Probability::mrktopos(FloatVec posdist, FloatVec mrkhat,
                           Uint gam, Uint pos) {
  Ttrans(posdist, mrkhat,
         recombfraccent(map->loci[gam].positionMale() -
                        map->positions[pos].positionMale()),
         recombfraccent(map->loci[gam].positionFemale() -
                        map->positions[pos].positionFemale()));
  fft(posdist, posdist, numiv, numbits);
  fixnumericalfft(posdist, numiv);
}

// void Probability::finddpt(Uint pos, FloatVec r) {
//   // The next informative marker strictly to the left of this one
//   int slm = (pos > 0 ? leftmarker[pos - 1] : NOLEFTMARKER);
//   FloatVec l = q->getrow(map->loci.size() - 1, false);
//   FloatVec d = l;
//   if (slm == NOLEFTMARKER && r == 0)
//     copyval(d, 1.0/Double(numiv), numiv);
//   else {
//     if (slm == NOLEFTMARKER)
//       l = r;
//     else {
//       mrktopos(l, lqhat->getrow(slm, true), slm, pos);
//       if (r != 0) elemprod(d, l, r, numiv);
//     }
//     normal<Float>(d, numiv);
//   }
//   Distribution::set(q->getrow(map->loci.size() - 1, false),
//                     map->leftmarker[pos], "dpt");
// }

void Probability::findp(const FamilyMap &fm, Uint pos, FloatVec p) {
  int lm = fm.leftmarker[pos];
  int rm = fm.rightmarker[pos];
  if (map->positions[pos].inbetween ||
      (!fm.informative[map->positions[pos].leftmarker] &&
       fm.shouldfindp[pos])) {
    if (lm == FamilyMap::NOLEFTMARKER) {
      mrktopos(p, rqhat, rm, pos);
      if (options->pseudoautosomal) {
        FloatVec p0 = q->getrow(0, false);
        fam->pseudonull(p0);
        fft(p0, p0, numiv, numbits);
        Ttrans(p0, p0, recombfraccent(map->positions[pos].positionMale()),
               recombfraccent(map->positions[pos].positionFemale()));
        fft(p0, p0, numiv, numbits);
        assertinternal(normal<Float>(p0, numiv) > 0);
        elemprod(p, p, p0, numiv);
      }
    }
    else if (rm == FamilyMap::NORIGHTMARKER)
      mrktopos(p, lqhat->getrow(lm, true), lm, pos);
    else { // Inbetween markers or at an uninformative marker
      mrktopos(p, lqhat->getrow(lm, true), lm, pos);
      mrktopos(q->getrow(map->loci.size() - 1, false), rqhat, rm, pos);
      elemprod(p, p, q->getrow(map->loci.size() - 1, false), numiv);
    }
    normal<Float>(p, numiv);
  }
  else if (fm.informative[map->positions[pos].leftmarker]) {
    if (rm != FamilyMap::NORIGHTMARKER && options->calcrpt)
      Recombdist::set(p, rqhat, lqhat->getrow(lm, true), lm, fm.theta[lm],
                      (options->sexspecific ? fm.theta_female[lm] : -1), "rpt");
    if (rm == FamilyMap::NORIGHTMARKER) {
      startright(lm);
      copyvec(p, lq->getrow(lm, true), numiv);
    }
    else {
                                      // rqhat starts as rqhat(k + 1)
      Ttrans(p, rqhat, fm.theta[lm], fm.theta_female[lm]);
                                      // p contains rqhat(k + 1) T(k)hat
      fft(rqhat, p, numiv, numbits);  // rqhat contains r(k)
      fixnumericalfft(rqhat, numiv);
      check("r", lm, rqhat);
      if (options->rfile != 0 && lm <= int(options->maxlocusforoutput))
        outputvec(options->rfile, lm, rqhat, numiv);
      if (map->loci[lm].shouldfindp)
        elemprod(p, lq->getrow(lm, true), rqhat, numiv); // p contains p(k)
      elemprod(rqhat, rqhat, q->getrow(lm, true), numiv);// rqhat contains rq(k)
      fft(rqhat, rqhat, numiv, numbits);  // rqhat contains rqhat(k)
    }
    normal<Float>(p, numiv);
  }
#ifdef DEBUG
  check("p", pos, p);
  for (IV v = 0; v < numiv; v++) assertinternal(p[v] >= 0);
#endif
  if (options->pfile && pos <= options->maxlocusforoutput)
    outputvec(options->pfile, pos, p, numiv);
}

void Probability::startright(int gam) {
  fft(rqhat, q->getrow(gam, true), numiv, numbits);
  check("r", gam, rqhat);
}

void Probability::lqfromlqhat(int gam, FloatVec lqp) {
  fft(lqp, lqhat->getrow(gam, true), numiv, numbits);
  fixnumericalfft(lqp, numiv);
  scalvec(lqp, 1.0/float(numiv), lqp, numiv);
}
