#include <cmath>
#include <iostream>
#include <iomanip>

output(int gam, double sv, double sg, double ad, double rd) {
  cout.precision(2);
  cout.setf(ios::scientific);
  cout << setw(8) << setiosflags(ios::left) << gam 
       << setw(11) << sv
       << setw(11) << sg
       << setw(11) << ad 
       << setw(11) << rd << endl;
}

main() {
  int gam,gamgh;
  double p;
  double pgh;
  int k = 0;
  int gamlast = -1;
  cout << "Locus  Sum-allegro  Sum-gh    Abs-diff   Rel-diff\n";
//        ^         ^         ^         ^         ^
//        0         10        20        30        40
  double amax,rmax,sum,sumgh;
  while (true) {
    k++;
    cin >> gam >> p >> gamgh >> pgh;
    if (cin.eof()) break;
    if (gam != gamgh) {
      cerr << "Unequal loci numbers on line " << k << endl;
      abort();
    }
    if (gam != gamlast) {
      if (gamlast != -1) output(gamlast,sum,sumgh,amax,rmax);
      amax = 0;
      rmax = 0;
      sum = 0;
      sumgh = 0;
      gamlast = gam;
    }
    sum += p;
    sumgh += pgh;
    double pmax = p > pgh ? p : pgh;
    double adiff = abs(p-pgh);
    double rdiff = pmax == 0 ? 0 : adiff/pmax;
    if (adiff > amax) amax = adiff;
    if (rdiff > rmax) rmax = rdiff;
  }
  output(gam,sum,sumgh,amax,rmax);
}


