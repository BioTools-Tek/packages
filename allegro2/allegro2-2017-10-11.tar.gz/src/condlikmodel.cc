#include "files.h"
#include "calcqtl.h"
#include "condlikmodel.h"
#include "inherdist.h"
#include "fmtout.h"
#include "ibddist.h"

//////////////////////////////////////////////////////////////////////
// Condlikmodel
Condlikmodel::Condlikmodel(const string &p, const string &tr, bool maxG,
                           bool maxA, bool maxD, Double shr, const string &of,
                           const string &fof) :
    QTLmodel(p, tr, true, maxG, maxA, maxD, 1.0, shr) {
  distribution = Inherdist::getinherdist(pt);
  setfiles(of, fof, string("condlik.") + shr + "." + pt,
           "Conditional likelihood output");
//  distribution = IBDdist::getibddist(pt, "qtl");
}

void Condlikmodel::print() const {
  string out = "MODEL condlik " + pt + " ";
  out += "shared:" + (maximizeG ? "max" : Floattostring(shared, 2)) + " ";
  message(out + outfile.name + " " + foutfile.name);
}

Double Condlikmodel::calculate(DoubleVec fl, Double S, Double G,
                               Double A, Double D, Uint gam) {
  if (false) {
    IBDdist *pairwiseibd = (IBDdist *)distribution;
    Double l = 0.0;
    for (Uint ifam = 0; ifam < nfam(); ifam++) {
      Family *fam = distribution->families[ifam];
      fam->calckinship();

      FloatVec prior_ibd1;
      FloatVec prior_ibd2;
      pairwiseibd->getprioribd(ifam, prior_ibd1, prior_ibd2);
      const Double lp0 = loglik.calc(fam, prior_ibd1, prior_ibd2, S, G, A, D,
                                     trait);

      FloatVec ibd1;
      FloatVec ibd2;
      pairwiseibd->getposterioribd(ifam, ibd1, ibd2, gam);
      const double lpA = loglik.calc(fam, ibd1, ibd2, S, G, A, D, trait);
      l += fl[ifam] = (lpA - lp0)/log(10.);
    }
    return l;
  }
  else
    return QTLmodel::calculate(fl, S, G, A, D, gam);
}
