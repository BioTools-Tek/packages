#include "files.h"
#include "linkagedist.h"
#include "options.h"
#include "family.h"
#include "vecutil.h"
#include "cuddutil.h"
#include "SW.hh"

///////////////////////////////////////////////////////////////////////
// Linkagedist

Linkagedist::~Linkagedist() {
  while (!familydata.empty()) {
    delete familydata.back();
    familydata.pop_back();
  }
  delete [] Lnull;
}

void Linkagedist::reset(Uint np) {
  while (!familydata.empty()) {
    delete familydata.back();
    familydata.pop_back();
  }
  npos = np;
  delete [] Lnull;
  Lnull = new Double[np];
}

void Linkagedist::nextfam(bool mtbdd, Uint pos, DoubleVec p0) {
  if (pos == 0)
    if (options->sexlinked == getsexlinked())
      familydata.push_back(new Familydata(this));
  const IV numiv = curfamily()->numiv();
  if (isnullconstant()) {
    if (mtbdd) {
      ADD one(calclinkage->S[0].manager()->addOne());
      Lnull[0] = calclinkage->sumLp(one,
                                    pow(2., double(curfamily()->numbits)));
    } else
      Lnull[0] = sum<Double>(calclinkage->vec, numiv)/Double(numiv);
    copyval(Lnull, Lnull[0], npos);
  }
  else {
    assertinternal(!mtbdd);
    for (IV v = 0; v < numiv; v++) Lnull[pos] += calclinkage->vec[v]*p0[v];
  }
}

void Linkagedist::set(ADD &pv, double sum_pv, Uint pos) {
  SW_START("Linkagedist::set");
  if (options->sexlinked == getsexlinked())
    familydata.back()->LR[pos] = calclinkage->sumLp(pv, sum_pv)/Lnull[pos];
  SW_STOP("Linkagedist::set");
}

void Linkagedist::set(FloatVec pv, Uint pos) {
  if (options->sexlinked == getsexlinked()) {
    Double LR = 0.0;
    DoubleVec L = calclinkage->vec;
    const IV numiv = curfamily()->numiv();
    for (IV v = 0; v < numiv; v++) LR += pv[v]*L[v];
    LR /= Lnull[pos];
    familydata.back()->LR[pos] = LR;
  }
}

void Linkagedist::skipfam() {
  if (options->sexlinked == getsexlinked()) {
    if (!familydata.empty()) {
      delete familydata.back();
      familydata.pop_back();
    }
  }
}

bool Linkagedist::usefamily(Family *fam, bool mtbdd) const {
  Uint ninf = 0;
  for (Person *p = fam->first; p != 0; p = p->next)
    if (p->dstat != UNKNOWN) ninf++;
  if (ninf <= 1 || fam->numbits == 0)
    return false;
  else
    return calclinkage->use(fam, mtbdd);
}

void Linkagedist::getuninteresting(::set<Unreduced> &uninteresting) {
  calclinkage->getuninteresting(uninteresting);
}
