#ifndef BASIC
#define BASIC
#include "config.h"

#include <new>
#include <string>
#include <vector>
#include <allegro.stdint.h>
#include <limits.h>

#ifndef NAN
#define NAN 9.999999999999999e300
#endif // NAN

#include <cmath>
#include <ctype.h>

#ifdef HAVE_IEEEFP_H
#include <ieeefp.h>
#endif // HAVE_IEEEFP_H

#ifdef HAVE_SSTREAM
#include <sstream>
#define ISTRINGSTREAM istringstream
#else
#include <strstream>
#define ISTRINGSTREAM istrstream
#endif

#include <stdint.h>

using namespace std;

////////////////////////////////////////////////////////////////////////////
// Primary typedefs
typedef double            Float;
typedef double            Double;
typedef unsigned char     Allele;
typedef int               Sex;
typedef uint64_t          IV;
typedef unsigned long int Uint;

////////////////////////////////////////////////////////////////////////////
// Constanstants and enums
const int MALE = 0;
const int FEMALE = 1;
const Allele ALLELEUNKNOWN = 0;
const Uint MAXBITS = 8*sizeof(IV);

enum Diseasestatus{UNKNOWN, UNAFFECTED, AFFECTED};
enum Unit {CENTIMORGAN, RECOMBINATION, DEFAULT};

#if __GNUC__ > 3 || (__GNUC__ == 3 && __GNUC_MINOR__ >= 4)
#define POPCOUNT(x) __builtin_popcountll(x)
#else
inline unsigned int POPCOUNT(IV n) {
  IV x, y;
  x = n & 0x55555555;
  y = (n >> 1) & 0x55555555;
  n = x + y;
  x = n & 0x33333333;
  y = (n >> 2) & 0x33333333;
  n = x + y;
  x = n & 0x0f0f0f0f;
  y = (n >> 4) & 0x0f0f0f0f;
  n = x + y;
  x = n & 0x00ff00ff;
  y = (n >> 8) & 0x00ff00ff;
  n = x + y;
  x = n & 0x0000ffff;
  y = (n >> 16);
  n = x + y;
  return n;
}
#endif

////////////////////////////////////////////////////////////////////////////
// Assert functions
#ifdef DEBUG_ASSERT
#include <assert.h>
#define ASSERT_FALSE assert(false)
#else
#define ASSERT_FALSE
#endif // DEBUG_ASSERT

void message(const string &);
string operator+(const string& s, int n);

#define assertcond(cond,msg) { \
  if (!(cond)) { \
    message(string("ERROR ") + (msg)); \
    ASSERT_FALSE; \
    exit(1); \
  } \
}

#ifdef DECODE
#define assertinternal(cond) { \
  if (!(cond)) { \
    message(string("ERROR internal error in ") + __FILE__ + " at line " + __LINE__ + "!"); \
    ASSERT_FALSE; \
    exit(1); \
  } \
}
#else
#define assertinternal(cond) { \
  if (!(cond)) { \
    message("ERROR internal error!!"); \
    exit(1); \
  } \
}
#endif // DECODE

#define todo(msg) assertcond(false,string("TODO: ") + (msg))

///////////////////////////////////////////////////////////////////////////
// Hashtable typedefs
//#include <unordered_map>  //Backwards compatibility warning add to (CXXFLAGS = -std=c++0x line139 makefile)
#include <ext/hash_map>  // But ext/hash_map has not been deprecated, so still okay!
using __gnu_cxx::hash_map;


struct stringhash {
private:
  __gnu_cxx::hash<const char*> hasher;

public:
  size_t operator()(const string &a) const
    {return hasher(a.c_str());}
};

typedef hash_map<string, Double, stringhash> String2Double;
typedef hash_map<string, bool, stringhash> String2Bool;
typedef hash_map<string, Uint, stringhash> String2Uint;

///////////////////////////////////////////////////////////////////////////
// Vector and matrix types
typedef Double *DoubleVec;
typedef Float *FloatVec;
typedef int *IntVec;
typedef bool *BoolVec;
typedef Uint *UintVec;
typedef IV *IVVec;
typedef string *StringVec;

typedef Double **DoubleMat;
typedef Float **FloatMat;
typedef int **IntMat;
typedef Uint **UintMat;
typedef IV **IVMat;

typedef vector<string> Stringvector;
typedef vector<Double> Doublevector;
typedef vector<Uint> Uintvector;
typedef vector<bool> Boolvector;

////////////////////////////////////////////////////////////////////////////
// Memory management
template<class T>
T **newmatrix(Uint m, Uint n) {
  T **x;
  if (m == 0) x = 0;
  else {
    x = new T *[m];
    if (n == 0) for (Uint i = 0; i < m; i++) x[i] = 0;
    else {
      x[0] = new T[n*m];
      for (Uint i = 1; i < m; i++)
        x[i] = x[i - 1] + n;
    }
  }
  return x;
}

template<class T>
T **newsymmetricmatrix(Uint n) {
  T **x;
  if (n == 0) x = 0;
  else {
    x = new T *[n];
    x[0] = new T[(n*(n + 1))/2];
    for (Uint i = 1; i < n; i++)
      x[i] = x[i - 1] + i;
  }
  return x;
}

template<class T>
void deletematrix(T &x) {
  if (x != 0) {
    delete [] x[0];
    delete [] x;
    x = 0;
  }
}

//mct -- commented out because gnu++0x has its own next() that overrides this one?
// It has only been an issue when including std=gnu_c++0x in the Makefile
template<class Iter>
Iter next(Iter i) {
    i++;
    return i;
}


template<class T>
inline T square(T x) {return x*x;}

#ifdef DEBUG_OUTPUT
#include <sys/types.h>
#include <unistd.h>
#include <fstream>

inline unsigned int memoryUse() {
  const pid_t pid = getpid();
  const string proc_file_name(string("/proc/") + pid + "/status");
  ifstream proc_file(proc_file_name.c_str());
  unsigned int mem = 0;
  while (!proc_file.eof()) {
    string str;
    proc_file >> str >> ws;
    if (str == "VmData:") {
      string unit;
      proc_file >> str >> unit >> ws;
      assertinternal(unit == "kB");
      mem = atoi(str.c_str());
    }
  }

  return mem;
}
#endif // DEBUG_OUTPUT

///////////////////////////////////////////////////////////////////////////
// Very commonly used classes
class Family;
class Person;
class Map;

#endif // _BASIC

/*
Notational conventions
* In comments, TeX style subscripts are a_i and superscripts a^k
* In general underscores are not used in identifiers
* Class names and variable names are in singular
* Typedefs and class names have initial capital, with a few exceptions
  (e.g. Uint, Float, Double)
* Variable and function names are all lowercase with few exceptions,
  (e.g. findMgam, N)
* Constants (including enum constants) are all capitals
* Sometimes the class name is spelled out in full and an abbreviation is used 
  for an instantiation. In other cases it is just the initial capital in the 
  class name that distinguishes (Sex and sex). The third possibility is to 
  use different words for class and variable (Person and member)
*/
