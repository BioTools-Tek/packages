#ifndef _CALC
#define _CALC
#include "basic.h"
#include "cuddObj.hh"

#include <set>

class Unreduced;

class Calc {
protected:
  typedef vector<Calc *> Calcvector;
  static Calcvector calcs;

  Calc(const string &cid) : id(cid), vec(0), S(0) {calcs.push_back(this);}
  string id;
  IV numscores;
  virtual void set_up(Family */*first*/, IV /*maxnumiv*/) {}
  virtual void clean_up() {}
  virtual void calcnumscores(Family *first, IV maxnumiv);
  static Calc *findcalc(const string &desc);
  virtual void operator()(Family *fam) = 0;
  virtual void operator()(Family *fam, Cudd &mgr) = 0;

public:
  virtual ~Calc() {delete [] vec;}
  virtual string getid() {return id;}
  static void calculate(Family *fam);
  static void calculate(Family *fam, Cudd &mgr);
  static bool setup(Family *first, IV maxnumiv);
  static void cleanupS();
  static Double countvecsneeded(Family *first, IV maxnumiv);
  void getuninteresting(set<Unreduced> &uninteresting);
  virtual string describe() const {return id;}
  DoubleVec vec;
  ADDvector S;
};

#endif // _CALC
