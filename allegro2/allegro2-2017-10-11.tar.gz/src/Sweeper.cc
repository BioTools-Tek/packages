#include <algorithm>
#include "Sweeper.hh"
#include "cuddInt.h"
#include "vecutil.h"
#include "cuddutil.h"
#include "ConvolutionStep.hh"
#include "family.h"
#include "control.h"
#include "distribution.h"
#include "recombdist.h"

#include "SW.hh"

bool ConvolutionStep::allow_swap = true;

ADD Unreduced::transform(ADD a) const {
  assertinternal(type != REGULAR);
  ADD res;
  if (type == FR) {
    SW_START("frTransform");
    res = frTransform(a);
    SW_STOP("frTransform");
  } else {
    assertinternal(type == FCR);
    SW_START("fcrTransform");
    res = fcrTransform(a);
    SW_STOP("fcrTransform");
  }
  return res;
}

ADD Unreduced::frTransform(ADD a) const {
  Cudd *mgr = a.manager();
  const int size = mgr->ReadSize();
  ADDvector f(size, mgr);

  for (int i = 0; i < size; i++)
    f[i] = mgr->addVar(i);
  for (unsigned i = 0; i < flips.size(); i++)
    f[flips[i]] = f[flips[i]].Cmpl();

  return a.VectorCompose(f);
}

ADD Unreduced::fcrTransform(ADD a) const {
  Cudd *mgr = a.manager();
  const int nswaps = swaps_src.size();
  ADDvector src(nswaps, mgr);
  ADDvector dest(nswaps, mgr);

  for (int i = 0; i < nswaps; i++) {
    src[i]  = mgr->addVar(swaps_src[i]);
    dest[i] = mgr->addVar(swaps_dest[i]);
  }

  return frTransform(a).SwapVariables(src, dest);
}

void RecombAccumulator::print() const {
  for (const_iterator bit = begin(); bit != end(); bit++)
    cout << bit->first << "\t" << bit->second << endl;
}

void Sweeper::addFounderReduction(const vector<ReducedIndex> &flips,
                                  bool interesting, bool female) {
  assertinternal(!flips.empty());
  Unreduced fr(flips);
  if (female)
    fr.makeFemale();
  unreduced.insert(fr);
  if (!interesting)
    uninteresting.insert(fr);
}

void Sweeper::addFounderCoupleReduction(const vector<ReducedIndex> &flips,
                                        const vector<ReducedIndex> &src,
                                        const vector<ReducedIndex> &dest,
                                        bool interesting) {
  assertinternal(!src.empty());
  assertinternal(src.size() == dest.size());
  Unreduced fcr(flips, src, dest);
  unreduced.insert(fcr);
  if (!interesting)
    uninteresting.insert(fcr);
}

void Sweeper::firstMarker() {
  assertinternal(work_space.empty());

  Cudd new_mgr(nbits, 0, 256, 262144, options->maxmem*(1 << 20)/8);
  mgr = new_mgr;
  mgr.SetMinHit(1);
  mgr.SetEpsilon(.0);
  mgr.SetRoundingPrec(options->mtbddrounding);

  racc.reset();
  work_space.add(mgr.addOne(), "from");
  work_space.dontNeed("from");
}

void Sweeper::lastMarker() {
  work_space.erase("from");
}

/**
 * Finds the informativeness of normal and reduced bits
 * with respect to the to-tree \c to.
 * Normal bit \c i is informative if <tt>ret & 1 << i</tt>
 * where \c ret is the return value.
 * Founder reduction \c freds[i] is informative unless
 * <tt>freds[i] & 1</tt>; similarly for founder-couple reduction
 * \c creds[i].
 */
set<Unreduced> Sweeper::informativePass(ADD to,
                                        const set<Unreduced> &unreduced) {
  // Find informative regular bits
  set<Unreduced> informative;

  int *support = Cudd_SupportIndex(to.manager()->getManager(), to.getNode());
  const unsigned int nbits(to.manager()->ReadSize());
  for (ReducedIndex i = 0; i < nbits; i++)
    if (support[i]) {
      set<Unreduced>::const_iterator ui = unreduced.find(Unreduced(i));
      if (ui != unreduced.end())
        informative.insert(*ui);
    }
  free(support);
  assertinternal(informative.size() <= nbits);

  for (set<Unreduced>::const_iterator ui = unreduced.begin();
       ui != unreduced.end(); ui++)
    if (ui->type != Unreduced::REGULAR && ui->informative(to))
      informative.insert(*ui);

  for (set<Unreduced>::const_iterator ui = unreduced.begin();
       ui != unreduced.end(); ui++) {
    if (ui->type == Unreduced::FCR /*&& informative.count(*ui) > 0*/) {
      const Unreduced &fcr = *ui;

      // if either of a pair of swapped bits is informative, then both
      // must be considered as informative
      for (unsigned int i = 0; i < fcr.swaps_src.size(); i++) {
        const ReducedIndex s = fcr.swaps_src[i];
        const ReducedIndex d = fcr.swaps_dest[i];
        assertinternal(s != d);
        if (unreduced.count(Unreduced(s)) > 0 &&
            unreduced.count(Unreduced(d)) > 0 &&
            ( ((informative.count(Unreduced(s)) > 0) xor
             (informative.count(Unreduced(d)) > 0)))) {
          informative.insert(Unreduced(s));
          informative.insert(Unreduced(d));
        }
      }

      // same deal with swapped founder reduced bits
      vector<Unreduced> swapped_fr;
      for (set<Unreduced>::const_iterator vi = unreduced.begin();
           vi != unreduced.end(); vi++)
        if (vi->type == Unreduced::FR && fcr.swaps(*vi))
          swapped_fr.push_back(*vi);
//      assertinternal(swapped_fr.size() == 0 || swapped_fr.size() == 2);

      if (swapped_fr.size() == 2 &&
          (  ((informative.count(swapped_fr[0]) > 0) xor
             (informative.count(swapped_fr[1]) > 0)) )) {
        informative.insert(swapped_fr[0]);
        informative.insert(swapped_fr[1]);
      }
    }
  }

  return informative;
}

set<Unreduced> getInfluencing(const set<Unreduced> &x, ReducedIndex bit) {
  set<Unreduced> infl;
  for (set<Unreduced>::const_iterator i = x.begin(); i != x.end(); i++)
    if (i->influences(bit))
      infl.insert(*i);
  return infl;
}

// This print function is used in debugging, do not delete
void print(const set<Unreduced> &x) {
  for (set<Unreduced>::const_iterator i = x.begin(); i != x.end(); i++)
    cout << *i << endl;
}

bool Sweeper::trySwapping(ZOEffect &a, ZOEffect &b) {
  ADD zo = b.bit.expandZO(a.zo);
  SW_START("CountMinterms");
  const double minterms = countMinterm(zo);
  SW_STOP("CountMinterms");
  if (minterms - b.minterms < .5) { // swapping improves, and will be performed
    const Unreduced tmp(a.bit);
    a.bit = b.bit;
    b.bit = tmp;
    b.minterms = minterms;
    b.zo = zo;
    return true;
  } else
    return false;
}

bool isPossible(DdNode *x, DdManager *mgr, st_table *table, int lvl, bool T) {
  const int xl = cuddI(mgr, x->index);
  if (xl > lvl)
    return !cuddIsConstant(x) || cuddV(x) != .0;

  DdNode *res;
  if (st_lookup(table, x, &res))
    return false;

  if ( (((xl == lvl) && (T && isPossible(cuddT(x), mgr, table, lvl, T))) ||
                    (!T && isPossible(cuddE(x), mgr, table, lvl, T))) ||
      ((xl < lvl) && (isPossible(cuddT(x), mgr, table, lvl, T) ||
                   isPossible(cuddE(x), mgr, table, lvl, T))))
    return true;

  st_add_direct(table, (char *)x, (char *)x);
  return false;
}

bool isPossible(ADD &x, unsigned int lvl, bool T) {
  st_table *table = st_init_table(st_ptrcmp, st_ptrhash);

  const bool possible = isPossible(x.getNode(), x.manager()->getManager(),
                                   table, lvl, T);

  st_free_table(table);
  return possible;
}

bool isFixed(ADD &x, unsigned int lvl) {
  return !isPossible(x, lvl, true) || !isPossible(x, lvl, false);
}

void Sweeper::findHandlingOrderRand(ADD zo, vector<ZOEffect> &v) {
  if (v.size() == 1) return;

  vector<ZOEffect> order;
  ADD cur_zo(zo);
  const unsigned int nbits = zo.manager()->ReadSize();
  const double max_minterms = pow(2., double(nbits));
  SW_START("CountMinterms");
  const double min_minterms = countMinterm(zo);
  SW_STOP("CountMinterms");
  if (max_minterms == min_minterms) return;

  double last_minimum = min_minterms;
  unsigned int active_begin = 0; // marks beginning of bits with some
                                 // information

  SW_START("Sweeper::findHandlingOrderRand_init");
  while (!v.empty()) {
    vector<ZOEffect> cand;
    double minimum = 1e304;

    for (vector<ZOEffect>::iterator vi = v.begin(); vi != v.end();) {
      ADD zon = vi->bit.expandZO(cur_zo);
      SW_START("CountMinterms");
      const double zon_minterms = countMinterm(zon);
      SW_STOP("CountMinterms");
      if (fabs(zon_minterms - min_minterms) < .5) {
        // means bit is good for nothin
        order.push_back(*vi);
        order.back().zo = zo;
        order.back().minterms = min_minterms;
        active_begin++;
        vi = v.erase(vi);
      } else { // bit has some potential
        if (zon_minterms < minimum) {
          cand.clear();
          cand.push_back(*vi);
          minimum = zon_minterms;
        } else if (zon_minterms == minimum)
          cand.push_back(*vi);
        vi++;
      }
    }
    if (v.empty()) {
      v = order;
      SW_STOP("Sweeper::findHandlingOrderRand_init");
      return;
    }

    assertinternal(!cand.empty());
    ZOEffect next =
      cand[int(floor(erand48(options->seed)*double(cand.size())))];

    v.erase(find(v.begin(), v.end(), next));
    order.push_back(next);
    order.back().zo = cur_zo;
    order.back().minterms = last_minimum;

    last_minimum = minimum;
    cur_zo = next.bit.expandZO(cur_zo);
  }
  SW_STOP("Sweeper::findHandlingOrderRand_init");

  unsigned int num_steps_without_improvement = 0;
  unsigned int active_end = order.size(); // marks beginning of
                                          // fixed bits
  unsigned int idx = active_end;
  assertinternal(active_begin < active_end);
  while (active_begin + 1 < active_end &&
         num_steps_without_improvement < active_end - active_begin + 3) {
    // make sure idx is within active range
    if (idx < active_begin) idx = active_begin;
    else if (idx >= active_end) idx = active_end - 2;

    // try moving a bit to the right
    unsigned int cur_place = idx;
    bool improvement = false;
    while (cur_place + 1 < active_end) {
      const double old_minterms = order[cur_place + 1].minterms;
      if (trySwapping(order[cur_place], order[cur_place + 1])) {
        if (order[cur_place + 1].minterms - old_minterms < -.5)
          improvement = true;
        cur_place++;
      } else
        break;
    }

    if (improvement) num_steps_without_improvement = 0;
    else num_steps_without_improvement++;
    idx--;

    // Don't worry about bits that cannot be improved upon
    for (int i = active_end - 1;
         i >= int(active_begin) && i + 1 == int(active_end); i--)
      if (fabs(order[i].minterms - (i == int(order.size()) - 1 ? max_minterms :
                                    order[i + 1].minterms)/2.) < .5)
        active_end--;
  }

  v = order;
}

void Sweeper::print(const vector<ZOEffect> &effects) {
  for (unsigned int i = 0; i < effects.size(); i++)
    cout << effects[i].bit << "\t" << effects[i].minterms << endl;
}

void Sweeper::
findOptimalHandlingOrder(vector<Unreduced> &optimal_order, ADD zo,
                         const set<Unreduced> &targ_all) {
  if (targ_all.empty()) {
    optimal_order.clear();
    return;
  } else if (targ_all.size() == 1) {
    optimal_order.clear();
    optimal_order.push_back(*targ_all.begin());
    return;
  }
  set<Unreduced> targ(targ_all);
//   set<Unreduced> targ(informativePass(zo, targ_all));

  vector<ZOEffect> effects;
  for (set<Unreduced>::const_iterator ai = targ.begin(); ai != targ.end(); ai++)
    effects.push_back(ZOEffect(*ai));
  assertinternal(!effects.empty());

  vector<ZOEffect> best_order;
  for (unsigned int i = 0; i < 2; i++) {
    vector<ZOEffect> order_i(effects);
    SW_START("Sweeper::findHandlingOrderRand");
    findHandlingOrderRand(zo, order_i);
    SW_STOP("Sweeper::findHandlingOrderRand");

    bool improv = i == 0;
    for (int j = order_i.size() - 1; !improv && j >= 0; j--)
      if (order_i[j].minterms > best_order[j].minterms)
        improv = false;
      else if (order_i[j].minterms < best_order[j].minterms)
        improv = true;

    if (improv)
      best_order = order_i;
  }

  SW_START("optimalHandlingOrder_rest");
  vector<Unreduced> oo;
  for (unsigned int i = 0; i < best_order.size(); i++)
    oo.push_back(best_order[i].bit);

  // make sure FCR swaps are respected by order
  optimal_order.clear();
  for (vector<Unreduced>::iterator i = oo.begin(); i < oo.end(); i++)
    if (i->type == Unreduced::FCR) {
      vector<Unreduced>::const_iterator si =
        find(i, oo.end(), Unreduced(i->swaps_src));
      vector<Unreduced>::const_iterator di =
        find(i, oo.end(), Unreduced(i->swaps_dest));
      if (si == oo.end() && di != oo.end())
        optimal_order.push_back(*di);
      else if (si != oo.end() && di == oo.end())
        optimal_order.push_back(*si);

      for (unsigned int j = 0; j < i->swaps_src.size(); j++) {
        vector<Unreduced>::const_iterator si =
          find(i, oo.end(), Unreduced(i->swaps_src[j]));
        vector<Unreduced>::const_iterator di =
          find(i, oo.end(), Unreduced(i->swaps_dest[j]));
        if (si == oo.end() && di != oo.end())
          optimal_order.push_back(*di);
        else if (si != oo.end() && di == oo.end())
          optimal_order.push_back(*si);
      }

      optimal_order.push_back(*i);
    } else if (find(optimal_order.begin(), optimal_order.end(), *i) ==
               optimal_order.end())
      optimal_order.push_back(*i);
  SW_STOP("optimalHandlingOrder_rest");
}

void Sweeper::nextMarker(RecombAccumulator &ra, double theta_male,
                         double theta_female, Uint gam, bool viterbi,
                         bool from_left) {
#ifdef DEBUG_OUTPUT
  Cudd::printActiveManagers();
#endif // DEBUG_OUTPUT

  static int checkcount = 10;
  if (options->checkcondition > 0 &&
      (checkcount % options->checkcondition) == 0) {
    if (work_space.type("from") == BFunction::ADD_FUN) {
      ADD &from = work_space.getADD("from");
      from *= from.manager()->constant(1./sum(from));
    } else
      normal<double>(work_space.getVector("from"), IV(1) << nbits);
  }

  racc.add(theta_male, theta_female);

  const SPTStructure &spt = spt_structure[gam];

  // Bits that have not been informative so far don't need to be convolved
  const set<Unreduced> &uninformative_in_sweep =
    from_left ?
    (gam == 0 ? unreduced : spt_structure[gam - 1].uninformative_from_left) :
    (gam + 1 == spt_structure.size() ? unreduced :
     spt_structure[gam + 1].uninformative_from_right);
  for (set<Unreduced>::const_iterator uis = uninformative_in_sweep.begin();
       uis != uninformative_in_sweep.end(); uis++)
    racc[*uis] = .0;

  if (!viterbi && work_space.type("from") == BFunction::ADD_FUN) {
    // Uninteresting bits, that will never be informative again, may be
    // integrated out
    const set<Unreduced> &uninformative_in_future =
      from_left ? spt.uninformative_from_right : spt.uninformative_from_left;

    ADD &from_add = work_space.getADD("from");

    if (!uninformative_in_future.empty()) {
      int *support = work_space.support("from");
      for (set<Unreduced>::const_iterator ufi = uninformative_in_future.begin();
           ufi != uninformative_in_future.end(); ufi++)
        if (ufi->type == Unreduced::REGULAR && support[ufi->begin] &&
            uninteresting.count(*ufi) > 0) {
#ifdef DEBUG_OUTPUT
          cerr << "********* integrating out " << ufi->begin << endl;
#endif // DEBUG_OUTPUT
          ADD bv(mgr.addVar(ufi->begin));
          from_add = from_add.Cofactor(~bv) + from_add.Cofactor(bv);
        }
      free(support);
    }
  }

  if (!work_space.isConstant("from")) {
    set<Unreduced> unhandled;
    set_difference(spt.informative.begin(), spt.informative.end(),
                   uninformative_in_sweep.begin(),
                   uninformative_in_sweep.end(),
                   inserter(unhandled, unhandled.end()));
    if (!unhandled.empty()) {
      ADD to = addTransfer(spt.spt, mgr);
//      work_space.add(mgr.addOne(), "zo");
      work_space.add(to.OneZeroMaximum(mgr.addZero()), "zo");
      to = ADD();

      // If from is stored as an ADD reorder the manager
      if (work_space.type("from") == BFunction::ADD_FUN &&
              (mgr.ReadKeys() - mgr.ReadDead() <
               options->mtbdddynamicthreshold*(IV(1) << mgr.ReadSize()) ||
               3*((mgr.ReadKeys() - mgr.ReadDead()) >> 20) > 2*options->maxmem)) {
          ADD &from_add = work_space.getADD("from");
#ifdef DEBUG_OUTPUT
          const unsigned int num_nodes_before = Cudd_DagSize(from_add.getNode());
          const unsigned int num_leaves = Cudd_CountLeaves(from_add.getNode());
#endif // DEBUG_OUTPUT
          mgr.SetMaxGrowth(1.001);
          SW_START("nextMarker:ReduceHeap");
          mgr.ReduceHeap(CUDD_REORDER_SIFT, 0);
          SW_STOP("nextMarker:ReduceHeap");
          //        mgr.SetMaxGrowth(1.05);
          //        Cudd_ReduceHeap(mgr.getManager(), CUDD_REORDER_SIFT, 0);
#ifdef DEBUG_OUTPUT
          cerr << "from";
          from_add.print(nbits, 1);
          cerr << "#informative = " << unhandled.size() << endl;
          const unsigned int num_nodes_after = Cudd_DagSize(from_add.getNode());
          cerr << "reorder rep:\t" << num_nodes_before << "\t" << num_nodes_after
               << "\t" << num_leaves << endl;
#endif // DEBUG_OUTPUT
      }

      // Convolve from
      convolutionPass("from", "zo", unhandled, racc, viterbi);

      work_space.erase("zo");
    }
  } else
    racc.reset();

  assertinternal(!work_space.isZero("from"));

  work_space.dontNeed("from");
  ra = racc;
}

void Sweeper::updateFrom(ADD &spt) {
  SW_START("update_from");
  ADD to(addTransfer(spt, mgr));
  to.manager()->SetRoundingPrec(options->mtbddrounding + 30);
  ADD rep_to_max = to.manager()->constant(1./cuddV(to.FindMax().getNode()));
  to.manager()->SetRoundingPrec(options->mtbddrounding);
  to = to*rep_to_max;
  work_space.inplaceMult("from", to);
  work_space.dontNeed("from");
  SW_STOP("update_from");
}

ADD Sweeper::expandZO(ADD &zo) const {
  ADD res = zo.manager()->addZero();
  for (set<Unreduced>::const_iterator ui = unreduced.begin();
       ui != unreduced.end(); ui++)
    res |= ui->expandZO(zo);
  return res;
}

double Sweeper::
skipCompleteUninformative(const string &zo, const string &left,
                          RecombAccumulator ralt,
                          ADD &sp, const string &right,
                          RecombAccumulator rart,
                          const set<Unreduced> &unhandled) {
  work_space.copy("left_tmp", left);
  work_space.copy("right_tmp", right);
//   work_space.swapToFile(left);
//   work_space.swapToFile(right);
  work_space.swapToFile("from");
  work_space.add(work_space.manager(left).addOne(), "zo_tmp");
  double full_nc = handleUninteresting("zo_tmp", "left_tmp", ralt, "right_tmp",
                                       rart, unhandled);
  work_space.erase("zo_tmp");
  const string tlqr_name = completeLQR("left_tmp", sp, "right_tmp");
  ADD one(work_space.manager(tlqr_name).addOne());
  ADD tlqr = work_space.asADD(tlqr_name, one);
  one = ADD();
  work_space.erase(tlqr_name);
//   zo_approx = tlqr.OneZeroMaximum(
//     tlqr.manager()->constant(cuddV(tlqr.FindMax().getNode())*10e-13));

  double sum_tlqr = sum(tlqr);
  full_nc *= sum_tlqr;

  tlqr.manager()->SetRoundingPrec(100);
  for (set<Unreduced>::const_iterator ui = unhandled.begin();
       ui != unhandled.end(); ui++)
    if (ui->type == Unreduced::REGULAR) {
      ADD bit(tlqr.manager()->addVar(ui->begin));
      tlqr = tlqr.Cofactor(bit) + tlqr.Cofactor(~bit);
      sum_tlqr *= 2.;
    }

  vector<ReducedIndex> handled;
  for (unsigned int b = 0; b < nbits; b++)
    if (unhandled.count(Unreduced(b)) == 0)
      handled.push_back(b);

  for (set<Unreduced>::const_iterator ui = unhandled.begin();
       ui != unhandled.end(); ui++)
    if (ui->type != Unreduced::REGULAR && ui->influences(handled)) {
      const double theta = addrec(ralt[*ui], rart[*ui]);
      ADD tmp = ui->transform(tlqr);
      tmp *= tlqr.manager()->constant(theta/(1. - theta));
      tlqr += tmp;
      sum_tlqr /= 1. - theta;
    }

  double threshold = cuddV(tlqr.FindMax().getNode())/16.;
  while (sum(tlqr.Threshold(tlqr.manager()->constant(threshold))) <
         (1 - 2e-5)*sum_tlqr)
    threshold /= 2.;

  ADD &zo_add = work_space.getADD(zo);
  zo_add *=
    addTransfer(tlqr.OneZeroMaximum(tlqr.manager()->constant(threshold)),
                *zo_add.manager());

  return full_nc;
}

template<class T>
class OrderBySecond {
public:
  bool operator()(const T &a, const T &b) {return a.second < b.second;}
};

set<Unreduced> Sweeper::findUninterestingUninformative(Uint gam, bool right,
                                                       ADD &side) {
  set<Unreduced> *uninformative = 0;
  if (right) {
    if (gam + 1 == spt_structure.size())
      uninformative = &unreduced;
    else
      uninformative = &spt_structure[gam + 1].uninformative_from_right;
  } else {
    if (gam == 0)
      uninformative = &unreduced;
    else
      uninformative = &spt_structure[gam - 1].uninformative_from_left;
  }
  assertinternal(uninformative != 0);

  set<Unreduced> res;
  set_intersection(uninteresting.begin(), uninteresting.end(),
                   uninformative->begin(), uninformative->end(),
                   inserter(res, res.end()));

  if (!res.empty()) {
    set<Unreduced> rs;
    int *support = Cudd_SupportIndex(side.manager()->getManager(),
                                     side.getNode());
    for (set<Unreduced>::const_iterator ri = res.begin(); ri != res.end(); ri++)
      if (ri->type == Unreduced::REGULAR && support[ri->begin])
        rs.insert(*ri);
    free(support);

    return rs;
  } else
    return res;
}

void Sweeper::
integrateOutUninterestingUninformative(ADD &side, ADD &sp, ADD &zo,
                                       const set<Unreduced> &unint_uninf) {
  side *= addTransfer(sp, *side.manager());
  for (set<Unreduced>::const_iterator i = unint_uninf.begin();
       i != unint_uninf.end(); i++) {
    assertinternal(i->type == Unreduced::REGULAR);
#ifdef DEBUG_OUTPUT
    cerr << "========= integrating out " << i->begin << endl;
#endif // DEBUG_OUTPUT
    ADD bv(side.manager()->addVar(i->begin));
    side = side.Cofactor(~bv) + side.Cofactor(bv);
    zo = i->expandZO(zo);
  }
}

ADD Sweeper::completeStep(const string &left_file, bool left_is_ADD,
                          const RecombAccumulator &ra_left, Uint gam,
                          const RecombAccumulator &ra_right, Cudd &comp_mgr) {
  ADD sp = spt_structure[gam].spt;
  ADD sp_zo(sp.OneZeroMaximum(sp.manager()->addZero()));
  work_space.add(sp_zo, "zo");

  // Handling of uninteresting bits
  SW_START("uninteresting");
  // handle uninteresting bits that may be integrated out immediately
  if (left_file.substr(left_file.length() - 2) == ".0")
    work_space.add(comp_mgr.addOne(), "left");
  else
    work_space.add(left_file, comp_mgr, left_is_ADD, "left");

  set<Unreduced> left_unint_uninf;
  if (work_space.type("left") == BFunction::ADD_FUN)
    left_unint_uninf =
      findUninterestingUninformative(gam, true, work_space.getADD("left"));
  work_space.dontNeed("left");

  work_space.copy("right", "from");
  set<Unreduced> right_unint_uninf;
  if (work_space.type("right") == BFunction::ADD_FUN)
    right_unint_uninf =
      findUninterestingUninformative(gam, false, work_space.getADD("right"));
  work_space.dontNeed("right");
  if (!left_unint_uninf.empty() || !right_unint_uninf.empty()) {
    if (left_unint_uninf.size() > right_unint_uninf.size()) {
      assertinternal(work_space.type("left") == BFunction::ADD_FUN);
      integrateOutUninterestingUninformative(work_space.getADD("left"), sp,
                                             work_space.getADD("zo"),
                                             left_unint_uninf);
      work_space.dontNeed("left");
    } else {
      assertinternal(work_space.type("right") == BFunction::ADD_FUN);
      integrateOutUninterestingUninformative(work_space.getADD("right"), sp,
                                             work_space.getADD("zo"),
                                             right_unint_uninf);
      work_space.dontNeed("right");
    }

    sp = sp_zo;
//    work_space.dontNeed("zo");
  }

  // handle remaining uninteresting bits
  handleUninteresting("zo", "left", ra_left, "right", ra_right, uninteresting);
  SW_STOP("uninteresting");

  // Handling of interesting bits
  RecombAccumulator ral(ra_left);
  ral.doBits(uninteresting);
  RecombAccumulator rar(ra_right);
  rar.doBits(uninteresting);
  SW_START("completeInteresting");

  ADD res = completeInteresting("zo", sp, "left", ral, "right", rar,
                                *spt_structure[gam].spt.manager());
  SW_STOP("completeInteresting");

  assertinternal(!work_space.isStored("right"));

  return res;
}

void Sweeper::buildBitInfo(vector<pair<Unreduced, double> > &bi,
                           const set<Unreduced> &unhandled,
                           ADD &left, RecombAccumulator &ral,
                           ADD &right, RecombAccumulator &rar) {
  for (set<Unreduced>::const_iterator ui = unhandled.begin();
       ui != unhandled.end(); ui++)
    if (ui->type == Unreduced::REGULAR) {
      ADD bl(left.manager()->addVar(ui->begin));
      const double lt = .5*sum(left.Cofactor(bl));
      const double lp = lt/sum(left);
      ADD br(right.manager()->addVar(ui->begin));
      const double rt = .5*sum(right.Cofactor(br));
      const double rp = rt/sum(right);

      const double ll = addrec(lp, ral[*ui]);
      const double rr = addrec(rp, rar[*ui]);

      const double p = ll*rr/(1 - addrec(ll, rr));

#ifdef DEBUG_OUTPUT
      cout << *ui << "\t" << ral[*ui] << "\t" << rar[*ui] << "\t"
           << lp << "\t" << rp << "\t" << p << endl;
#endif // DEBUG_OUTPUT

      bi.push_back(make_pair(*ui, min(p, 1. - p)));
    }
  OrderBySecond<pair<Unreduced, double> > obs;
  sort(bi.begin(), bi.end(), obs);
}

inline DdNode *crudeRoundSmall(DdNode *x, DdManager *mgr, st_table *table,
                               double thresh, int prec) {
  if (cuddIsConstant(x)) {
    const double val = cuddV(x);
    if (val == .0 || val == 1. || val > thresh) return x;
    else {
      double rounded_val;
      if (!finite(val)) rounded_val = val;
      else {
        const int ilb = ilogb(val) - prec;
/*    return scalbn(round(scalbn(x, -ilb)), ilb);*/
        rounded_val = scalbn(rint(scalbn(val, -ilb)), ilb);
      }
      return cuddUniqueConst(mgr, rounded_val);
    }
  }

  const bool use_cache = mgr->size > cuddI(mgr, x->index) + mgr->size/4;
  DdNode *res;
  if (use_cache && st_lookup(table, x, &res))
    return res;

  DdNode *rt = crudeRoundSmall(cuddT(x), mgr, table, thresh, prec);
  cuddRef(rt);
  DdNode *re = crudeRoundSmall(cuddE(x), mgr, table, thresh, prec);
  cuddRef(re);

  if (rt == cuddT(x) && re == cuddE(x))
    res = x;
  else
    res = rt == re ? rt : cuddUniqueInter(mgr, x->index, rt, re);
  cuddDeref(rt);
  cuddDeref(re);

  if (use_cache)
    st_add_direct(table, (char *)x, (char *)(res));

  return res;
}

void crudeRoundSmall(ADD &x, double thresh, int prec) {
  DdManager *man = x.manager()->getManager();
  st_table *table = st_init_table(st_ptrcmp, st_ptrhash);

  DdNode *res = crudeRoundSmall(x.getNode(), man, table, thresh, prec);

  x = ADD(x.manager(), res);
}


ADD Sweeper::completeInteresting(const string &zo, ADD &sp,
                                 const string &left, RecombAccumulator &ral,
                                 const string &right, RecombAccumulator &rar,
                                 Cudd &result_mgr) {
  SW_START("uninformative");
  set<Unreduced> unhandled;
  for (set<Unreduced>::const_iterator bit = unreduced.begin();
       bit != unreduced.end(); bit++)
    if (ral[*bit] != .0 || rar[*bit] != .0)
      unhandled.insert(*bit);

//  const double lqr_thresh = 1e-5*pow(.5, double(nbits));
  const double approx_threshold = 1e5;
  if (options->mtbddapproximatecompletion &&
      work_space.type(left) == BFunction::ADD_FUN &&
      work_space.type(right) == BFunction::ADD_FUN && unhandled.size() > 4 &&
      countMinterm(work_space.getADD(zo)) > approx_threshold) {
#ifdef DEBUG_OUTPUT
    cout << "zo = " << countMinterm(work_space.getADD(zo)) << endl;
#endif // DEBUG_OUTPUT
    // complete approximately
    vector<pair<Unreduced, double> > bi;
    while (!unhandled.empty()) {
      const bool approximate = (unhandled.size() > 3 &&
                                work_space.type(left) == BFunction::ADD_FUN &&
                                work_space.type(right) == BFunction::ADD_FUN);
      if (approximate) {
        skipCompleteUninformative(zo, left, ral, sp, right, rar, unhandled);

#ifdef DEBUG_OUTPUT
        cout << "zo = " << countMinterm(work_space.getADD(zo)) << endl;
#endif // DEBUG_OUTPUT
      }

      set<Unreduced> uh;
      if (approximate &&
          countMinterm(work_space.getADD(zo)) > approx_threshold) {
        set<Unreduced> v(unhandled);
        for (set<Unreduced>::const_iterator ui = v.begin(); ui != v.end(); ui++)
          if (ui->type != Unreduced::REGULAR) {
            uh.insert(*ui);
            unhandled.erase(*ui);
          }
        if (uh.empty()) {
          if (bi.empty()) {
            buildBitInfo(bi, unhandled, work_space.getADD(left), ral,
                         work_space.getADD(right), rar);
            work_space.dontNeed(left);
            work_space.dontNeed(right);
          } else
            assertinternal(bi.size() == unhandled.size());

          // do the most informative bits first
          const unsigned int n = 4;
          for (unsigned int i = 0; i < n && !bi.empty(); i++) {
            uh.insert(bi.front().first);
            unhandled.erase(bi.front().first);
            bi.erase(bi.begin());
          }
        }
      } else {
        uh = unhandled;
        unhandled.clear();
      }

      completeUninformativeSide(left, zo, uh, ral);
      completeUninformativeSide(right, zo, uh, rar);
    }

  } else {
    // complete exactly
    completeUninformativeSide(left, zo, unhandled, ral);
    completeUninformativeSide(right, zo, unhandled, rar);
  }
  SW_STOP("uninformative");

#ifdef DEBUG_OUTPUT
  Cudd::printActiveManagers();
  cout << "Memory:\t" << memoryUse() << endl;
#endif // DEBUG_OUTPUT

  SW_START("completeLQR");
  const string lqr(completeLQR(left, sp, right));
  SW_STOP("completeLQR");

#ifdef DEBUG_OUTPUT
  Cudd::printActiveManagers();
  cout << "Memory:\t" << memoryUse() << endl;
#endif // DEBUG_OUTPUT

//   if (work_space.type(lqr) == BFunction::ADD_FUN) {
//     SW_START("thresh");
//     ADD &lqr_add = work_space.getADD(lqr);
// //    if (true || options->mtbddapproximatecompletion && countMinterm(lqr_add) > 1e5) {
//     ADD mx = lqr_add.FindMax();
//     double threshold = cuddV(mx.getNode())*lqr_thresh;
//     const double sum_lqr_add = sum(lqr_add);
//     ADD thr_lqr_add = lqr_add.Threshold(lqr_add.manager()->constant(threshold));
//     while (sum(thr_lqr_add) > (1 - 2e-5)*sum_lqr_add) {
//       lqr_add = thr_lqr_add;
//       threshold *= 4.;
//       thr_lqr_add = lqr_add.Threshold(lqr_add.manager()->constant(threshold));
//     }
//     lqr_add = thr_lqr_add;
//   }
//   SW_STOP("thresh");
//   }
// //    lqr = lqr.Threshold(lqr.manager()->constant(threshold));
// //     double threshold = cuddV(mx.getNode())/16.;
// //     const double sum_lqr = sum(lqr);
// //     while (sum(lqr.Threshold(lqr.manager()->constant(threshold))) <
// //            (1 - 2e-5)*sum_lqr)
// //       threshold /= 2.;

// //     lqr = lqr.Threshold(lqr.manager()->constant(threshold));
//   } else
//     lqr = lqr.Threshold(lqr.manager()->constant(lqr_thresh)*mx);

  if (work_space.type(lqr) == BFunction::ADD_FUN) {
    SW_START("trim");
    ADD &lqr_add = work_space.getADD(lqr);

    ADD mx = lqr_add.FindMax();

    crudeRoundSmall(lqr_add, cuddV(mx.getNode())*1e-6, 1);
    SW_STOP("trim");
  }

  work_space.integrateOut(lqr, uninteresting);

  if (work_space.type(lqr) == BFunction::ADD_FUN) {
    SW_START("trim");
    ADD &lqr_add = work_space.getADD(lqr);

    ADD mx = lqr_add.FindMax();

    crudeRoundSmall(lqr_add, cuddV(mx.getNode())*1e-6, 1);
    SW_STOP("trim");
  }

  mgr.SetMaxGrowth(1.01);
  work_space.manager(lqr).ReduceHeap(CUDD_REORDER_SIFT, 0);
  result_mgr.ShuffleHeap(work_space.manager(lqr).getManager()->invperm);

  ADD p;
  if (work_space.type(lqr) == BFunction::ADD_FUN) {
    SW_START("transfer_p");
    p = addTransfer(work_space.getADD(lqr), result_mgr);
    SW_STOP("transfer_p");
  } else {
    work_space.integrateOut(zo, uninteresting);
    ADD &zo_add = work_space.getADD(zo);
    zo_add = zo_add.OneZeroMaximum(zo_add.manager()->addZero());

    SW_START("transfer_p");
    p = addTransfer(work_space.asADD(lqr, work_space.getADD(zo)), result_mgr);
//  ADD p = addTransfer(integrateOut(lqr, uninteresting), result_mgr);
    SW_STOP("transfer_p");
  }

//  Cudd lqr_manager(work_space.manager(lqr));

  work_space.erase(zo);
  work_space.erase(lqr);

//  cuddGarbageCollect(lqr_manager.getManager(), 1);

#ifdef DEBUG_OUTPUT
  int *p_support = Cudd_SupportIndex(p.manager()->getManager(), p.getNode());
  for (set<Unreduced>::const_iterator u = uninteresting.begin();
       u != uninteresting.end(); u++)
    if (u->type == Unreduced::REGULAR)
      assertinternal(!p_support[u->begin]);
  free(p_support);
#endif // DEBUG_OUTPUT

//   if (lqr.manager()->getManager() != left.manager()->getManager() && todo
//       5*lqr.manager()->ReadMemoryInUse() > options->maxmem)
//     cuddGarbageCollect(lqr.manager()->getManager(), 1);

  return p;
}

template<typename L, typename R>
void getThetas(double &theta, double &theta_female,
               Uint lm, Uint rm, const L &lpos, const R &rpos) {
  theta = theta_female = .0;
  if (lm != Uint(FamilyMap::NOLEFTMARKER) &&
      rm != Uint(FamilyMap::NORIGHTMARKER)) {
    theta = recombfraccent(rpos[rm].positionMale() - lpos[lm].positionMale());
    theta_female = recombfraccent(rpos[rm].positionFemale() -
                                  lpos[lm].positionFemale());
  }
}

void Sweeper::completeUninformative(Uint &pos, const FamilyMap &fm,
                                    const string &left, bool left_is_ADD,
                                    const RecombAccumulator &la, ADD &sp,
                                    Map *map, Cudd &result_mgr) {
  if (left.substr(left.length() - 2) == ".0")
    work_space.add(result_mgr.addOne(), "left");
  else
    work_space.add(left, result_mgr, left_is_ADD, "left");
  work_space.inplaceMult("left", sp);
  work_space.add(result_mgr.addOne(), "zo");
  ADD s(sp.manager()->addOne());
  work_space.dontNeed("zo");

  const int lm = fm.leftmarker[pos];
  const int rm = fm.rightmarker[pos];
  assertinternal(lm != rm);

  double theta, theta_female;
  getThetas(theta, theta_female, lm, rm, map->loci, map->loci);

  RecombAccumulator ral(la), rar(racc);
  ral.add(theta, theta_female);

  // swap from to file
  work_space.copy("right", "from");

  // handle uninteresting bits
  handleUninteresting("zo", "left", ral, "right", rar, uninteresting);

  Uint first_p = pos;
  string left_file("");
  for (Uint p = 0; p <= pos; p++)
    if ((map->positions[p].inbetween ||
         !fm.informative[map->positions[p].leftmarker]) &&
        fm.leftmarker[p] == lm) {
      assertinternal(fm.rightmarker[p] == rm);

      if (p < pos) first_p = p;

      double left_theta, left_theta_female, right_theta, right_theta_female;
      getThetas(left_theta, left_theta_female, lm, p, map->loci,
                map->positions);
      getThetas(right_theta, right_theta_female, p, rm, map->positions,
                map->loci);

      RecombAccumulator ral_p(la), rar_p(racc);
      ral_p.add(left_theta, left_theta_female);
      rar_p.add(right_theta, right_theta_female);

      ral_p.doBits(uninteresting);
      rar_p.doBits(uninteresting);

      string l, z, r;
      if (p == pos) {
        l = "left";
        z = "zo";
        r = "right";
      } else {
        work_space.copy("left_p", "left");
        work_space.copy("zo_p", "zo");
        work_space.copy("right_p", "right");

        l = "left_p";
        z = "zo_p";
        r = "right_p";
      }

      ADD pd = completeInteresting(z, s, l, ral_p, r, rar_p, result_mgr);

      SW_START("Distribution::set_mpt");
      Distribution::set(pd, p, "mpt");
      SW_STOP("Distribution::set_mpt");
    }

  assertinternal(!work_space.isStored("left"));
  assertinternal(!work_space.isStored("zo"));
  assertinternal(!work_space.isStored("right"));

  pos = first_p;
}

set<Unreduced> Sweeper::findLegalStepSubset(set<Unreduced> &unhandled,
                                            double minterm) {
  set<Unreduced> uh;
  const double approx_threshold = 1e6;
  if (minterm < approx_threshold) {
    uh = unhandled;
    unhandled.clear();
  } else {
    // handle founder couple reductions firs to make sure that
    // swapped bits are handled on the same side of the founder
    // couple reduction
    for (set<Unreduced>::iterator ui = unhandled.begin();
         ui != unhandled.end(); )
      if (ui->type == Unreduced::FCR) {
        uh.insert(*ui);
        unhandled.erase(ui);
        ui = unhandled.begin();
      } else
        ui++;

    for (unsigned int i = 0; uh.size() < 6 && !unhandled.empty(); i++) {
      uh.insert(*unhandled.begin());
      unhandled.erase(unhandled.begin());
    }

    // pop bits that are swapped by a founder couple reduction in uh
    for (set<Unreduced>::iterator ui = uh.begin(); ui != uh.end(); ui++)
      if (ui->type == Unreduced::FCR)
        for (unsigned i = 0; i < ui->swaps_src.size(); i++)
          if ( ((uh.count(Unreduced(ui->swaps_src[i])) > 0) xor
               (uh.count(Unreduced(ui->swaps_dest[i])) > 0))) {
            uh.erase(Unreduced(ui->swaps_src[i]));
            uh.erase(Unreduced(ui->swaps_dest[i]));
          }
  }
  return uh;
}

void Sweeper::completeUninformativeSide(const string &side,
                                        const string &zo,
                                        const set<Unreduced> &unhandled,
                                        RecombAccumulator &sra) {
  if (!sra.done()) {
    Cudd &m = work_space.manager(side);
    work_space.add(addTransfer(work_space.getADD(zo), m),"zo_side");
    work_space.dontNeed(zo);
    convolutionPass(side, "zo_side", unhandled, sra, false);
    work_space.erase("zo_side");
//     if (20*m.ReadMemoryInUse() > options->maxmem)
//       cuddGarbageCollect(m.getManager(), 1);
  }
}

string Sweeper::completeLQR(const string &l, ADD &s, const string &r) {
  const bool left_is_ADD = work_space.type(l) == BFunction::ADD_FUN;
  const bool right_is_ADD = work_space.type(r) == BFunction::ADD_FUN;

  Cudd &lm = work_space.manager(l);
  Cudd &rm = work_space.manager(r);

  const bool reorder_right =
    (!right_is_ADD && (!left_is_ADD || work_space.getADD(l).nodeCount() <
                      (IV(1) << nbits)*options->mtbdddynamicthreshold)) ||
    (left_is_ADD && (right_is_ADD &&
    ((work_space.getADD(l).nodeCount()) > (work_space.getADD(r).nodeCount()))));

  if (reorder_right) {
    work_space.inplaceMult(r, s);
    const bool short_on_memory = (work_space.manager(l).ReadMemoryInUse() +
                                  2*work_space.manager(r).ReadMemoryInUse() >
                                  2*options->maxmem/3);
    if (short_on_memory || !right_is_ADD)
      work_space.shuffle(r, work_space.getInvperm(l));
    else
      work_space.transferADD(r, l);
  } else {
    work_space.inplaceMult(l, s);
    const bool short_on_memory = (work_space.manager(r).ReadMemoryInUse() +
                                  2*work_space.manager(l).ReadMemoryInUse() >
                                  2*options->maxmem/3);
    if (short_on_memory || !left_is_ADD)
      work_space.shuffle(l, work_space.getInvperm(r));
    else
      work_space.transferADD(l, r);
  }

//  work_space.makeSpace(8*3*((IV(1) << nbits) >> 20), options->maxmem);

  SW_START("lqr");
//  ADD lqr;
  string lqr;
  if (!right_is_ADD) {
    work_space.inplaceMult(r, l);
    work_space.erase(l);
    lqr = r;
//    work_space.erase(r);
  } else {
    work_space.inplaceMult(l, r);
    work_space.erase(r);
    lqr = l;
//    work_space.erase(l);
  }
  SW_STOP("lqr");

  if (work_space.manager(lqr).getManager() == lm.getManager())
    cuddGarbageCollect(rm.getManager(), 1);
  else
    cuddGarbageCollect(lm.getManager(), 1);

//   assertinternal(cuddV(lqr.FindMin().getNode()) >= .0);

  return lqr;
}

ADD Sweeper::splitUninterestingConvolutions(ADD zo_left,
                                            RecombAccumulator &ra_ul,
                                            unsigned int num_left_nodes,
                                            ADD zo_right,
                                            RecombAccumulator &ra_ur,
                                            unsigned int num_right_nodes) {
  set<Unreduced> bits;
  for (RecombAccumulator::const_iterator i = ra_ul.begin(); i != ra_ul.end();
       i++)
    if (i->second != .0 && ra_ur[i->first] != .0)
      bits.insert(i->first);

  set<Unreduced> informative_left(informativePass(zo_left, bits));
  set<Unreduced> informative_right(informativePass(zo_right, bits));

  // bits that are only informative for left should be convolved from right
  ADD zr(zo_right);
  set<Unreduced> informative_left_only;
  std::set_difference(informative_left.begin(), informative_left.end(),
                      informative_right.begin(), informative_right.end(),
                      inserter(informative_left_only,
                               informative_left_only.end()));
  for (set<Unreduced>::const_iterator i = informative_left_only.begin();
       i != informative_left_only.end(); i++) {
    ra_ul[*i] = .0;
    zr = i->expandZO(zr);
    num_right_nodes *= 2;
  }

  // bits that are only informative for right should be convolved from left
  ADD zl(zo_left);
  set<Unreduced> informative_right_only;
  set_difference(informative_right.begin(), informative_right.end(),
                 informative_left.begin(), informative_left.end(),
                 inserter(informative_right_only,
                          informative_right_only.end()));
  for (set<Unreduced>::const_iterator i = informative_right_only.begin();
       i != informative_right_only.end(); i++) {
    ra_ur[*i] = .0;
    i->expandZO(zl);
    num_left_nodes *= 2;
  }

  // bits that are informative for both should be split so that final
  // result is as small as possible
  set<Unreduced> informative_both;
  set_intersection(informative_left.begin(), informative_left.end(),
                   informative_right.begin(), informative_right.end(),
                   inserter(informative_both, informative_both.end()));
  double min_diff = 1.99;
  while (!informative_both.empty()) {
    set<Unreduced> not_split;
    for (set<Unreduced>::const_iterator i = informative_both.begin();
         i != informative_both.end(); i++) {
      ADD zl_tmp = i->expandZO(zl);
      ADD zr_tmp = i->expandZO(zr);
      const double mtl = countMinterm(zl_tmp);
      const double mtr = countMinterm(zr_tmp);
      const double d1 = countMinterm(zl)/mtl;
      const double d2 = countMinterm(zr)/mtr;
      const double r = d1/d2;
      if ( ((r > min_diff) && (fabs(r - 1) > .001)) || (min_diff > 1.) ||
                           ((min_diff < 1.) && (mtl > mtr))) {
        ra_ur[*i] = .0;
        zl = zl_tmp;
        num_left_nodes *= 2;
      } else if (r < 1./min_diff) {
        ra_ul[*i] = .0;
        zr = zr_tmp;
        num_right_nodes *= 2;
      } else
        not_split.insert(*i);
    }
    informative_both = not_split;

    min_diff = 1. + (min_diff - 1.)/2.;
    if (min_diff < 1.1) min_diff = .99;
  }

  // bits that are informative for neither should be split to make
  // tree growth more symmetric
  set<Unreduced> informative;
  set_union(informative_left.begin(), informative_left.end(),
            informative_right.begin(), informative_right.end(),
            inserter(informative, informative.end()));
  set<Unreduced> uninformative;
  set_difference(bits.begin(), bits.end(),
                 informative.begin(), informative.end(),
                 inserter(uninformative, uninformative.end()));
  for (set<Unreduced>::const_iterator i = uninformative.begin();
       i != uninformative.end(); i++)
    if (num_left_nodes < num_right_nodes) {
      ra_ur[*i] = .0;
      num_left_nodes *= 2;
    } else {
      ra_ul[*i] = .0;
      num_right_nodes *= 2;
    }

  return zl*addTransfer(zr, *zl.manager());
}

double Sweeper::
handleUninteresting(const string &zo, const string &left,
                    const RecombAccumulator &ra_left, const string &right,
                    const RecombAccumulator &ra_right,
                    const set<Unreduced> &unint) {
  // uninteresting bits can bits may be stepped over and, later,
  // integrated out
  RecombAccumulator sum_racc(ra_left + ra_right);
  RecombAccumulator uninteresting_racc(sum_racc, unint);

  set<Unreduced> unhandled_interesting;
  for (RecombAccumulator::const_iterator si = sum_racc.begin();
       si != sum_racc.end(); si++)
    if (si->second != .0 && uninteresting_racc[si->first] == .0)
      unhandled_interesting.insert(si->first);

#ifdef DEBUG_OUTPUT
  cerr << "unint rep\t" << uninteresting_racc.numLeft() << "\t"
       << ra_left.numLeft() << "\t" << ra_right.numLeft() << endl;
#endif // DEBUG_OUTPUT

  double tf = 1;
  if (uninteresting_racc.done())
    return tf;

  const bool left_is_ADD = work_space.type(left) == BFunction::ADD_FUN;
  const bool right_is_ADD = work_space.type(right) == BFunction::ADD_FUN;

  if (left_is_ADD || right_is_ADD) {
    // nothing has to be done for bits that are uninformative for left
    // or right

    int *left_support = work_space.support(left);
    int *right_support = work_space.support(right);

    for (RecombAccumulator::iterator bit = uninteresting_racc.begin();
         bit != uninteresting_racc.end(); bit++)
      if (bit->second != .0 &&
          (((bit->first.type == Unreduced::REGULAR) &&
           (!left_support[bit->first.begin] ||
            !right_support[bit->first.begin])) ||
           ((bit->first.type != Unreduced::REGULAR) &&
           ( (left_is_ADD && !bit->first.informative(work_space.getADD(left))) ||
             (right_is_ADD && !bit->first.informative(work_space.getADD(right)))))))
        bit->second = .0;

    free(left_support);
    free(right_support);
    tf = uninteresting_racc.resipProduct();

    // uninteresting bits only need to be convolved from left or right
    unsigned int left_node_count, right_node_count;
    ADD zo_left, zo_right;

    if (left_is_ADD) {
      ADD left_add = work_space.getADD(left);
      zo_left = left_add.OneZeroMaximum(left_add.manager()->addZero());
      for (set<Unreduced>::const_iterator ui = unhandled_interesting.begin();
           ui != unhandled_interesting.end(); ui++)
        zo_left = ui->expandZO(zo_left);

      left_node_count = left_add.nodeCount();
    }
    work_space.dontNeed(left);

    if (right_is_ADD) {
      ADD right_add = work_space.getADD(right);
      zo_right = right_add.OneZeroMaximum(right_add.manager()->addZero());
      for (set<Unreduced>::const_iterator ui = unhandled_interesting.begin();
           ui != unhandled_interesting.end(); ui++)
        zo_right = ui->expandZO(zo_right);

      right_node_count = right_add.nodeCount();
    }
    work_space.dontNeed(right);

    if (left_is_ADD && right_is_ADD) {
      // bits that remain and are interesting should expand zo
      RecombAccumulator ra_ul(uninteresting_racc);
      RecombAccumulator ra_ur(uninteresting_racc);
      work_space.setADD(zo, splitUninterestingConvolutions(zo_left, ra_ul,
                                                           left_node_count,
                                                           zo_right, ra_ur,
                                                           right_node_count));
      zo_left = zo_right = ADD();
      assertinternal(ra_ul + ra_ur == uninteresting_racc);

      // convolve uninteresting uninformative bits
      handleUninterestingSide(left, zo, ra_ul);
      handleUninterestingSide(right, zo, ra_ur);
    } else if (left_is_ADD) {
      work_space.setADD(zo, zo_left);
      handleUninterestingSide(right, zo, uninteresting_racc);
    } else {
      assertinternal(right_is_ADD);
      work_space.setADD(zo, zo_right);
      handleUninterestingSide(left, zo, uninteresting_racc);
    }
  } else
    handleUninterestingSide(left, zo, uninteresting_racc);

  work_space.dontNeed(left);
  work_space.dontNeed(right);
  work_space.dontNeed(zo);

  return tf;
}

void Sweeper::handleUninterestingSide(const string &from_side, const string &zo,
                                      RecombAccumulator &ra) {
  set<Unreduced> unhandled;
  for (RecombAccumulator::iterator bit = ra.begin(); bit != ra.end(); bit++)
    if (bit->second > .0)
      unhandled.insert(bit->first);

  // actual convolution
  work_space.add(addTransfer(work_space.getADD(zo),
                             work_space.manager(from_side)), "tmp_zo");
  work_space.dontNeed(zo);
  convolutionPass(from_side, "tmp_zo", unhandled, ra, false);
  work_space.erase("tmp_zo");
}

void Sweeper::convolutionPass(const string &res_name, const string &zo_name,
                              const set<Unreduced> &targ_all,
                              RecombAccumulator &ra, bool viterbi) {
  vector<ConvolutionStep *> cs;
  Cudd &res_mgr = work_space.manager(res_name);
  if (work_space.type(res_name) == BFunction::ADD_FUN) {
    SW_START("Sweeper::convolutionPass");

    // extract from targ those bits that have non-zero recombination fraction
    set<Unreduced> targ;
    for (set<Unreduced>::const_iterator ti = targ_all.begin();
         ti != targ_all.end(); ti++)
      if (ra[*ti] > .0)
        targ.insert(*ti);

    res_mgr.SetRoundingPrec(options->mtbddrounding + 5 + targ.size()/2);

  // find optimal order of convolution
    vector<Unreduced> optimal_order;
    SW_START("Sweeper::findOptimalHandlingOrder");
    findOptimalHandlingOrder(optimal_order, work_space.getADD(zo_name), targ);
    SW_STOP("Sweeper::findOptimalHandlingOrder");

//    reverse(optimal_order.begin(), optimal_order.end());

    // Create convolution steps
    for (unsigned int i = 0; i < optimal_order.size(); i++) {
      double &th = ra[optimal_order[i]];
      assertinternal(th > .0);
      if (optimal_order[i].type == Unreduced::REGULAR)
      cs.push_back(new ConvolutionStepRegular(th, optimal_order[i].begin));
      else
        cs.push_back(new ConvolutionStepRedux(th, optimal_order[i]));
      th = .0;
    }

    // Perform convolution
    ConvolutionStep::allow_swap = true;
    convolutionStep(res_name, zo_name, &*cs.begin(), &*cs.end(), viterbi);

    if (work_space.type(res_name) == BFunction::ADD_FUN &&
        res_mgr.ReadRoundingPrec() != int(options->mtbddrounding)) {
      res_mgr.SetRoundingPrec(options->mtbddrounding);
      SW_START("reRound");
      reRound(work_space.getADD(res_name), res_mgr.ReadSize()/3);
      SW_STOP("reRound");
    }

    work_space.dontNeed(res_name);

    SW_STOP("Sweeper::convolutionPass");
  } else {
    // Create convolution steps

    // FCR should be handled first (both because of efficiency and to
    // avoid them being done between swapped bits)
    for (RecombAccumulator::iterator i = ra.begin(); i != ra.end(); i++) {
      double &th = i->second;
      if (th > .0 && i->first.type == Unreduced::FCR) {
        cs.push_back(new ConvolutionStepRedux(th, i->first));
        th = .0;
      }
    }
    for (RecombAccumulator::iterator i = ra.begin(); i != ra.end(); i++) {
      double &th = i->second;
      if (th > .0) {
        if (i->first.type == Unreduced::REGULAR)
          cs.push_back(new ConvolutionStepRegular(th, i->first.begin));
        else
          cs.push_back(new ConvolutionStepRedux(th, i->first));
        th = .0;
      }
    }

    Float *f = work_space.getVector(res_name);
    ConvolutionStep::indexToLevel(work_space.getPerm(res_name),
                                  res_mgr.ReadSize(), &*cs.begin(), &*cs.end());
    SW_START("ConvolutionStep::vectorStep");
    ConvolutionStep::vectorStep(f, IV(1) << res_mgr.ReadSize(), &*cs.begin(),
                                &*cs.end());
    SW_STOP("ConvolutionStep::vectorStep");
  }

  for (unsigned int i = 0; i < cs.size(); i++)
    delete cs[i];

  if (work_space.type(res_name) == BFunction::VECTOR_FUN) {
    ADD &zo = work_space.getADD(zo_name);

    if (countMinterm(zo) < options->mtbdddynamicthreshold/8.*(IV(1) << nbits))
      work_space.changeToADD(res_name, zo);
    else
      work_space.inplaceMult(res_name, zo);
  }
}

void Sweeper::convolutionStep(const string &res_name, const string &zo_name,
                              ConvolutionStep **cs, ConvolutionStep **cs_end,
                              bool viterbi) {
  ADD &res = work_space.getADD(res_name);
  ADD &zo = work_space.getADD(zo_name);
  Cudd &res_mgr = *res.manager();
  try {
    unsigned int last_reorder_size = res_mgr.ReadKeys() - res_mgr.ReadDead();
    SW_START("ConvolutionStep::step");
    ConvolutionStep::step(res, zo, cs, cs_end, last_reorder_size, viterbi);
    SW_STOP("ConvolutionStep::step");
  } catch (ConvolutionStepSwapException ce) {
    SW_STOP("ConvolutionStep::step");
    ConvolutionStep::allow_swap = false;
    // Find bits that may be conditioned on in order to break problem
    // into sub components
    vector<Uint> cond_bits;
    int *support = Cudd_SupportIndex(res_mgr.getManager(), res.getNode());
    for (int lvl = 0; lvl < res_mgr.ReadSize(); lvl++) {
      const ReducedIndex bit = res_mgr.getManager()->invperm[lvl];
      if (!support[bit] || isFixed(res, lvl)) continue;
      bool influenced = false;
      for (ConvolutionStep **c = ce.cs_b; c != ce.cs_e && !influenced; c++)
        if ((*c)->red.influences(bit))
          influenced = true;

      if (!influenced)
        cond_bits.push_back(bit);
    }
    free(support);
    if (cond_bits.empty()) {
      ConvolutionStep **m = cs + (cs_end - cs)/2;
      ConvolutionStep::allow_swap = true;
      convolutionStep(res_name, zo_name, m, cs_end, viterbi);
      ConvolutionStep::allow_swap = true;
      convolutionStep(res_name, zo_name, cs, m, viterbi);

      return;
    } else if (cond_bits.size() > 5)
      cond_bits.resize(5);

    // create sub components
    map<DdNode *, string> results;
    map<DdNode *, string> result_names;
    swapConvolutionStepCreateFiles(res, ce.zo, res_mgr.addOne(), cond_bits, 0,
                                   "", results, result_names);
    set<string> result_files;
    for (map<DdNode *, string>::const_iterator ri = result_names.begin();
         ri != result_names.end(); ri++) {
      result_files.insert(ri->second);
      Cudd_RecursiveDeref(res_mgr.getManager(), ri->first);
    }
    result_names.clear();

    // clean out memory
    work_space.erase(res_name);
//    res = res_mgr.addZero();
//    cuddGarbageCollect(res_mgr.getManager(), 1);

    // convolve each sub component
    {
      for (set<string>::const_iterator ri = result_files.begin();
           ri != result_files.end(); ri++) {
        res_mgr.SetRoundingPrec(options->mtbddrounding + 8 +
                            (ce.cs_e - ce.cs_b)/2);
        const string swap_res(options->swapdirname + "/swap_res." + *ri);
        work_space.add(readADD(swap_res, res_mgr), "swap_res");
        remove(swap_res.c_str());

        const string swap_zo(options->swapdirname + "/swap_zo." + *ri);
        work_space.add(readADD(swap_zo, res_mgr), "swap_zo");
        remove(swap_zo.c_str());

        convolutionStep("swap_res", "swap_zo", ce.cs_b, ce.cs_e, viterbi);
        work_space.erase("swap_zo");
        writeADD(options->swapdirname + "/swap_final." + *ri,
                 work_space.getADD("swap_res"));
        work_space.erase("swap_res");
      }
    }

    // collect convolutions of sub components into manager
    res_mgr.SetRoundingPrec(options->mtbddrounding);
    work_space.add(res_mgr.addZero(), res_name);
    for (set<string>::const_iterator ri = result_files.begin();
         ri != result_files.end(); ri++) {
      ADD sub_result;
      {
        Cudd swap_mgr(res_mgr.ReadSize(), 0, 256, 262144,
                      options->maxmem*(1 << 20)/8);
        swap_mgr.SetMinHit(1);
        swap_mgr.SetEpsilon(.0);
        swap_mgr.SetRoundingPrec(res_mgr.ReadRoundingPrec());

        const string swap_final(options->swapdirname + "/swap_final." + *ri);
        sub_result = addTransfer(readADD(swap_final, swap_mgr), res_mgr);
        remove(swap_final.c_str());
      }
      ADD cf = res_mgr.addZero();
      for (map<DdNode *, string>::const_iterator si = results.begin();
           si != results.end(); si++)
        if (*ri == si->second)
          cf += ADD(&res_mgr, si->first);
      assertinternal(cf != res_mgr.addZero());
      work_space.getADD(res_name) += cf*sub_result;

      while (5*res_mgr.ReadMemoryInUse() > 3*options->maxmem) {
        if (res_mgr.ReadRoundingPrec() > int(options->mtbddmaxrounding)) {
          res_mgr.SetRoundingPrec(max(int(options->mtbddmaxrounding),
                                  res_mgr.ReadRoundingPrec() - 10));
          reRound(work_space.getADD(res_name), res_mgr.ReadSize()/3);
        }
        unsigned int lrs = 0;
        ConvolutionStep::reorderManager(res_mgr, cs_end - ce.cs_b, 0, lrs);
        if (res_mgr.ReadRoundingPrec() == int(options->mtbddmaxrounding))
          break;
      }
    }
    for (map<DdNode *, string>::const_iterator si = results.begin();
         si != results.end(); si++)
      Cudd_RecursiveDeref(res_mgr.getManager(), si->first);

    if (ce.cs_b > cs) {
      ConvolutionStep::allow_swap = true;
      convolutionStep(res_name, zo_name, cs, ce.cs_b, viterbi);
    }
  } catch (ConvolutionStepVectorException ce) {
    SW_STOP("ConvolutionStep::step");
#ifdef DEBUG_OUTPUT
    cerr << "vvvvvectorizing " << ce.cs_e - cs << " / " << cs_end - cs << endl;
#endif // DEBUG_OUTPUT

    work_space.changeToVector(res_name);
    work_space.makeSpace(8*((IV(1) << res_mgr.ReadSize()) >> 20),
                         options->maxmem);
    Float *f = work_space.getVector(res_name);
    ConvolutionStep::indexToLevel(work_space.getPerm(res_name), nbits, cs,
                                  ce.cs_e);
    SW_START("ConvolutionStep::vectorStep");
    ConvolutionStep::vectorStep(f, IV(1) << res_mgr.ReadSize(), cs, ce.cs_e);
    SW_STOP("ConvolutionStep::vectorStep");
  }

  work_space.dontNeed(res_name);
  work_space.dontNeed(zo_name);
}

void Sweeper::
swapConvolutionStepCreateFiles(ADD res, ADD zo, ADD cube,
                               const vector<Uint> &cond_bits,
                               Uint cond_idx, const string &output,
                               map<DdNode *, string> &results,
                               map<DdNode *, string> &result_names) {
  if (res == res.manager()->addZero() || zo == zo.manager()->addZero())
    return;
  if (cond_idx == cond_bits.size()) {
    map<DdNode *, string>::const_iterator rni =
      result_names.find(res.getNode());
    if (rni == result_names.end()) {
      writeADD(options->swapdirname + "/swap_res." + output, res);
      writeADD(options->swapdirname + "/swap_zo." + output, zo);
      result_names[res.getNode()] = output;
      cuddRef(res.getNode());
      results[cube.getNode()] = output;
      cuddRef(cube.getNode());
    } else {
      results[cube.getNode()] = rni->second;
      cuddRef(cube.getNode());
    }
  } else {
    ADD bit(res.manager()->addVar(cond_bits[cond_idx]));
    ADD cnb = cube;
    cnb *= ~bit;
    swapConvolutionStepCreateFiles(
      singleCofactor(res, cond_bits[cond_idx], false),
      singleCofactor(zo, cond_bits[cond_idx], false), cnb,
      cond_bits, cond_idx + 1, output + "0", results, result_names);
    ADD cb = cube;
    cb *= bit;
    swapConvolutionStepCreateFiles(
      singleCofactor(res, cond_bits[cond_idx], true),
      singleCofactor(zo, cond_bits[cond_idx], true), cb,
      cond_bits, cond_idx + 1, output + "1", results, result_names);
  }
}

static bool informativephenotype(Person *p) {
  if (p->phenotyped) return true;
  for (Plist *c = p->children; c != 0; c = c->next)
    if (informativephenotype(c->p)) return true;
  return false;
}

Sweeper::Sweeper(Family *fam) :
    mgr(fam->numbits, 0, 256, 262144, options->maxmem*(1 << 20)/8),
    nbits(fam->numbits), work_space(fam->numbits) {
  mgr.SetMinHit(1);
  mgr.SetEpsilon(.0);
  mgr.SetRoundingPrec(options->mtbddrounding);

  for (unsigned int rb = 0; rb < nbits; rb++)
    unreduced.insert(Unreduced(rb));


  for (Person *p = fam->firstdescendant; p != 0; p = p->next)
    if (p->matbitlevel != Person::FIXEDBIT)
      makeFemale(p->matbitlevel);

  for (Person *p = fam->first; p != fam->firstdescendant; p = p->next) {
    vector<ReducedIndex> flips;
    const Sex pSex = p->sex;
    Uint num_informative_children = 0;
    Uint num_strictly_informative_children = 0;
    for (Plist *children = p->children; children != 0;
         children = children->next) {
      Person *child = children->p;
      if (informativephenotype(child)) {
        num_informative_children++;
        bool informative_gc = false;
        for (Plist *gc = child->children; gc != 0; gc = gc->next)
            if (informativephenotype(gc->p))
                informative_gc = true;
      }
      IV relmask = (pSex==MALE ? child->patmask : child->matmask);
      if (relmask) {
        int relbit = findPowTwo(relmask);
        flips.push_back(relbit);
      }
    }
    if (flips.size() > 0) {
      const bool informative = (num_informative_children > 1 ||
                                ((p->dstat != UNKNOWN) &&
                                (num_strictly_informative_children > 0)));
      if (flips.size() == 1)
        makeIntense(flips.front());
      else
        addFounderReduction(flips, informative &&
                            informativephenotype(p->children->p),
                            p->sex == FEMALE);
    }
  }

  for (Foundercouple *fc = fam->firstfoundercouple;fc!=0;fc=fc->next) {
    Person *father = fc->husband;
    Plist  *children = father->children;
    Person *child = 0;
    vector<ReducedIndex> flips;
    vector<ReducedIndex> src;
    vector<ReducedIndex> dest;
    // The two bits of the children are swapped

    bool reduced_bit_is_interesting = true;
    while (children != 0) {
      child = children->p;
      if (child->patmask && child->matmask) {
        int patbit = findPowTwo(child->patmask);
        int matbit = findPowTwo(child->matmask);

        src.push_back(patbit);
        dest.push_back(matbit);
      }
      // The grandchildren bits are flipped
      Plist *gChildren = child->children;
      Sex cSex = child->sex;
      Person *gChild = 0;
      while (gChildren != 0) {
        gChild = gChildren->p;
        const IV relmask = (cSex==MALE) ? gChild->patmask : gChild->matmask;
        if (relmask) {
          const int relbit = findPowTwo(relmask);
          flips.push_back(relbit);
        } else {
          if (!informativephenotype(gChild) && gChild->children == 0)
            reduced_bit_is_interesting = false;
        }
        gChildren = gChildren->next;
      }
      children = children->next;
    }
    if (src.empty())
      addFounderReduction(flips, reduced_bit_is_interesting, false);
    else
      addFounderCoupleReduction(flips, src, dest, reduced_bit_is_interesting);
  }

  uninteresting = unreduced;
  Distribution::getuninteresting(fam, uninteresting);

  for (set<Unreduced>::const_iterator ui = unreduced.begin();
       ui != unreduced.end(); ui++)
    racc[*ui] = .0;
}

void Sweeper::setup(ADDvector &sp) {
  spt_structure.resize(sp.count());
  for (unsigned int i = 0; i < spt_structure.size(); i++) {
    SPTStructure &spt_i = spt_structure[i];
    spt_i.spt = sp[i];
    spt_i.informative = informativePass(sp[i], unreduced);
    if (i == 0)
      set_difference(unreduced.begin(), unreduced.end(),
                     spt_i.informative.begin(), spt_i.informative.end(),
                     inserter(spt_i.uninformative_from_left,
                              spt_i.uninformative_from_left.end()));
    else
      set_difference(spt_structure[i - 1].uninformative_from_left.begin(),
                     spt_structure[i - 1].uninformative_from_left.end(),
                     spt_i.informative.begin(), spt_i.informative.end(),
                     inserter(spt_i.uninformative_from_left,
                              spt_i.uninformative_from_left.end()));
  }

  for (int i = spt_structure.size() - 1; i >= 0; i--) {
    SPTStructure &spt_i = spt_structure[i];
    if ((unsigned int)(i + 1) == spt_structure.size())
      set_difference(unreduced.begin(), unreduced.end(),
                     spt_i.informative.begin(), spt_i.informative.end(),
                     inserter(spt_i.uninformative_from_right,
                              spt_i.uninformative_from_right.end()));
    else
      set_difference(spt_structure[i + 1].uninformative_from_right.begin(),
                     spt_structure[i + 1].uninformative_from_right.end(),
                     spt_i.informative.begin(), spt_i.informative.end(),
                     inserter(spt_i.uninformative_from_right,
                              spt_i.uninformative_from_right.end()));
  }
}

ADD Sweeper::ivToADD(IV v, Cudd &mgr) {
  ADD res = mgr.addOne();
  for (IV bit = 0; bit < IV(mgr.ReadSize()); bit++)
    res *= v & (IV(1) << bit) ? mgr.addVar(bit) : ~mgr.addVar(bit);
  return res;
}

IV Sweeper::getMaxIV(IV max_iv, DdNode *x, DdNode *mx, st_table *table) {
  if (x == mx)
    return max_iv;
  else if (cuddIsConstant(x))
    return IV(-1);
  else {
    int res;
    if (st_lookup(table, x, &res))
      return IV(-1);

    IV t = getMaxIV(max_iv + (IV(1) << x->index), cuddT(x), mx, table);
    if (t != IV(-1))
      return t;

    IV e = getMaxIV(max_iv, cuddE(x), mx, table);
    if (e != IV(-1))
      return e;

    st_add_direct(table, (char *)x, 0);
    return IV(-1);
  }
}

IV Sweeper::getMaxIV(ADD x) {
  ADD mx = x.FindMax();

  IV max_iv = 0;
  st_table *table = st_init_table(st_ptrcmp, st_ptrhash);
  const IV res = getMaxIV(max_iv, x.getNode(), mx.getNode(), table);
  st_free_table(table);

  return res;
}

IV Sweeper::startViterbiBacktrack() {
  work_space.add(mgr.addOne(), "left");
  const IV res = viterbiBacktrack("left", "from", racc);
  return res;
}

IV Sweeper::viterbiBacktrack(IV left, RecombAccumulator &ra, ADD spt,
                             double theta_male, double theta_female,
                             const string &right_file) {
  work_space.add(ivToADD(left, mgr), "left");
  RecombAccumulator left_acc(unreduced);
  left_acc.add(theta_male, theta_female);

  work_space.add(addTransfer(spt.OneZeroMaximum(spt.manager()->addZero()), mgr),
                 "zo");
  convolutionPass("left", "zo", unreduced, left_acc, true);
  work_space.erase("zo");

  ADD &l(work_space.getADD("left"));
  l *= addTransfer(spt, *l.manager());
  work_space.dontNeed("left");
  work_space.add(right_file, mgr, true, "right");
  const IV res = viterbiBacktrack("left", "right", ra);

  assertinternal(ivToADD(res, *spt.manager())*spt != spt.manager()->addZero());

  return res;
}

ADD Sweeper::maxOut(ADD x, const set<Unreduced> &u, bool out_reduced) {
  ADD res(x);
  for (set<Unreduced>::const_iterator ui = u.begin(); ui != u.end(); ui++)
    if (ui->type == Unreduced::REGULAR) {
      ADD bv(res.manager()->addVar(ui->begin));
      res = res.Cofactor(bv).Maximum(res.Cofactor(~bv));
    } else if (out_reduced)
      res = res.Maximum(ui->transform(res));
  return res;
}

IV Sweeper::viterbiBacktrack(const string &left_name, const string &right_name,
                             RecombAccumulator &ra) {
  set<Unreduced> unhandled;
  for (RecombAccumulator::const_iterator rai = ra.begin(); rai != ra.end();
       rai++)
    if (rai->second > .0)
      unhandled.insert(rai->first);
//   convolutionPass(right, zo, unhandled, ra, true);

  ADD &left = work_space.getADD(left_name);
  ADD &right = work_space.getADD(right_name);

  work_space.add(left*right, "final");
  while (!unhandled.empty()) {
    ADD mx(work_space.getADD("final").FindMax());
    work_space.dontNeed("final");

    ADD left_sub(maxOut(left, unhandled, false));
    ADD right_sub(maxOut(right, unhandled, true));

    ADD final_sub(left_sub*right_sub);
    left_sub = right_sub = ADD();
    const double rep = ra.resipProduct();
    work_space.add(final_sub.OneZeroMaximum(
                     final_sub.manager()->constant(
                       .98*cuddV(mx.getNode())*rep)), "zo");
    final_sub = ADD();
    ADD &zo = work_space.getADD("zo");
    assertinternal(zo != zo.manager()->addZero());

    set<Unreduced> uh(findLegalStepSubset(unhandled, countMinterm(zo)));

    convolutionPass(right_name, "zo", uh, ra, true);
    work_space.erase("zo");

    work_space.setADD("final", work_space.getADD(left_name)*
                      work_space.getADD(right_name));
  }

  work_space.erase(left_name);
  work_space.erase(right_name);

  const IV res = getMaxIV(work_space.getADD("final"));
  work_space.erase("final");

  return res;
}

void Sweeper::calcRecombDist(const string &left_fn, bool left_is_ADD,
                             const RecombAccumulator &la, ADD &sp,
                             Uint gam_m_1, double theta, double theta_female) {
  Cudd comp_mgr(nbits, 0, 256, 262144, options->maxmem*(1 << 20)/8);
  comp_mgr.SetRoundingPrec(options->mtbddrounding);
  comp_mgr.SetEpsilon(0.0);

  if (left_fn == "")
    work_space.add(comp_mgr.addOne(), "left");
  else
    work_space.add(left_fn, comp_mgr, left_is_ADD, "left");
  work_space.inplaceMult("left", sp);

  Recombdist::set("left", la, *this, gam_m_1, theta, theta_female, "rpt");
  work_space.erase("left");
}

void Sweeper::probRecomb(double &recomb, double &recomb_female,
                         const string &left, const RecombAccumulator &ral,
                         double theta, double theta_female) {
  recomb = recomb_female = .0;

  if (work_space.type("from") == BFunction::VECTOR_FUN) {
    work_space.copy("right", "from");
    work_space.transfer("right", work_space.manager(left));
  } else {
    work_space.add(addTransfer(work_space.getADD("from"),
                               work_space.manager(left)), "right");
    work_space.dontNeed("from");
  }

  set<Unreduced> bits, left_drop_bits, right_drop_bits;
  int *left_support = work_space.support(left);
  int *right_support = work_space.support("right");

  RecombAccumulator rl(ral), rr(racc);
  for (set<Unreduced>::const_iterator b = unreduced.begin();
       b != unreduced.end(); b++)
    if (b->type == Unreduced::REGULAR) {
      if (left_support[b->begin] && right_support[b->begin])
        bits.insert(*b);
      else {
        rl[*b] = rr[*b] = .0;
        if (right_support[b->begin]) right_drop_bits.insert(*b);
        if (left_support[b->begin]) left_drop_bits.insert(*b);

        const double intense_factor = b->isIntense() ? 2. : 1.;
        if (options->sexspecific && b->isFemale())
          recomb_female += intense_factor*theta_female;
        else
          recomb += intense_factor*theta;
      }
    } else
      bits.insert(*b);
  free(left_support);
  free(right_support);

  work_space.integrateOut(left, left_drop_bits);
  work_space.integrateOut("right", right_drop_bits);

  probRecomb(recomb, recomb_female, bits, left, rl, "right", rr, theta,
             theta_female);

  work_space.erase("right");
}

void Sweeper::probRecombSplit(double &recomb, double &recomb_female,
                              const set<Unreduced> &all_bits,
                              const set<Unreduced> &convolve_bits,
                              const set<Unreduced> &remaining_bits,
                              const string &left_name,
                              const RecombAccumulator &ral,
                              const string &right_name,
                              const RecombAccumulator &rar, double theta,
                              double theta_female) {
  const string new_left_name(left_name + "l");
  const string new_right_name(right_name + "r");
  work_space.copy(new_left_name, left_name);
  work_space.copy(new_right_name, right_name);

  RecombAccumulator conv_ral(ral), conv_rar(rar);

  conv_ral.add(theta, theta_female, all_bits);
  work_space.add(mgr.addOne(), "zo");
  handleUninteresting("zo", new_left_name, conv_ral, new_right_name,
                      conv_rar, convolve_bits);
  work_space.erase("zo");

  probRecomb(recomb, recomb_female, remaining_bits, new_left_name, ral,
             new_right_name, rar, theta, theta_female);

  work_space.erase(new_left_name);
  work_space.erase(new_right_name);
}

void Sweeper::probRecomb(double &recomb, double &recomb_female,
                         const set<Unreduced> &bits, const string &left_name,
                         const RecombAccumulator &ral, const string &right_name,
                         const RecombAccumulator &rar, double theta,
                         double theta_female) {
  assertinternal(!bits.empty());
  if (bits.size() == 1) {
    const double prob_norecomb = work_space.dotProduct(left_name, right_name);
    const double prob_recomb = work_space.dotProductRec(left_name, right_name,
                                                        *bits.begin());

//     const double prob_norecomb = sum(left*addTransfer(right, *left.manager()));
//     if (bits.begin()->type == Unreduced::REGULAR) {
//       vector<ReducedIndex> ri(1, bits.begin()->begin);
//       Unreduced tr(ri);
//       prob_recomb = sum(left*addTransfer(tr.transform(right), *left.manager()));
//     } else
//       prob_recomb = sum(left*addTransfer(bits.begin()->transform(right),
//                                          *left.manager()));

    const double tl = ral.find(*bits.begin())->second;
    const double tr = rar.find(*bits.begin())->second;
    const double t = (1. - tl)*tr + tl*(1. - tr);

    const double prob_nor = prob_norecomb*(1. - t) + t*prob_recomb;
    const double prob_r = prob_recomb*(1. - t) + t*prob_norecomb;

    const double th =
      options->sexspecific && bits.begin()->isFemale() ? theta_female : theta;
    double pr;
    if (bits.begin()->isIntense()) {
      const double n = (1. - th)*prob_nor + th*prob_r;
      const double r = (1. - th)*prob_r + th*prob_nor;
      pr = 2.*r*th/(n*(1. - th) + r*th);
    } else
      pr = prob_r*th/(prob_nor*(1. - th) + prob_r*th);
    if (options->sexspecific && bits.begin()->isFemale())
      recomb_female += pr;
    else
      recomb += pr;
  } else {
    set<Unreduced>::const_iterator middle(bits.begin());
    advance(middle, bits.size()/2);

    set<Unreduced> bits_1(bits.begin(), middle);
    set<Unreduced> bits_2(middle, bits.end());

    // Make sure swapped bits end up in the same partition
    for (set<Unreduced>::const_iterator b = bits.begin(); b != bits.end(); b++)
      if (b->type == Unreduced::FCR) {
        for (unsigned int i = 0; i < b->swaps_src.size(); i++) {
          const ReducedIndex s = b->swaps_src[i];
          const ReducedIndex d = b->swaps_dest[i];
          assertinternal(s != d);
          const bool s_in_1 = bits_1.count(Unreduced(s));
          const bool d_in_1 = bits_1.count(Unreduced(d));
          const bool s_in_2 = bits_2.count(Unreduced(s));
          const bool d_in_2 = bits_2.count(Unreduced(d));
          if ((s_in_1 && d_in_2) || (s_in_2 && d_in_1)) {
            set<Unreduced> &b_s = s_in_1 ? bits_1 : bits_2;
            set<Unreduced> &b_d = d_in_2 ? bits_2 : bits_1;
            if (b_s.size() > b_d.size()) {
              set<Unreduced>::iterator i_s = b_s.find(Unreduced(s));
              b_d.insert(*i_s);
              b_s.erase(i_s);
            } else {
              set<Unreduced>::iterator i_d = b_d.find(Unreduced(d));
              b_s.insert(*i_d);
              b_d.erase(i_d);
            }
          }
        }

        for (set<Unreduced>::const_iterator c = bits_1.begin();
             c != bits_1.end(); c++)
          if (c->type == Unreduced::FR && b->swaps(*c)) {
            for (set<Unreduced>::const_iterator d = bits_2.begin();
                 d != bits_2.end(); d++)
              if (d->type == Unreduced::FR && b->swaps(*d)) {
                if (bits_1.size() > bits_2.size()) {
                  bits_2.insert(*c);
                  bits_1.erase(c);
                } else {
                  bits_1.insert(*d);
                  bits_2.erase(d);
                }
                break;
              }
            break;
          }
      }

    probRecombSplit(recomb, recomb_female, bits, bits_1, bits_2, left_name,
                    ral, right_name, rar, theta, theta_female);
    probRecombSplit(recomb, recomb_female, bits, bits_2, bits_1, left_name,
                    ral, right_name, rar, theta, theta_female);
  }
}

void ADDWorkSpace::print() {
  for (map<string, WorkRecord>::iterator i = data.begin();
       i != data.end(); i++) {
    cout << i->first << "\t"
         << (i->second.m_bf->type() == BFunction::ADD_FUN ? "ADD" : "VEC")
         << "\t" << &i->second.m_bf->manager() << "\t"
         << i->second.m_needed << "\t" << i->second.m_bf->inMemory() << endl;
//     if (i->second.swap_file == "") {
//       cout << i->second.add.manager()->ReadMemoryInUse() << "\t";
//       i->second.add.print(i->second.add.manager()->ReadSize(), 1);
//     } else
//       cout << i->second.swap_file << endl;
//     cout << endl;
  }
}

void ADDWorkSpace::printBF(char *name, int print_level) {
  find(string(name)).m_bf->print(print_level);
}

void ADDWorkSpace::printZO(char *name, int print_level) {
  const string n(name);
  ADD one(manager(n).addOne());
  ADD zero(manager(n).addZero());
  asADD(n, one).OneZeroMaximum(zero).print(manager(n).ReadSize(), print_level);
}

void ADDWorkSpace::checkManagers() {
  for (map<string, WorkRecord>::iterator i = data.begin();
       i != data.end(); i++)
    assert(Cudd_DebugCheck(i->second.m_bf->manager().getManager()) == 0);
}

void ADDWorkSpace::makeSpace(unsigned int want, unsigned int available) {
  set<Cudd *> needed_mgrs;
  set<Cudd *> all_mgrs;
  for (map<string, WorkRecord>::iterator i = data.begin();
       i != data.end(); i++)
    if (i->second.m_bf->inMemory()) {
      if (i->second.m_needed)
        needed_mgrs.insert(&i->second.m_bf->manager());
      all_mgrs.insert(&i->second.m_bf->manager());
    }

  set<Cudd *> not_needed_mgrs;
  set_difference(all_mgrs.begin(), all_mgrs.end(),
                 needed_mgrs.begin(), needed_mgrs.end(),
                 inserter(not_needed_mgrs, not_needed_mgrs.end()));

  unsigned int memory_in_use = 100 + memoryInUse();

  if (memory_in_use + want > available) { // need to free some memory
    for (set<Cudd *>::iterator mi = not_needed_mgrs.begin();
         mi != not_needed_mgrs.end() && memory_in_use + want > available;
         mi++) {
      // swap all ADDs that use the manager to disk
      memory_in_use -= (*mi)->ReadMemoryInUse();
      for (map<string, WorkRecord>::iterator i = data.begin();
           i != data.end(); i++)
        if (&i->second.m_bf->manager() == *mi && i->second.m_bf->inMemory())
          swapToFile(i->first);

      // delete the manager
      Cudd new_manager((*mi)->ReadSize(), 0, 256, 262144,
                       options->maxmem*(1 << 20)/8);
      **mi = new_manager;
    }

    if (memory_in_use + want > available) {
      // In addition swap all ADDs, that are not needed, to disk
      for (map<string, WorkRecord>::iterator i = data.begin();
           i != data.end(); i++)
        if (!i->second.m_needed && i->second.m_bf->inMemory())
          swapToFile(i->first);
    }
  }
}

void Sweeper::checkManagers() {
  assert(Cudd_DebugCheck(mgr.getManager()) == 0);

  work_space.checkManagers();
}

void Sweeper::checkBF(const string &name, const string &ref_fn,
                      const Uint gam) {
  vector<double> ref(IV(1) << nbits);
  ifstream ref_file(ref_fn.c_str());
  while (!ref_file.eof()) {
    Uint g;
    IV v;
    double x;
    ref_file >> g >> v >> x >> ws;
    assertinternal(v < ref.size());
    if (g == gam)
      ref[v] = x;
  }

  vector<double> d(IV(1) << nbits);
  work_space.asStraightVector(name, &*d.begin());
//  work_space.asADD(name).print(nbits, 2);

  double max_d = -1e300;
  double min_d = 1e300;

  for (IV v = 0; v < ref.size(); v++) {
    const double rv = ref[v];
    const double dv = d[v];

    if (dv == .0) {
//       if (dv != .0) {
//         min_d = -1e300;
//         max_d = 1e300;
//       }
    } else {
      if (rv == .0) {
        min_d = -1e300;
        max_d = 1e300;
      }

      const double dd = log(fabs(rv/dv));
      if (dd < min_d) min_d = dd;
      if (dd > max_d) max_d = dd;
    }
  }

  assertcond(max_d - min_d < log(.01), "distribution is different from ref");
}
