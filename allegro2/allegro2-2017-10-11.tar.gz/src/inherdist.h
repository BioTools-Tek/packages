#ifndef _INHERDIST
#define _INHERDIST
#include "distribution.h"

class Inherdist : public Distribution {
public:
  // This class writes distribution of inheritance vectors to files called
  //    options->inherdistfolder/familyid.pt.gam 
  // where the default of options->inherdistfolder is inherdist, familyid is
  // the id of the family, pt is mpt or spt, and gam is the number of locus

  virtual ~Inherdist();
  virtual string describe() const {return "inherdist";}

  static Inherdist *getinherdist(const string &pt);

  void getdist(const string &famid, IV numiv, Uint gam, DoubleVec p);
  Family *getfirstfamily() {return *families.begin();}

  virtual bool usefamily(Family *, bool) const {return true;}
protected:
  bool storeresults;

  Inherdist(const string &p, bool store = false) :
      Distribution(p), storeresults(store) {}

  virtual void reset(Uint np);
  virtual void nextfam(bool /*mtbdd*/, Uint /*pos*/ = 0,
                       DoubleVec /*p0*/ = 0) {}
  virtual void set(FloatVec pv, Uint pos);
  virtual void set(ADD &/*pv*/, double /*sum_pv*/, Uint /*pos*/) {
    fatal("Distribution of inheritance vectors not implemented for MTBDDs");
  }
  virtual string getfilename(const string &famid, Uint pos) const;
  virtual void skipfam() {}

  virtual void getuninteresting(::set<Unreduced> &uninteresting);

};

#endif // _INHERDIST
