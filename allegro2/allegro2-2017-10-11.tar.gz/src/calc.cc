#include "calc.h"
#include "family.h"
#include "utils.h"
#include "options.h"
#include "Unreduced.hh"

/////////////////////////////////////////////////////////////////////////
// Calc

#include <typeinfo>

Calc::Calcvector Calc::calcs;

void Calc::calcnumscores(Family *first, IV maxnumiv) {
  numscores = 0;
  for (Family *f = first; f != 0; f = f->next)
    if (f->numbits <= options->mtbddthreshold) {
      const Uint numas = f->nasymmetricfoundercouples();
      if (numscores == 0) numscores = maxnumiv;
      numscores = max(f->numiv()*(IV(1) << numas), numscores);
    }
}

Calc *Calc::findcalc(const string &desc) {
  for (Uint s = 0; s < calcs.size(); s++)
    if (calcs[s]->describe() == desc)
      return calcs[s];
  return 0;
}

Double Calc::countvecsneeded(Family *first, IV maxnumiv) {
  Double count = 0.0;
  for (Uint s = 0; s < calcs.size(); s++)
    calcs[s]->calcnumscores(first, maxnumiv);
  for (Uint s = 0; s < calcs.size(); s++)
    count += Double(calcs[s]->numscores)/Double(maxnumiv);
  return count;
}

//mct -- changed from void to bool, returns whether it can alloc memory or not
bool Calc::setup(Family *first, IV maxnumiv) {
    cerr << "\rcalcsetup SIZE:" << calcs.size() << flush;
    for (Uint s = 0; s < calcs.size(); s++) {
        cerr << "\r, s-value:" << s << flush;
        calcs[s]->calcnumscores(first, maxnumiv);
        cerr << "\r, calcnumscores" << flush;
        if (calcs[s]->numscores > 0){
            cerr << "\r, numscores > 0" << flush;
            calcs[s]->vec = new Double[calcs[s]->numscores];
            cerr << "\r, new vector generated" << flush;
        }
        //mct - On a 2GB RAM machine, malloc can only allocated a maxnumiv of ~ 200000, which explains the 17-bit crashes
        // when maxnumiv is 262144. This of course depends on swap and mem overcommit behaviour too
        cerr << "\rcalcsetup set_UP (first,maxnumiv)= (" << first << "," << maxnumiv << ")" << flush;
        try{
            cerr << "\rcalcsetup idname: " << typeid(calcs[s]).name() << flush;
            calcs[s]->set_up(first, maxnumiv);
//            exit(-1);
        }
        catch (bad_alloc& ba){
            cerr << "calcsetup BAD_ALLOC: " << ba.what()  << " --- Forcing lowmem option" <<  endl;
            return true; //Low mem
        }
        cerr << "\rcalcsetup setup initial" << flush;
        return false; //good mem

    }
}

void Calc::cleanupS() {
  for (Uint s = 0; s < calcs.size(); s++) {
    calcs[s]->S.clear();
    calcs[s]->clean_up();
  }
}

void Calc::calculate(Family *fam) {
  if (fam->numbits > 0)
    for (Uint s = 0; s < calcs.size(); s++)
      (*calcs[s])(fam);
}

void Calc::calculate(Family *fam, Cudd &mgr) {
  if (fam->numbits > 0)
    for (Uint s = 0; s < calcs.size(); s++)
      (*calcs[s])(fam, mgr);
}

void Calc::getuninteresting(set<Unreduced> &uninteresting) {
  assertinternal(vec == 0 && S.count() > 0);
  set<Unreduced> interesting_bits;
  for (int i = 0; i < S.count(); i++) {
    int *support = Cudd_SupportIndex(S[i].manager()->getManager(),
                                     S[i].getNode());
    for (set<Unreduced>::const_iterator ui = uninteresting.begin();
         ui != uninteresting.end(); ui++) {
      const bool interesting = (ui->type == Unreduced::REGULAR ?
                                support[ui->begin] : ui->informative(S[i]));
      if (interesting)
        interesting_bits.insert(*ui);
    }

    free(support);
  }

  for (set<Unreduced>::const_iterator ib = interesting_bits.begin();
       ib != interesting_bits.end(); ib++)
    uninteresting.erase(*ib);
}
