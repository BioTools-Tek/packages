#include "calcparametric.h"
#include "files.h"
#include "peel.h"
#include "vecutil.h"
#include "options.h"
#include "mtbddpeel.h"

//////////////////////////////////////////////////////////////////////
// Calcparametric

Calcparametric *Calcparametric::getcalcparametric(Trait *tr) {
  Calc *clc = findcalc(description(tr));
  if (clc != 0) return (Calcparametric *)clc;
  else return new Calcparametric(tr);
}

void Calcparametric::calclod(Family *fam, Foundercouple *fc) {
  if (fc == 0) {
    ESgraph g(*fam, trait);
    g.peel(vec);
  }
  else {
    calclod(fam, fc->next);
    if (fc->husband->dstat != fc->wife->dstat) {
      fc->swapdstat();
      calclod(fam, fc->next);
      fc->swapdstat();
    }
  }
}

void Calcparametric::calclod(Family *fam, Foundercouple *fc,
                             Cudd &mgr) {
  if (fc == 0) {
    mtbdd_peeler.push_back(PPeeler());
    mtbdd_peeler.back().setup(fam, mgr, trait);
//     ESgraph g(*fam, trait);
//     ADDvector vars = mgr.GetADDVariables();
//     S.push_back(g.peel(vars, mgr));
  }
  else {
    return calclod(fam, fc->next, mgr);
    if (fc->husband->dstat != fc->wife->dstat) {
      fc->swapdstat();
      calclod(fam, fc->next, mgr);
      fc->swapdstat();
    }
  }
}

Double Calcparametric::sumLp(ADD &pv, Double sum_pv) {
  Double res = .0;
  for (Uint i = 0; i < mtbdd_peeler.size(); i++)
    res += mtbdd_peeler[i].peel(pv);
  return res/sum_pv;
}

void Calcparametric::operator() (Family *fam) {
  if (options->sexlinked == getsexlinked()) {
    zero(vec, fam->numiv());
    calclod(fam, fam->firstfoundercouple);
  }
}

void Calcparametric::operator() (Family *fam, Cudd &mgr) {
  if (options->sexlinked == getsexlinked()) {
    S.clear();
    S.push_back(mgr.addOne());
    calclod(fam, fam->firstfoundercouple, mgr);
  }
}
