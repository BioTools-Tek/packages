#ifndef _TRAITDATA
#define _TRAITDATA

#include "basic.h"

#include <map>

class Traitdata {
public:
  Traitdata(const Stringvector &traitfiles);

  bool hastraitvalue(const string &pn) const {
    for (map<string, String2Double>::const_iterator ti = data.begin();
         ti != data.end(); ti++) {
      String2Double::const_iterator pi = ti->second.find(pn);
      if (pi != ti->second.end()) return true;
    }
    return false;
  }
  bool hastraitvalue(const string &pn, const string &trait) const {
    map<string, String2Double>::const_iterator ti;
    if (trait == "") {
      assertinternal(data.size() == 1);
      ti = data.begin();
    } else {
      ti = data.find(trait);
      assertinternal(ti != data.end());
    }
    String2Double::const_iterator pi = ti->second.find(pn);
    return pi != ti->second.end();
  }
  Double gettraitvalue(const string &pn, const string &trait) const {
    map<string, String2Double>::const_iterator ti;
    if (trait == "") {
      assertinternal(data.size() == 1);
      ti = data.begin();
    } else {
      ti = data.find(trait);
      assertinternal(ti != data.end());
    }
    String2Double::const_iterator pi = ti->second.find(pn);
    assertinternal(pi != ti->second.end());
    return pi->second;
  }

private:
  map<string, String2Double> data;

};

extern Traitdata *traitdata;

#endif // _TRAITDATA
