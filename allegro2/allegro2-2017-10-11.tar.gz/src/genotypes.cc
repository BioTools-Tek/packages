#include "files.h"
#include "options.h"
#include "map.h"
#include "control.h"
#include "genotypes.h"
#include "vecutil.h"
#include "family.h"

#include <algorithm>

int Marker::nextidx = 0;

const Uint MAXLINE = 1000;
char gtbuf[MAXLINE];
char gtbuf2[MAXLINE];

void readgenotypefile(String2Marker &string2marker, String2PN &string2PN) {
  options->genotypefile.open();
  int linenum = 0;
  while (!options->genotypefile.eof()) {
    linenum++;
    options->genotypefile >> gtbuf >> gtbuf2;
    String2Marker::iterator m = string2marker.find(gtbuf2);
    if (m != string2marker.end()) {
      PN &pn = string2PN[gtbuf];
      int r1, r2;
      options->genotypefile >> r1 >> r2 >> ws;
      if (options->genotypefile.fail())
        fatal(string("Illegal value at line ") + linenum + " in " +
              options->genotypefile.name);
      m->second.genotypesexist = true;
      pn.add(m->second.idx, r1, r1);
    }
  }
  options->genotypefile.close();
}

class MarkerOrder {
private:
  const String2Marker &string2marker;

  double loc(const string &m) const {
    String2Marker::const_iterator mi = string2marker.find(m);
    assertinternal(mi != string2marker.end());
    return mi->second.location;
  }

public:
  MarkerOrder(const String2Marker &s2m) : string2marker(s2m) {}

  bool operator()(const string &m1, const string &m2) const {
    return loc(m1) < loc(m2);
  }
};

void readmapfile(String2Marker &string2marker,
                 String2Chromosome &string2chromosome) {
  options->mapfile.open();
  options->mapfile >> ws;
  char lastchromosome[MAXLINE] = "";
  Chromosome *ch = 0;
  while (!options->mapfile.eof()) {
    options->mapfile >> gtbuf;
    if (gtbuf[0] == '%') continue;
    if (strcmp(gtbuf, lastchromosome) != 0) {
      ch = &string2chromosome[gtbuf];
      assertcond(ch != 0, string("Chromosome ") + gtbuf +
                 " in map file is not in chromosomefile");
      strcpy(lastchromosome, gtbuf);
    }
    if (ch->id == options->chromosome) {
      options->mapfile >> gtbuf;
      String2Marker::iterator mi = string2marker.find(gtbuf);
      assertcond(mi == string2marker.end(),
                 string("Marker ") + gtbuf + " repeated in map!");

      Marker &m = string2marker[gtbuf];
      m.id = gtbuf;
      options->mapfile >> m.location;
      if (options->sexspecific)
        options->mapfile >> m.location_female;
      ch->add(m.id);
    }
    options->mapfile.ignore(MAXLINE, '\n');
    options->mapfile >> ws;
  }
  options->mapfile.close();
}

void readfreqfile(String2Marker &string2marker) {
  options->freqfile.open();
  options->freqfile >> ws;
  char lastmarker[MAXLINE] = "";
  String2Marker::iterator m = string2marker.end();
  while (!options->freqfile.eof()) {
    options->freqfile >> gtbuf;
    if (strcmp(gtbuf, lastmarker) != 0) {
      string2marker[gtbuf];
      m = string2marker.find(gtbuf);
      strcpy(lastmarker, gtbuf);
    }
    if (m != string2marker.end()) {
      int rep;
      options->freqfile >> rep;
      Float freq;
      options->freqfile >> freq;
      m->second.rep2freq[rep] = freq + options->controlprior;
      m->second.controlsavailable = true;
    }
    options->freqfile.ignore(MAXLINE, '\n');
  }
  options->freqfile.close();
}

void readaffectionfile(String2PN &string2pn) {
  options->affectionfile.open();
  int linenum = 0;
  while (!options->affectionfile.eof()) {
    linenum++;
    options->affectionfile >> gtbuf;
    PN &pn = string2pn[gtbuf];
    int tmpint;
    options->affectionfile >> tmpint;
    if (options->affectionfile.fail())
      fatal(string("Illegal disease status in affection file at line ") +
            linenum);
    if (tmpint >= 2) tmpint = 2;
    else if (tmpint <= 0) tmpint = 0;
    else tmpint = 1;
    pn.dstat = Diseasestatus(tmpint);
    options->affectionfile >> ws;
  }
  options->affectionfile.close();
}

void readchromosomefile(String2Chromosome &string2chromosome) {
  options->chromosomefile.open();
  while (!options->chromosomefile.eof()) {
    options->chromosomefile >> gtbuf;
    Chromosome &ch = string2chromosome[gtbuf];
    ch.id = gtbuf;
    options->chromosomefile >> ch.length;
    assertcond(ch.length > 0, string("Illegal chromosome length ") +
               ch.length + " for " + ch.id);
    if (options->sexspecific) {
      options->chromosomefile >> ch.length_female;
      assertcond(ch.length_female > 0,
                 string("Illegal female chromosome length ") +
                 ch.length_female + " for " + ch.id);
    }
    options->chromosomefile >> gtbuf;
    switch (gtbuf[0]) {
      case 'a':
      case 'A':
        ch.type = AUTOSOMAL; break;
      case 's':
      case 'S':
        ch.type = SEXLINKED; break;
      default: fatal(string("Unknown chromosome type ") + gtbuf);
    }
    options->chromosomefile.ignore(MAXLINE, '\n');
    options->chromosomefile >> ws;
  }
  options->chromosomefile.close();
}

void Control::inputdecode() {
  String2Chromosome string2chromosome;
  String2PN string2pn;
  String2Marker string2marker;
  readchromosomefile(string2chromosome);
  assertcond(string2chromosome.find(options->chromosome) !=
             string2chromosome.end(), "unable to find chromosome '" +
             options->chromosome + "' in chromosomefile");
  Chromosome &chr = string2chromosome[options->chromosome];
  readmapfile(string2marker, string2chromosome);
  readgenotypefile(string2marker, string2pn);

  // Remove markers for which no genotypes exist
  for (vector<string>::iterator mi = chr.markers.begin();
       mi != chr.markers.end();)
    if (string2marker[*mi].genotypesexist) mi++;
    else mi = chr.markers.erase(mi);

  // Sort remaining markers
  MarkerOrder markerorder(string2marker);
  sort(chr.markers.begin(), chr.markers.end(), markerorder);

  readfreqfile(string2marker);
  initializechromosome(options->chromosome, string2chromosome, string2marker,
                       string2pn);

  if (options->affectionfile.assigned()) readaffectionfile(string2pn);
  Infile prefile;
  prefile.setname(options->prefile[0]);
  getpre(prefile, 0, 0, 0, 0, &string2marker, &string2pn,
         &string2chromosome.find(options->chromosome)->second);
}

void Control::initializechromosome(const string &id,
                                   String2Chromosome &string2chromosome,
                                   String2Marker &string2marker,
                                   String2PN &string2pn) {
//   message("");
//   message("Analysing chromosome " + id);
//   message("");
  String2Chromosome::iterator ch = string2chromosome.find(id);
  assertinternal(ch != string2chromosome.end());
  map.reset();
  map.setunit(CENTIMORGAN);
  map.init(ch->second.markers.size() + (options->addendmarkers ? 2 : 0));
  assertcond(!ch->second.markers.empty(),
             "Chromosome " + id + " has no markers");
  // Compute marker distances
  Uint numendmarkers = (options->addendmarkers ? 1 : 0);
  Uint midx = numendmarkers;
  const Float MINDIST = 0.05;
  FloatVec dist = 0;
  FloatVec dist_female = 0;
  Uint numdist = ch->second.markers.size() + (options->addendmarkers ? 1 : -1);
  if (numdist > 0) {
    dist = new Float[numdist];
    if (options->sexspecific)
      dist_female = new Float[numdist];
  }
  const Marker &firstmarker = string2marker[ch->second.markers.front()];
  if (options->addendmarkers) {
    assertinternal(!ch->second.markers.empty());
    dist[0] = firstmarker.location;
    if (options->sexspecific)
      dist_female[0] = firstmarker.location_female;
  }
  for (vector<string>::const_iterator mn = ch->second.markers.begin();
       mn != ch->second.markers.end() && next(mn) != ch->second.markers.end();
       mn++, midx++) {
    const Marker &marker = string2marker[*mn];
    const Marker &nextmarker = string2marker[*next(mn)];
    dist[midx] = nextmarker.location - marker.location;
    if (options->sexspecific)
      dist_female[midx] = nextmarker.location_female - marker.location_female;
  }
//  assertcond(options->markerdistzero || dist[midx] > 0, "Markers " + m->id +
//              " and " + m->next->id + " are in the same position " +
//              "(use \"MARKERDISTZERO on\" to allow)");
  if (options->addendmarkers) {
    const Marker &lastmarker = string2marker[ch->second.markers.back()];
    dist[ch->second.markers.size()] =
      max(ch->second.length - lastmarker.location, 0.0);
    if (options->sexspecific)
      dist_female[ch->second.markers.size()] =
        max(ch->second.length_female - lastmarker.location_female, 0.0);
  }
  if (!options->markerdistzero) {
    for (midx = 0;
         midx < ch->second.markers.size() + (options->addendmarkers ? 1 : -1);
         midx++) {
      if (dist[midx] == 0) dist[midx] = MINDIST;
      if (options->sexspecific)
        if (dist_female[midx] == 0) dist_female[midx] = MINDIST;
    }
  }
  if (options->sexspecific) {
    map.adddist(options->addendmarkers ? .0 : firstmarker.location, dist, 1);
    map.adddist(options->addendmarkers ? .0 : firstmarker.location_female,
                dist_female, 2);
  }
  else
    map.adddist(firstmarker.location, dist, 0);
  delete [] dist;
  if (options->sexspecific)
    delete [] dist_female;
  // Assign allele numbers to repeats and alleles to people
  FloatVec unif2;
  unif2 = new Float[2];
  unif2[0] = unif2[1] = .5;
  if (options->addendmarkers) {
    map.addmarker(0, 2, unif2, "START" + ch->second.id);
    vector<int> orig(2);
    orig[0] = 1;
    orig[1] = 2;
    map.loci.back().origalleles = orig;
  }

  midx = numendmarkers;
  Outfile controlfrq("control.frq");
  controlfrq.open();
  for (vector<string>::const_iterator mn = ch->second.markers.begin();
       mn != ch->second.markers.end(); mn++, midx++) {
    Marker &marker = string2marker[*mn];
    // Create frequencies
    for (String2PN::const_iterator pn = string2pn.begin();
         pn != string2pn.end(); pn++) {
      if (pn->second.genotyped()) {
        IntVec als = pn->second.get_rep(marker.idx);
        if (als != 0 && als[0] != options->unknownrepeat) {
          if (marker.rep2freq[als[0]] == 0.0) marker.addallele(als[0]);
          if (marker.rep2freq[als[1]] == 0.0) marker.addallele(als[1]);
        }
      }
    }
    if (!marker.controlsavailable) {
      warning("No control frequencies available for " + marker.id +
              " (using data as controls)");
      for (String2PN::const_iterator pn = string2pn.begin();
           pn != string2pn.end(); pn++) {
        IntVec als = pn->second.get_rep(marker.idx);
        if (pn->second.genotyped() && als != 0 &&
            als[0] != options->unknownrepeat) {
          assertinternal(als[1] != options->unknownrepeat);
          marker.rep2freq[als[0]] += 1.0;
          marker.rep2freq[als[1]] += 1.0;
        }
      }
    }
    // Map repeats into alleles
    marker.assignrep2allele();
    assertcond(marker.rep2freq.size() == marker.rep2allele.size(),
               marker.id + " incorrectly processed");
    // Add mapping from allegro alleles to original alleles
    vector<int> orig(marker.rep2allele.size());
    for (Int2int::iterator al = marker.rep2allele.begin();
         al != marker.rep2allele.end(); al++) {
      assertinternal(al->second <= int(marker.rep2allele.size()));
      orig[al->second - 1] = al->first;
    }
    map.loci.back().origalleles = orig;

    if (midx < map.loci.size()) {
      // Add marker to map
      FloatVec freq = marker.getfreq(&controlfrq);
      map.addmarker(midx, marker.rep2allele.size(), freq, marker.id);
      delete [] freq;
    }
  }

  controlfrq.close();
  if (options->addendmarkers) {
    map.addmarker(map.loci.size() - 1, 2, unif2, "END" + ch->second.id);
    vector<int> orig(2);
    orig[0] = 1;
    orig[1] = 2;
    map.loci.back().origalleles = orig;
  }

  // Write map
  Outfile mapfile("map");
  mapfile.open();
  assertinternal(mapfile.is_open());
  for (Uint m = numendmarkers; m < map.loci.size() - numendmarkers; m++)
    mapfile << ch->second.id << "\t" << map.loci[m].name << "\t"
            << map.loci[m].positionAvg() << "\n";
  mapfile.close();

  options->sexlinked = ch->second.type == SEXLINKED;
//   IntVec nogt;
//   nogt = new int[2];
//   nogt[0] = nogt[1] = options->unknownrepeat;
//   for (Family *fam = firstorig; fam != 0; fam = fam->next)
//     for (Person *p = fam->first; p != 0; p = p->next) {
//       // Set liability classes
//       p->liability = options->sexlinked ? 1 - p->sex : 0;
//       // Set genotypes for genotyped people
//       String2PN::iterator q = string2pn.find(p->id);
//       if (q != string2pn.end() && q->second.genotyped()) {
//         p->allocgenotypes(map.loci.size());
//         midx = numendmarkers;
//         vector<string>::const_iterator mn = ch->second.markers.begin();
//         while (midx < map.loci.size() - numendmarkers) {
//           assertinternal(mn != ch->second.markers.end());
//           Marker &marker = string2marker[*mn];
//           IntVec als = q->second.get_rep(marker.idx);
//           if (als == 0) als = nogt;
//           if (als[0] != options->unknownrepeat) {
//             Int2int::iterator fr = marker.rep2allele.find(als[0]);
//             assertinternal(fr != marker.rep2allele.end());
//             fr = marker.rep2allele.find(als[1]);
//             assertinternal(fr != marker.rep2allele.end());
//             assertinternal(marker.rep2allele[als[0]] != 0 &&
//                            marker.rep2allele[als[1]] != 0);
//             p->gen[0][midx] = marker.rep2allele[als[0]];
//             p->gen[1][midx] = marker.rep2allele[als[1]];
//           }
//           else {
//             p->gen[0][midx] = p->gen[1][midx] = ALLELEUNKNOWN;
//           }
//           // Increment midx and m
//           mn++;
//           midx++;
//         }
//       }
//     }
}

void Chromosome::add(const string &m) {
  assertcond(find(markers.begin(), markers.end(), m) == markers.end(),
             "Marker " + m + " is duplicated in map!");
  markers.push_back(m);
}

PN::~PN() {
  deletematrix(rep);
}

void PN::add(int idx, int r1, int r2) {
  while (idx >= nrep) {
    IntMat newrep;
    newrep = newmatrix<int>(nrep + repinc, 2);
    copyval(newrep[nrep], options->unknownrepeat, 2*repinc);
    if (nrep > 0) {
      copyvec(newrep[0], rep[0], 2*nrep);
      deletematrix(rep);
    }
    rep = newrep;
    nrep += repinc;
  }
  rep[idx][0] = r1;
  rep[idx][1] = r2;
}

FloatVec Marker::getfreq(ostream *out) {
  FloatVec freq;
  freq = new Float[rep2allele.size()];
  for (Int2int::iterator al = rep2allele.begin();
       al != rep2allele.end(); al++) {
    assertinternal(al->second > 0 && al->second - 1 < int(rep2allele.size()));
    freq[al->second - 1] = rep2freq[al->first];
    // Write control frequencies to file
    if (out != 0)
      (*out) << id << "\t" << al->first << "\t"
             << rep2freq[al->first] << "\t" << al->second << "\n";
  }
  assertcond(rep2freq.size() == rep2allele.size(),
             id + " incorrectly processed!");
  return freq;
}

void Marker::assignrep2allele() {
  // Find smallest unassigned repeat
  const int NOREPEAT = 9999999;
  int repeat = NOREPEAT;
  for (Int2float::iterator al = rep2freq.begin(); al != rep2freq.end(); al++)
    if (rep2allele.find(al->first) == rep2allele.end() &&
        al->first < repeat) repeat = al->first;
  a = rep2allele.size() + 1;
  if (repeat != NOREPEAT) {
    rep2allele[repeat] = a++;
    while (rep2freq.size() > rep2allele.size()) {
      repeat++;
      if (rep2freq.find(repeat) != rep2freq.end() &&
          rep2allele.find(repeat) == rep2allele.end())
        rep2allele[repeat] = a++;
      assertcond(repeat < 10000, string("Repeat ") + repeat + " too long!");
    }
  }
}
