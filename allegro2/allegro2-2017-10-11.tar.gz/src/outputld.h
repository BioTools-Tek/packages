#ifndef _OUTPUTLD
#define _OUTPUTLD
#include "basic.h"

void writepre(const string &filename, Family *firstfam, Map *m);
void writedat(const string &filename, Map *map);

#endif // _OUTPUTLD
