#ifndef _PAIRWISE
#define _PAIRWISE
#include "basic.h"

#include "cuddInt.h"

class Indexfounderallele {
public:
  UintVec descendants;
  BoolVec descendanthomozygous;
  Uint numdescendants;

  Indexfounderallele() :
      descendants(0), descendanthomozygous(0), numdescendants(0) {}
  void setmaxnum(Uint maxnum) {
    if (maxnum > 0) {
      descendants = new Uint[maxnum];
      descendanthomozygous = new bool[maxnum];
    }
    else {
      descendants = 0;
      descendanthomozygous = 0;
    }
  }
  ~Indexfounderallele() {
    delete [] descendants;
    delete [] descendanthomozygous;
  }

  void pushdescendant(Uint idx, bool homozygote) {
    descendants[numdescendants] = idx;
    descendanthomozygous[numdescendants++] = homozygote;
  }
  void popdescendant() {numdescendants--;}
};

template <class Founderallele>
class Pairwiseperson {
protected:
  Person *per;
  Pairwiseperson *father;
  Pairwiseperson *mother;

  DdNode *collectresults(DdManager *mgr, DdNode *qdd_00, DdNode *qdd_01,
                         DdNode *qdd_10, DdNode *qdd_11,
                         Uint Kf, Uint Km) const  {
    DdNode *result;
    DdNode *const mat_var = Km == 1 ? Cudd_addIthVar(mgr, per->matbitlevel) : 0;
    if (mat_var != 0) cuddRef(mat_var);
    DdNode *const pat_var = Kf == 1 ? Cudd_addIthVar(mgr, per->patbitlevel) : 0;
    if (pat_var != 0) cuddRef(pat_var);
    if (Km == 1 && Kf == 1) {
      DdNode *mat0 =
        qdd_10 == qdd_00 ? qdd_10 :
//         cuddUniqueInter(mgr, cuddI(mgr, per->matbitlevel), qdd_10, qdd_00);
        Cudd_addIte(mgr, mat_var, qdd_10, qdd_00);
      cuddRef(mat0);
      DdNode *mat1 =
        qdd_11 == qdd_01 ? qdd_11 :
//        cuddUniqueInter(mgr, cuddI(mgr, per->matbitlevel), qdd_11, qdd_01);
        Cudd_addIte(mgr, mat_var, qdd_11, qdd_01);
      cuddRef(mat1);
      result =
        mat0 == mat1 ? mat1 :
//         cuddUniqueInter(mgr, cuddI(mgr, per->patbitlevel), mat1, mat0);
        Cudd_addIte(mgr, pat_var, mat1, mat0);
      cuddRef(result);
//       cuddDeref(mat0);
//       cuddDeref(mat1);
      Cudd_RecursiveDeref(mgr, mat0);
      Cudd_RecursiveDeref(mgr, mat1);
    }
    else if (Km == 1) {
      result =
        qdd_10 == qdd_00 ? qdd_10 :
//         cuddUniqueInter(mgr, cuddI(mgr, per->matbitlevel), qdd_10, qdd_00);
        Cudd_addIte(mgr, mat_var, qdd_10, qdd_00);
      cuddRef(result);
    } else if (Kf == 1) {
      result =
        qdd_01 == qdd_00 ? qdd_01 :
//         cuddUniqueInter(mgr, cuddI(mgr, per->patbitlevel), qdd_01, qdd_00);
        Cudd_addIte(mgr, pat_var, qdd_01, qdd_00);
      cuddRef(result);
    } else {
      result = qdd_00;
      cuddRef(result);
    }
    assert(result != 0);

    if (mat_var != 0) Cudd_RecursiveDeref(mgr, mat_var);
    if (pat_var != 0) Cudd_RecursiveDeref(mgr, pat_var);

//     if (qdd_00 != 0) cuddDeref(qdd_00);
//     if (qdd_01 != 0) cuddDeref(qdd_01);
//     if (qdd_10 != 0) cuddDeref(qdd_10);
//     if (qdd_11 != 0) cuddDeref(qdd_11);
    if (qdd_00 != 0) Cudd_RecursiveDeref(mgr, qdd_00);
    if (qdd_01 != 0) Cudd_RecursiveDeref(mgr, qdd_01);
    if (qdd_10 != 0) Cudd_RecursiveDeref(mgr, qdd_10);
    if (qdd_11 != 0) Cudd_RecursiveDeref(mgr, qdd_11);

    cuddDeref(result);

    return result;
  }
public:
  Pairwiseperson *next;
  Founderallele *nod[2];
  Pairwiseperson(Person *p, Pairwiseperson *first) :
      per(p), father(0), mother(0), next(0) {
    if (p->founder()) {
      nod[0] = new Founderallele;
      nod[1] = new Founderallele;
    }
    else nod[0] = nod[1] = 0;

    Pairwiseperson *last = 0;
    for (Pairwiseperson *q = first; q != 0; q = q->next) {
      if (q->per == per->father) father = q;
      if (q->per == per->mother) mother = q;
      last = q;
    }
    if (last != 0) last->next = this;
  }
  ~Pairwiseperson() {
    if (per->founder()) {
      delete nod[0];
      delete nod[1];
    }
    delete next;
  }
};

#endif // _PAIRWISE
