#ifndef _CALCSCORE
#define _CALCSCORE
#include "calc.h"
#include "fmtout.h"
#include "files.h"

class Scoreperson;
class Foundercouple;

class Calcscore : public Calc {
protected:
  virtual void setupscorefamily(Family *fam) = 0;
  void calcscore(Foundercouple *fc, Uint &i, Family *fam);
  void calcscore(Foundercouple *fc, Uint &i, Family *fam, Cudd &mgr);
  virtual void calc(DoubleVec score, Family *fam) = 0;
  virtual ADD calc(Family *fam, Cudd &mgr) = 0;
  Calcscore(const string &sc) : Calc(sc) {}
public:
  virtual bool isdiscrete() const = 0;
  virtual void operator() (Family *fam);
  virtual void operator() (Family *fam, Cudd &mgr);
  virtual void printpairscores(Family */*fam*/) {}
};

class Calcqualitativescore : public Calcscore {
protected:
  Scoreperson *firstdesc;
  Scoreperson *first;
  IV uninformativemask;
  virtual void setupscorefamily(Family *fam);
  virtual void calc(DoubleVec score, Family *fam);
  virtual ADD calc(Family *fam, Cudd &mgr);
  Calcqualitativescore(const string &sc) : Calcscore(sc) {}
public:
  virtual bool isdiscrete() const {return true;}
  static Calcqualitativescore *getcalcqualitativescore(const string &sc);
};

class Calcparentspecificscore : public Calcqualitativescore {
protected:
  Double w_mm;
  Double w_mf;
  Double w_ff;

  Calcparentspecificscore(const string &sc, Double wmm, Double wmf,
                          Double wff) :
      Calcqualitativescore(sc), w_mm(wmm), w_mf(wmf), w_ff(wff) {}
  virtual void calc(DoubleVec score, Family *fam);
  virtual ADD calc(Family *fam, Cudd &mgr);
  static string description(const string &sc,
                            Double wmm, Double wmf, Double wff) {
    return sc + " " + Floattostring(wmm, 2) + " " + Floattostring(wmf, 2) +
      " " + Floattostring(wff, 2);
  }
public:
  virtual bool isdiscrete() const {return false;}
  virtual string describe() const {return description(id, w_mm, w_mf, w_ff);}
  static Calcparentspecificscore *getcalcparentspecificscore(const string &sc,
                                                             Double wmm,
                                                             Double wmf,
                                                             Double wff);
};

class Genpairsperson;

class Calcgenpairs : public Calcscore {
protected:
  Outfile pairscores;
  Genpairsperson *first;
  String2Bool informative;
  String2Double pair2weight1;
  String2Double pair2weight2;

  string pair2string(const string &a, const string &b) const;
  virtual void setupscorefamily(Family *fam);
  virtual void calc(DoubleVec score, Family *fam);
  virtual ADD calc(Family *fam, Cudd &mgr);
  Calcgenpairs(const string &sc);

  virtual void calcweights(Family *fam);

public:
  virtual bool isdiscrete() const {return false;}
  virtual void printpairscores(Family *fam);

  virtual void operator() (Family *fam);
  virtual void operator() (Family *fam, Cudd &mgr);

};

class Calcgenpairsfile : public Calcgenpairs {
protected:
  string filename;

  Calcgenpairsfile(const string &sc, const string &fn);

  virtual void calcweights(Family *fam);

public:
  static Calcgenpairsfile *getcalcgenpairsfile(const string &sc,
                                               const string &fn);
  virtual string describe() const {return id + " " + filename;}

};

class Genpairsperson_ps;

class Calcgenpairsfile_ps : public Calcscore {
protected:
  string filename;
  Genpairsperson_ps *first;
  String2Bool informative;
  String2Double pair2wmm;
  String2Double pair2wmf;
  String2Double pair2wff;

  virtual void setupscorefamily(Family *fam);
  virtual void calc(DoubleVec score, Family *);
  virtual ADD calc(Family *fam, Cudd &mgr);

  Calcgenpairsfile_ps(const string &sc, const string &fn);

  virtual void calcweights(Family *fam);

public:
  static Calcgenpairsfile_ps *getcalcgenpairsfile_ps(const string &sc,
                                                     const string &fn);
  virtual string describe() const {return id + " " + filename;}
  virtual bool isdiscrete() const {return false;}
};

class Kinship;

class Calcgenpairsregress : public Calcgenpairs {
public:
  const string trait;
  Double heritability;

  Calcgenpairsregress(const string &sc, Double her, const string &tr) :
      Calcgenpairs(sc), heritability(her), trait(tr) {}
  static string description(const string &cid, Double her, const string &tr)
    {return cid + " " + Floattostring(her, 2) +
       (tr == "" ? "" : " trait:" + tr);}

  Double kccor(Uint p1, Uint p2, Kinship *kinship);
  virtual void calcweights(Family *fam);

public:
  static Calcgenpairsregress *getcalcgenpairsregress(const string &sc,
                                                     Double het,
                                                     const string &tr);
  virtual string describe() const {return description(id, heritability, trait);}
};

class Calcgenpairsshared : public Calcgenpairs {
protected:
  const string trait;
  Double shared;
  Double variance;

  Float calcweight(Float ks, Float x1, Float x2);
  Calcgenpairsshared(const string &sc, Double shr, Double var,
                     const string &tr) :
      Calcgenpairs(sc), shared(shr), variance(var), trait(tr) {}
  static string description(const string &cid, Double shr, Double var,
                            const string &tr)
    {return cid + " " + Floattostring(shr, 2) +
       (var == 1 ? "" : " " + Floattostring(var, 2)) +
       (tr == "" ? "" : " trait:" + tr);}

  virtual void calcweights(Family *fam);

public:
  static Calcgenpairsshared *getcalcgenpairsshared(const string &sc, Double s,
                                                   Double v, const string &tr);
  virtual string describe() const {return description(id, shared, variance,
                                                      trait);}
};

class FindIBD;

class Calcgenpairsvc : public Calcgenpairs {
protected:
  const string trait;
  Double shared;
  Double sigma2_g;
  Double sigma2_d;
  static FindIBD *findIBD;

  void calcweight(Float p1, Float p2, Float x1, Float x2, Float &w1, Float &w2);
  Calcgenpairsvc(const string &sc, Double s, Double a, Double d,
                 const string &tr);
  static string description(const string &id, Double s, Double a, Double d,
                            const string &tr)
    {return id + " " + Floattostring(s, 2) +  " " + Floattostring(a, 2) + " " +
       Floattostring(d, 2) + (tr == "" ? "" : " trait:" + tr);}
  Float probpair(Float ks, Float x1, Float x2, Float pi);

  virtual void calcweights(Family *fam);

public:
  static Calcgenpairsvc *getcalcgenpairsvc(const string &sc, Double s2,
                                           Double s, Double a, Double d,
                                           const string &tr);
  virtual string describe() const
    {return description(id, shared, sigma2_g, sigma2_d, trait);}
};


#endif // _CALCSCORE
