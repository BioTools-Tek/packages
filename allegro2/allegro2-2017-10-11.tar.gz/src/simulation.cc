#include "simulation.h"
#include "files.h"
#include "peel.h"
#include "singlelocus.h"
#include "vecutil.h"
#include "haldane.h"
#include "map.h"
#include "family.h"
#include "trait.h"
#include "options.h"
#include "rgamma.h"

Double runif() {
  return erand48(options->seed);
}

void Simulation::setfoundergenotypes(const Map &map) {
  for (Uint gam = 0; gam < map.loci.size(); gam++) {
    Uint a = 1;
    for (Person *p = fam->first; p != fam->firstdescendant; p = p->next) {
      if (perfectdata) {
        p->gen[0][gam] = a++;
        if (!options->sexlinked || p->sex == FEMALE) p->gen[1][gam] = a++;
        else p->gen[1][gam] = p->gen[0][gam];
      }
      else {
        p->gen[0][gam] = map.randomallele(gam);
        if (!options->sexlinked || p->sex == FEMALE)
          p->gen[1][gam] = map.randomallele(gam);
        else p->gen[1][gam] = p->gen[0][gam];
      }
    }
  }
}

void Simulation::simulate(Family *famp, const Map &map) {
//  if (perfectdata)
    for (Person *p = famp->first; p != 0; p = p->next)
      if (!p->genotyped())
        p->allocgenotypes(map.loci.size());

  fam = famp;
  if (diseaseloc) {
    zero(L, fam->numiv());
    ESgraph g = ESgraph(*fam, trait);
    g.peel(L);
    Double cumsum = 0.0;
    for (IV w = 0; w < fam->numiv(); w++) {
      cumsum += L[w];
      L[w] = cumsum;
    }
  }
  ios::openmode mode = firstfam ? ios::out | ios::trunc : ios::out | ios::app;
  firstfam = false;
  for (int s = 0; s < nsimulations; s++) {
    string postfix = "";
    for (Uint i = Uint(log10(Double(s + 1)));
         i < Uint(log10(Double(nsimulations))); i++)
      postfix += "0";
    string filename = options->prefile[0] + "." + postfix + (s + 1);
    ofstream out(filename.c_str(), mode);
    for (int i = 0; i < nrepeats; i++) {
      // pick an IV at the disease locus
      IV v;
      if (diseaseloc && runif() >= hetrogen) {
        const Double r = runif()*L[fam->numiv() - 1];
        for (v = 0; v < fam->numiv() && L[v] <= r; v++);
      }
      else v = IV(nrand48(options->seed)) % fam->numiv();
      // simulate founder alleles
      setfoundergenotypes(map);
      // simulate from disease locus
      simulatefromdiseaselocus(map, v);
      // print out results
      for (Person *p = fam->first; p != 0; p = p->next) {
        out << fam->id;
        if (nrepeats > 1) out << "-" << i + 1;
        out <<  "  " << p->id << " "
            << (p->father == 0 ? "0" : p->father->id) << " "
            << (p->mother == 0 ? "0" : p->mother->id) << " "
            << p->sex + 1 << " " << p->dstat;
        for (Uint gam = 0; gam < map.loci.size(); gam++)
          out << " " << p->gen[0][gam] << " " << p->gen[1][gam];
        out << "\n";
      }
      out.flush();
    }
  }
}

void Simulation::simulatefromdiseaselocus(const Map &map, IV v) {
  if (diseaseloc) {
    // find the marker on the left of the disease locus
    Uint leftmarker = 0;
    if (diseaseloc) {
      for (; leftmarker < map.loci.size(); leftmarker++)
        if (map.loci[leftmarker].positionAvg() >= diseasepos) break;
      if (map.loci[leftmarker].positionAvg() > diseasepos) {
        assertinternal(leftmarker > 0);
        leftmarker--;
      }
    }

    // Calculate sex-specific disease positions
    Float diseasepos_male;
    Float diseasepos_female;
    if (diseasepos < map.loci[0].positionAvg() ||
        diseasepos > map.loci[map.loci.size() - 1].positionAvg())
      diseasepos_male = diseasepos_female = diseasepos;
    else {
      Float d = ((diseasepos - map.loci[leftmarker].positionAvg())/
                 (map.loci[leftmarker + 1].positionAvg() -
                  map.loci[leftmarker].positionAvg()));
      diseasepos_male = map.loci[leftmarker].positionMale() +
        d*(map.loci[leftmarker + 1].positionMale() -
           map.loci[leftmarker].positionMale());
      diseasepos_female = map.loci[leftmarker].positionFemale() +
        d*(map.loci[leftmarker + 1].positionFemale() -
           map.loci[leftmarker].positionFemale());
    }

    // Initialize crossover process
    FloatVec left_paticd;
    FloatVec left_maticd;
    FloatVec right_paticd;
    FloatVec right_maticd;
    left_paticd = new Float[fam->numnf];
    left_maticd = new Float[fam->numnf];
    right_paticd = new Float[fam->numnf];
    right_maticd = new Float[fam->numnf];
    Uint i = 0;
    for (Person *p = fam->firstdescendant; p != 0; p = p->next, i++) {
      initicd(diseasepos_male, nu_male, left_paticd[i], right_paticd[i]);
      initicd(diseasepos_female, nu_female, left_maticd[i], right_maticd[i]);
    }
    // Simulate left
    inittrans(v);
    simulateicd(map, leftmarker, left_paticd, left_maticd, LEFT);
    // Simulate right
    inittrans(v);
    simulateicd(map, leftmarker + 1, right_paticd, right_maticd, RIGHT);
    delete [] left_paticd;
    delete [] left_maticd;
    delete [] right_paticd;
    delete [] right_maticd;
  }
  else {
    // Initialize crossover process
    FloatVec paticd;
    FloatVec maticd;
    paticd = new Float[fam->numnf];
    maticd = new Float[fam->numnf];
    Uint i = 0;
    for (Person *p = fam->firstdescendant; p != 0; p = p->next, i++) {
      paticd[i] = 100.*rgammamix_end(nu_male);
      maticd[i] = 100.*rgammamix_end(nu_female);
    }
    inittrans(v);
    simulateicd(map, 0, paticd, maticd, RIGHT);
    delete [] paticd;
    delete [] maticd;
  }
}

void Simulation::simulatemarker(const Map &map, int gam) {
  // set founder node alleles to the value at marker gam
  for (Person *p = fam->first; p != fam->firstdescendant; p = p->next) {
    p->nod[0]->allele = p->gen[0][gam];
    p->nod[1]->allele = p->gen[1][gam];
  }
  // set people's nodes
  Uint i = 0;
  for (Person *p = fam->firstdescendant; p != 0; p = p->next, i++) {
    p->nod[1] = p->mother->nod[mattrans[i]];
    if (options->sexlinked && p->sex == MALE) 
      p->nod[0] = p->nod[1];
    else
      p->nod[0] = p->father->nod[pattrans[i]];
  }
  // set people's alleles
  for (Person *p = fam->first; p != 0; p = p->next) {
    if (perfectdata || (p->genotyped() && runif() <= yield)) {
      if (runif() > errorrate) {
        p->gen[0][gam] = p->nod[0]->allele;
        p->gen[1][gam] = p->nod[1]->allele;
      }
      else {
        p->gen[0][gam] = map.randomallele(gam);
        p->gen[1][gam] = map.randomallele(gam);
      }
    }
    else p->gen[0][gam] = p->gen[1][gam] = ALLELEUNKNOWN;
  }
}

void Simulation::initicd(Double diseasepos, Double nu,
                         Float &left_icd, Float &right_icd) {
//   Double r = runif();
//   Double d = 100*rgammamix(nu);
//   left_icd = diseasepos - r*d;
//   right_icd = diseasepos + (1 - r)*d;
  const Double l = 100.*rgammamix_end(nu);
  Double r;
  do {
    r = 100.*rgammamix(nu) - l;
  } while (r < 0);
  left_icd = diseasepos - l;
  right_icd = diseasepos + r;
}

void Simulation::inittrans(IV v) {
  // set non founder nodes to their value according to v
  Uint i = 0;
  for (Person *p = fam->firstdescendant; p != 0; p = p->next, i++) {
    pattrans[i] = (p->patmask & v) > 0 ? 1 : 0;
    mattrans[i] = (p->matmask & v) > 0 ? 1 : 0;
  }
}

void Simulation::simulateicd(const Map &map, Uint from,
                             FloatVec paticd, FloatVec maticd, int dir) {
  for (int gam = from; gam >= 0 && gam < int(map.loci.size()); gam += dir) {
    // Simulate crossover process
    int i = 0;
    for (Person *p = fam->firstdescendant; p != 0; p = p->next, i++) {
      while (dir*paticd[i] < dir*map.loci[gam].positionMale()) {
        paticd[i] += dir*100*rgammamix(nu_male);
        pattrans[i] ^= 1;
      }
      while (dir*maticd[i] < dir*map.loci[gam].positionFemale()) {
        maticd[i] += dir*100*rgammamix(nu_female);
        mattrans[i] ^= 1;
      }
    }
    // Finally simulate people's genotypes
    simulatemarker(map, gam);
  }
}
