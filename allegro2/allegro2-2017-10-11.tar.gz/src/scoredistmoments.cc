#include "files.h"
#include "scoredistmoments.h"
#include "family.h"
#include "calcscore.h"
#include "cuddInt.h"
#include "cuddutil.h"

Scoredistmoments::Scoredistmoments(const string &p, Uint deg) :
    Scoredist(p, deg) {}

Scoredistmoments::~Scoredistmoments() {
  while (!familydata.empty()) {
    delete familydata.back();
    familydata.pop_back();
  }
}

void Scoredistmoments::setuniformstats(DdNode *S, Familydata *famdat) {
  if (cuddIsConstant(S)) {
    const double val = cuddV(S);
    famdat->nullmean[0] += val;
    famdat->nullsd[0] += val*val;

    if (val < famdat->minvalue) famdat->minvalue = val;
    if (val > famdat->maxvalue) famdat->maxvalue = val;
  }
  else {
    setuniformstats(cuddT(S), famdat);
    setuniformstats(cuddE(S), famdat);
  }
}

void Scoredistmoments::setuniformmoments(DdNode *S, Familydata *famdat) {
  if (cuddIsConstant(S)) {
    const double val = (cuddV(S) - famdat->nullmean[0])/famdat->nullsd[0];

    double valp = val*val*val;
    for (Uint deg = 2; deg < degree; deg++) {
      famdat->nullvalue[0][deg] += valp;
      valp *= val;
    }
  }
  else {
    setuniformmoments(cuddT(S), famdat);
    setuniformmoments(cuddE(S), famdat);
  }
}

void Scoredistmoments::nextfam(bool mtbdd, Uint pos, DoubleVec p0) {
  if (pos == 0) familydata.push_back(new Familydata(this));
  Familydata *famdat = familydata.back();

  const IV numiv = curfamily()->numiv();
  const IV numscores = numiv*(1 << curfamily()->nasymmetricfoundercouples());

  famdat->minvalue = 1e300;
  famdat->maxvalue = -1e300;

  if (mtbdd) {
    for (Uint a = 0; a < (1U << curfamily()->nasymmetricfoundercouples()); a++)
      setuniformstats(calcscore->S[a].getNode(), famdat);

    famdat->nullmean[pos] /= double(numscores);
    famdat->nullsd[pos] /= double(numscores);

    famdat->nullsd[pos] = (famdat->nullsd[pos] -
                           famdat->nullmean[pos]*famdat->nullmean[pos]);
    famdat->nullsd[pos] =  (famdat->nullsd[pos] < 1e-8 ? 0 :
                            sqrt(famdat->nullsd[pos]));

    famdat->nullvalue[pos][0] = 0;
    famdat->nullvalue[pos][1] = 1;


    if (famdat->nullsd == 0)
      for (Uint deg = 2; deg < degree; deg++)
        famdat->nullvalue[pos][deg] = 0;
    else {
      for (Uint a = 0; a < (1U << curfamily()->nasymmetricfoundercouples());
           a++)
        setuniformmoments(calcscore->S[a].getNode(), famdat);

      for (Uint deg = 2; deg < degree; deg++)
        famdat->nullvalue[pos][deg] /= Double(numscores);
    }
  }
  else {
    for (IV v = 0; v < numscores; v++) {
      Double val = calcscore->vec[v];
      Double valp = val;

      if (p0 != 0)
        valp *= p0[v % numiv];
      famdat->nullmean[pos] += valp;
      famdat->nullsd[pos] += valp*val;

      if (pos == 0) {
        if (val < famdat->minvalue) famdat->minvalue = val;
        if (val > famdat->maxvalue) famdat->maxvalue = val;
      }
    }
    if (isnullconstant()) {
      famdat->nullmean[pos] /= Double(numscores);
      famdat->nullsd[pos] /= Double(numscores);
    }
    famdat->nullsd[pos] = (famdat->nullsd[pos] -
                           famdat->nullmean[pos]*famdat->nullmean[pos]);
    famdat->nullsd[pos] =  (famdat->nullsd[pos] < 1e-8 ? 0 :
                            sqrt(famdat->nullsd[pos]));

    famdat->nullvalue[pos][0] = 0;
    famdat->nullvalue[pos][1] = 1;
    if (famdat->nullsd[pos] == 0)
      for (Uint deg = 2; deg < degree; deg++)
        famdat->nullvalue[pos][deg] = 0;
    else {
      for (IV v = 0; v < numscores; v++) {
        const Double val = (calcscore->vec[v] -
                            famdat->nullmean[pos])/famdat->nullsd[pos];
        Double valp = val*val*val;

        if (p0 != 0)
          valp *= p0[v % numiv];
        for (Uint deg = 2; deg < degree; deg++) {
          famdat->nullvalue[pos][deg] += valp;
          valp *= val;
        }
      }
    }
    if (isnullconstant())
      for (Uint deg = 2; deg < degree; deg++)
        famdat->nullvalue[pos][deg] /= Double(numscores);
  }
}

void Scoredistmoments::set(FloatVec pv, Uint pos) {
  Familydata *famdat = familydata.back();
  Uint nullpos = (isnullconstant() ? 0 : pos);
  if (famdat->nullsd[nullpos] == 0) return;
  const IV numiv = curfamily()->numiv();

  for (Uint a = 0; a < (Uint(1) << curfamily()->nasymmetricfoundercouples());
       a++) {
    DoubleVec sv = calcscore->vec + a*numiv;
    for (IV v = 0; v < numiv; v++) {
      Double valp = pv[v];
      if (valp <= .0) continue;

      Double val = (sv[v] - famdat->nullmean[nullpos])/famdat->nullsd[nullpos];
      valp *= val;
      if (valp != .0)
        for (Uint deg = 0; deg < degree; deg++) {
          famdat->value[pos][deg] += valp;
          valp *= val;
        }
    }
  }

  if (curfamily()->nasymmetricfoundercouples() > 0) {
    const Double fac =
      1./Double(1 << curfamily()->nasymmetricfoundercouples());
    for (Uint deg = 0; deg < degree; deg++)
      famdat->value[pos][deg] *= fac;
  }
}

void Scoredistmoments::setmoments(DdNode *S, int S_parent_level, DdNode *pv,
                                  double inv_sum_pv, DdManager *mgr,
                                  Familydata *famdat, Uint pos,
                                  CuddCacheN_D &sum_cache) {
  if (cuddIsConstant(S)) {
    const double val = (cuddV(S) - famdat->nullmean[0])/famdat->nullsd[0];
    double valp = ((IV(1) << (mgr->size - S_parent_level))*
                   sum(mgr, pv, sum_cache)*inv_sum_pv*val);

    if (valp != .0)
      for (Uint deg = 0; deg < degree; deg++) {
        famdat->value[pos][deg] += valp;
        valp *= val;
      }
  }
  else {
    const Uint S_lvl = cuddI(mgr, S->index);
    const Uint pv_lvl = cuddI(mgr, pv->index);
    Uint index;
    DdNode *S_v, *S_vn, *pv_v, *pv_vn;
    if (S_lvl <= pv_lvl) {
      index = S->index;
      S_v = cuddT(S);
      S_vn = cuddE(S);
    }
    else {
      index = pv->index;
      S_v = S_vn = S;
    }
    if (pv_lvl <= S_lvl) {
      pv_v = cuddT(pv);
      pv_vn = cuddE(pv);
    }
    else {
      pv_v = pv_vn = pv;
    }

    setmoments(S_v, S_lvl, pv_v, inv_sum_pv, mgr, famdat, pos, sum_cache);
    setmoments(S_vn, S_lvl, pv_vn, inv_sum_pv, mgr, famdat, pos, sum_cache);
  }
}

void Scoredistmoments::set(ADD &pv, double sum_pv, Uint pos) {
  Familydata *famdat = familydata.back();
  if (famdat->nullsd == 0) return;
  for (Uint a = 0; a < (1U << curfamily()->nasymmetricfoundercouples()); a++) {
    DdManager *mgr = pv.manager()->getManager();
    setmoments(calcscore->S[a].getNode(), 0, pv.getNode(), 1./sum_pv,
               mgr, famdat, pos, CuddCacheManager::getCacheN_D("sum", mgr));
  }
}

void Scoredistmoments::reset(Uint np) {
  while (!familydata.empty()) {
    delete familydata.back();
    familydata.pop_back();
  }
  npos = np;
}

void Scoredistmoments::getresults(DoubleMat *value, DoubleMat *nullvalue,
                                  DoubleMat nullmean, DoubleMat nullsd,
                                  Uint deg, DoubleVec minvalue,
                                  DoubleVec maxvalue) {
  for (Uint pos = 0; pos < npos; pos++)
    for (Uint fam = 0; fam < familydata.size(); fam++)
      copyvec(value[fam][pos], familydata[fam]->value[pos], deg);

  for (Uint pos = 0; pos < nnulldist(); pos++) {
    for (Uint fam = 0; fam < familydata.size(); fam++) {
      copyvec(nullvalue[pos][fam], familydata[fam]->nullvalue[pos], deg);
      nullmean[pos][fam] = familydata[fam]->nullmean[pos];
      nullsd[pos][fam] = familydata[fam]->nullsd[pos];
    }
  }

  for (Uint fam = 0; fam < familydata.size(); fam++) {
    minvalue[fam] = familydata[fam]->minvalue;
    maxvalue[fam] = familydata[fam]->maxvalue;
  }
}

void Scoredistmoments::skipfam() {
  if (!familydata.empty()) {
    delete familydata.back();
    familydata.pop_back();
  }
}
