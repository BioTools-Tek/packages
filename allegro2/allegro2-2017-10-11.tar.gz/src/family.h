#ifndef _FAMILY
#define _FAMILY
#include "basic.h"

class Person;
class Foundercouple;

class Plist {
public:
  Plist(Person *q, Plist *ch) : p(q), next(ch) {};
  ~Plist() { delete next; };
  Uint length() {return 1 + (next == 0 ? 0 : next->length());}
  Person *p;
  Plist *next;
};

class Node;

class Person {
  friend class Family;
public:
  Person(const string& id,    // Create person with no parents
         Sex sx, Diseasestatus ds, Uint liab, bool hastraitvalue);
  Person(const Person &per);
  ~Person();
  Person *next;          // pointer to next person in family
  string id;
  bool founder() const
    {return mother == 0/* && father == 0*/;}
  void getspouses(Person *&s1, Person *&s2) const; // Finds first two spouses
  Sex sex;
  Diseasestatus dstat; // Can be changed to UNKNOWN if uninformative
  Diseasestatus origdstat; // The dstat reported in prefile/affectionfile

  bool phenotyped;

  Uint nmrk;        // Number used by haplotyping alg
  Uint liability;
  Allele *gen[2];        // one pair pr. marker (0,0) = unknown
  bool genotyped() const {return gen[0] != 0;}
  bool genotyped(Uint gam) const {return genotyped() && gen[0][gam] != 0;}
  bool genotyped(const vector<Uint> &markers) const {
    if (!genotyped()) return false;
    for (Uint gam = 0; gam < markers.size(); gam++)
      if (genotyped(markers[gam]))
        return true;
    return false;
  }
  Person *father;        // 0 = no father
  Person *mother;        // 0 = no mother
  Node *nod[2];          // nodes in graphs (in findq)
  IV mask;     // mask for inher. vec. bits of all meioses in person
  IV patmask;  // mask for paternal inheritance vector bit
  IV matmask;  // mask for maternal inheritance vector bit
  IV lastbit;  // last bit in mask ((mask + lastbit)/2 = first bit)
  Uint patbitlevel;
  Uint matbitlevel;
  bool removepatbit;
  bool removematbit;
  Plist *children;    // list of children
  void setgenotypes(Allele *g0, Allele *g1, Uint nm);
  void allocgenotypes(Uint nm);
  Foundercouple *fc; // Pointer is set for founder couples, and their children

  static const Uint FIXEDBIT = Uint(-1);

  bool hasaffecteddescendants(bool strict) {
    if (origdstat == AFFECTED && !strict) return true;
    for (Plist *c = children; c != 0; c = c->next)
      if (c->p->hasaffecteddescendants(false)) return true;
    return false;
  }
  bool hasphenotypeddescendants(bool strict) {
    if (origdstat != UNKNOWN && !strict) return true;
    for (Plist *c = children; c != 0; c = c->next)
      if (c->p->hasphenotypeddescendants(false)) return true;
    return false;
  }
  bool hasgenotypeddesc(Uint gam) const;
  bool hasgenotypeddesc(const vector<Uint> &markers) const {
    for (Uint gam = 0; gam < markers.size(); gam++)
      if (hasgenotypeddesc(markers[gam]))
        return true;
    return false;
  }

  bool isancestorof(Person *p) const;
  bool isrelatedto(Person *p) const;

  void print() const;

protected:
  Uint nmkr;        // number of markers that this person has genotype info on
  void addparents(Person *fath, Person *moth); // Add parents
  Uint visit(); // used by connected
  Uint visitup();
  Uint visitdown();
  Uint visitchildren();
  Uint visitparents();
  bool ishodgeinformativeup(Uint ngen);
  bool ishodgeinformativedown(Uint ngen);

  void init(const string& id, Sex sx);
  void sort(bool down, Person **last);
  void addchild(Person *c);
  void removechild(Person *p);
  void removechildren();
  bool visitedup;     // true after visitup called
  bool visiteddown;   // true after visitdown called
  bool processed;     // used by sort
};

class Foundercouple {
public:
  Person *husband;
  Person *wife;
  IV mask;
  IV childrenmask;
  Foundercouple *next;
  IV lastgcbit;
  IV bitbeforefirstgcbit;
  inline IV lastcbit() const
    {return husband->lastbit;}
  inline IV pi(IV v) {
    Uint shift = POPCOUNT(wife->mask);
    return (v & ~childrenmask) | ((wife->mask & v) >> shift) |
      ((husband->mask & v) << shift);
  }
  void swapdstat();
  bool asymmetric() const;

  Foundercouple(Person *h, Person *w, Foundercouple *n);
};

class Kinship;

class Family {
public:
  Family(const string &id, Uint popidx = 0); // Create empty family, no members
  Family(const Family &fam);
  ~Family();
  void organize(const vector<string> &faid, const vector<string> &moid);
  void organize();
  void setup();
  string id;
  Family *next;         // next family
  Person *first;        // first person in family
  Foundercouple *firstfoundercouple;
  Person *firstdescendant;
  Uint num;           // number of members
  Uint numnf;         // number of descendants, m
  Uint numf;          // number of founders, f (num = m + f)
  IV numiv() const {return IV(1) << numbits;} // number of inheritance vectors
  Uint numbits;       // log2(numiv)
  Uint populationindex; // index of population that this family
                        // belongs to
  Uint numfc;
  IV mask;
  IV lastfounderbit;  // the last bit corresponding to a meisois in a founder
  Person *addperson(const string& pid, Sex sex, Diseasestatus ds,
                    Uint liab, bool hastraitvalue);
  Person *addperson(Person *p, bool addpar = true);
  void removeperson(Person *p);
  void removeuninformativeperson(Person *p);
  Uint nasymmetricfoundercouples() const;
  void countbits();
  Kinship *kinship;
  void calckinship();
  Uint hodgeninfm(); // counts number of informative affecteds for Sue Hodge's
                     // weighting scheme
  void pseudonull(DoubleVec p0); // Calculates the prior IV
                                 // distribution at the start of the
                                 // pseudoautosomal chromsome region
  Uint countinformative() const;

  void print() const;

  void createmasks();    // used by Fouriertransform of T
protected:
  void addbit(IV &j, IV &partransmask, IV &parmask);
  bool hasinformativerelatives(Person *p);
  Uint countinformativerelatives(Person *q);
  Person *findperson(const string& id); // Return pointer to person
  // with given id
  void init();
  void putfoundersfirst();
  bool phenotypesconnected();
  bool connected();      // return true if family connected
  void sort();           // sorts so that children come after parents
                         // Also finds num, mumf, numnf, numiv.
  void trim(); // Removes uninformative people from family
  void findfoundercouples();
  string genpar(int nr);
  void splitunconnectedphenotypes();
  void removeuninformativephenotypes();
  void split();
  void findorinsert(Person *p);

  Person *last;         // pointer to last person added to pedigree
                        // not maintained after last call to addperson
  Person *lastfounder;  // pointer to last founder
  Uint ngenpar;
};

#endif // _FAMILY
