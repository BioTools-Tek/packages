#include "findnormal.h"
#include "warning.h"
#include "vecutil.h"
#include "kinship.h"
#include "family.h"
#include "traitdata.h"

FindNormalLoglik::~FindNormalLoglik() {
  cleanup();
  delete [] traitvalues;
}

Uint FindNormalLoglik::nqtl(Family *fam, const string &tr) const {
  Uint n = 0;
  for (Person *p = fam->first; p != 0; p = p->next)
    if (traitdata->hastraitvalue(p->id, tr))
      n++;
  return n;
}

void FindNormalLoglik::calcloglik(Family *fam, DoubleVec S, Plist *pl, IV v,
                                  Uint pi, Double log_det, Double xEx,
                                  Double sigma2, Double shared,
                                  Double sigma2_g, Double sigma2_d,
                                  const string &tr) {
  if (pl == 0) {
//    S[v] = pow(2*M_PI, -Double(fam->nqtl)/2.0)*exp(-.5*xEx)/sqrt(det);
    S[v] = -.5*(xEx + log_det);
  }
  else {
    Person *p = pl->p;
    IV Kf = p->patmask ? 1 : 0;
    IV Km = p->matmask ? 1 : 0;

    for (IV K1 = 0; K1 <= Km; K1++) {
      if (K1) v += p->matmask;
      if (p->mother != 0) p->nod[1] = p->mother->nod[K1];
      for (IV K0 = 0; K0 <= Kf; K0++) {
        if (K0) v += p->patmask;
        if (p->father != 0) p->nod[0] = p->father->nod[K0];
        Uint newpi = pi;
        Double newdet = log_det;
        Double newxEx = xEx;
        if (traitdata->hastraitvalue(p->id, tr)) {
          newpi++;

          y[pi] = traitvalues[pi];
//          assertinternal(finite(y[pi]));
          Uint qi = 0;
          for (Person *q = fam->first; qi < pi; q = q->next)
            if (traitdata->hastraitvalue(q->id, tr)) {
              Uint oibd = 1;
              if (p->nod[0] != q->nod[0] && p->nod[0] != q->nod[1] &&
                  p->nod[1] != q->nod[0] && p->nod[1] != q->nod[1])
                oibd = 0;
              else if (p->nod[0] == q->nod[0] && p->nod[1] == q->nod[1] ||
                       p->nod[0] == q->nod[1] && p->nod[1] == q->nod[0])
                oibd = 2;

              L[pi][qi] = fam->kinship->getkinship(p->nmrk, q->nmrk)*shared +
                oibd*sigma2_g/2.0 + (oibd == 2 ? sigma2_d : 0);
              for (Uint k = 0; k < qi; k++) L[pi][qi] -= L[pi][k]*L[qi][k];
              L[pi][qi] /= L[qi][qi];

//              assertinternal(finite(y[qi]));
              y[pi] -= L[pi][qi]*y[qi];
//              assertinternal(finite(y[pi]));

              qi++;
            }

          L[pi][pi] = sigma2 + shared + sigma2_g + sigma2_d;
          for (Uint k = 0; k < pi; k++) L[pi][pi] -= L[pi][k]*L[pi][k];
          newdet += log(L[pi][pi]);
          L[pi][pi] = sqrt(L[pi][pi]);
          y[pi] /= L[pi][pi];
          newxEx += y[pi]*y[pi];
        }
        calcloglik(fam, S, pl->next, v, newpi, newdet, newxEx, sigma2, shared,
                   sigma2_g, sigma2_d, tr);
      }
      v &= ~p->patmask;
    }
  }
}

bool FindNormalLoglik::hasphenotypeddesc(Person *p, const string &tr) const {
  bool res = false;
  for (Plist *c = p->children; c != 0 && !res; c = c->next) {
    res |= traitdata->hastraitvalue(c->p->id, tr);
    if (!res) res |= hasphenotypeddesc(c->p, tr);
  }
  return res;
}

void FindNormalLoglik::extracttraitvalues(Family *fam, const string &tr) {
  delete [] traitvalues;
  traitvalues = new Double[nqtl(fam, tr)];
  Uint pi = 0;
  for (Person *p = fam->first; p != 0; p = p->next)
    if (traitdata->hastraitvalue(p->id, tr)) {
      traitvalues[pi] = traitdata->gettraitvalue(p->id, tr);
      pi++;
    }
}

void FindNormalLoglik::initialize(Family *fam, const string &tr) {
  fam->calckinship();
  const Uint nq = nqtl(fam, tr);
  if (nq > curnqtl) {
    cleanup();
    curnqtl = nq;
    // Alloc ibd and E
    ibd = newsymmetricmatrix<Uint>(nq);
    E = newsymmetricmatrix<Double>(nq);
    L = newsymmetricmatrix<Double>(nq);
    y = new Double[nq];
  }
  extracttraitvalues(fam, tr);
}

void FindNormalLoglik::cleanup() {
  deletematrix(ibd);
  deletematrix(E);
  deletematrix(L);
  delete [] L;
  delete [] y;
}

void FindNormalLoglik::calc(Family *fam, DoubleVec S, Double sigma2,
                            Double shared, Double sigma2_g, Double sigma2_d,
                            const string &tr) {
  initialize(fam, tr);
  // Throw out ungenotyped leaves
  Plist *firstper = 0, *lastper = 0;
  Uint uninformativemask = 0;
  for (Person *p = fam->first; p != 0; p = p->next)
    if (p->children != 0 && hasphenotypeddesc(p, tr) ||
        traitdata->hastraitvalue(p->id, tr)) {
      if (firstper == 0) lastper = firstper = new Plist(p, 0);
        else {
          lastper->next = new Plist(p, 0);
          lastper = lastper->next;
        }
    } else uninformativemask |= p->patmask | p->matmask;
  // Calculate loglik
  calcloglik(fam, S, firstper, 0, 0, 0, 0.0, sigma2, shared,
             sigma2_g, sigma2_d, tr);
  delete firstper;
  // Fill in results for all IV's
  expandiv(S, uninformativemask, fam->numiv());
}

Double FindNormalLoglik::calc(Family *fam, DoubleVec ibd1, DoubleVec ibd2,
                              Double sigma2, Double shared, Double sigma2_g,
                              Double sigma2_d, const string &tr) {
  initialize(fam, tr);
  // Calculate E(pihat)
  Uint pi = 0;
  Uint ibdindex = 0;
  for (Person *p = fam->first; p != 0; p = p->next)
    if (traitdata->hastraitvalue(p->id, tr)) {
      Uint qi = 0;
      for (Person *q = fam->first; pi > qi; q = q->next) {
        assertinternal(p != q);
        if (traitdata->hastraitvalue(q->id, tr)) {
          E[pi][qi] = (fam->kinship->getkinship(p->nmrk, q->nmrk)*shared +
                       (ibd1[ibdindex]/2.0 + ibd2[ibdindex])*sigma2_g +
                       ibd2[ibdindex]*sigma2_d);
          qi++;
          ibdindex++;
        }
      }
      E[pi][pi] = sigma2 + shared + sigma2_g + sigma2_d;
      pi++;
    }

  Double logdet = 0.0;
  Double xEx = 0.0;
  const Uint nq = nqtl(fam, tr);
  for (Uint j = 0; j < nq; j++) {
    for (Uint i = 0; i < j; i++) {
      L[j][i] = E[j][i];
      for (Uint k = 0; k < i; k++)
        L[j][i] -= L[j][k]*L[i][k];
      L[j][i] /= L[i][i];
    }
    L[j][j] = E[j][j];
    y[j] = traitvalues[j];
    for (Uint k = 0; k < j; k++) {
      L[j][j] -= L[j][k]*L[j][k];
      y[j] -= L[j][k]*y[k];
    }
    logdet += log(L[j][j]);
    L[j][j] = sqrt(L[j][j]);
    y[j] /= L[j][j];
    xEx += y[j]*y[j];
  }
  return -.5*(logdet + xEx);
}
