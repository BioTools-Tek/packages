#include "calcscore.h"
#include "findscore.h"
#include "files.h"
#include "options.h"
#include "vecutil.h"
#include "genpairs.h"
#include "kinship.h"
#include "findibd.h"
#include "traitdata.h"

///////////////////////////////////////////////////////////////////////////
// Calcscore
void Calcscore::calcscore(Foundercouple *fc, Uint &i, Family *fam) {
  if (fc == 0) {
    calc(vec + i*fam->numiv(), fam);
    i++;
  }
  else {
    calcscore(fc->next, i, fam);
    if (fc->asymmetric()) {
      fc->swapdstat();
      calcscore(fc->next, i, fam);
      fc->swapdstat();
    }
  }
}

void Calcscore::calcscore(Foundercouple *fc, Uint &i, Family *fam, Cudd &mgr) {
  if (fc == 0) {
    S.push_back(calc(fam, mgr));
    i++;
  }
  else {
     calcscore(fc->next, i, fam, mgr);
     if (fc->asymmetric()) {
       fc->swapdstat();
       calcscore(fc->next, i, fam, mgr);
       fc->swapdstat();
     }
  }
}

void Calcscore::operator()(Family *fam) {
  zero(vec, fam->numiv()*(1 << fam->nasymmetricfoundercouples()));

  setupscorefamily(fam);

  // Recursive function to take care of founder couple asymmetries
  Uint i = 0;
  calcscore(fam->firstfoundercouple, i, fam);
  if (options->printpairscores)
    printpairscores(fam);
}

void Calcscore::operator()(Family *fam, Cudd &mgr) {
  S.clear();

  setupscorefamily(fam);

  // Recursive function to take care of founder couple asymmetries
  Uint i = 0;
  calcscore(fam->firstfoundercouple, i, fam, mgr);

  if (options->printpairscores)
    printpairscores(fam);
}

///////////////////////////////////////////////////////////////////////////
// Calcqualitativescore
void Calcqualitativescore::calc(DoubleVec score, Family *fam) {
  if (first == 0 || firstdesc == 0) {
    zero(score, fam->numiv());
    return;
  }
  if (id == "pairs" || id == "homoz") {
    first->resetdstat();
    firstdesc->calcspairs(0, 0.0, score, id == "homoz");
  }
  else if (id == "all") {
    for (Scoreperson *p = first; p != firstdesc; p = (Scoreperson *)p->next) {
      p->nod[0]->setinitcount(0.0);
      p->nod[1]->setinitcount(0.0);
    }
    first->calcsall(0, 1.0, score);
  }
  else if (id == "robdom")
    first->calcsrobdom(0, 0.0, score);
  else if (id == "mnallele") {
    Uint numf = fam->numf;
    if (options->sexlinked) {
      numf = 0;
      for (Person *p = fam->first; p != fam->firstdescendant; p = p->next)
        numf++;
    }
    first->calcsmnallele(0, 2.0*numf, score);
  }
  else assertinternal(false);

  expandiv(score, uninformativemask, fam->numiv());
}

ADD Calcqualitativescore::calc(Family *fam, Cudd &mgr) {
  if (first == 0)
    return mgr.addZero();
  DdNode *res = 0;
  if (id == "pairs" || id == "homoz") {
    first->resetdstat();
    res = firstdesc->calcspairs(0.0, id == "homoz", mgr.getManager());
  }
  else if (id == "all") {
    for (Scoreperson *p = first; p != firstdesc; p = (Scoreperson *)p->next) {
      p->nod[0]->setinitcount(0.0);
      p->nod[1]->setinitcount(0.0);
    }
    res = first->calcsall(1.0, mgr.getManager());
  }
  else if (id == "robdom")
    res = first->calcsrobdom(0.0, mgr.getManager());
  else if (id == "mnallele") {
    Uint numf = fam->numf;
    if (options->sexlinked) {
      numf = 0;
      for (Person *p = fam->first; p != fam->firstdescendant; p = p->next)
        numf++;
    }
    res = first->calcsmnallele(2.0*numf, mgr.getManager());
  }
  else assertinternal(false);
  assertinternal(res != 0);
  return ADD(&mgr, res);
}

void Calcqualitativescore::setupscorefamily(Family *fam) {
  first = 0;
  Scoreperson *lastfounder = 0;
  uninformativemask = 0;
  for (Person *p = fam->first; p != 0; p = p->next)
    if (p->hasaffecteddescendants(false)) {
      Scoreperson *next = new Scoreperson(p, first);
      if (first == 0) first = next;
      if (p->founder()) lastfounder = next;
    }
    else uninformativemask |= p->patmask | p->matmask;
  firstdesc = lastfounder == 0 ? 0 : (Scoreperson *)lastfounder->next;
}

Calcqualitativescore *
Calcqualitativescore::getcalcqualitativescore(const string &sc) {
  Calc *clc = findcalc(sc);
  if (clc != 0) return (Calcqualitativescore *)clc;
  else return new Calcqualitativescore(sc);
}

///////////////////////////////////////////////////////////////////////////
// Calcparentspecificscore
void Calcparentspecificscore::calc(DoubleVec score, Family *fam) {
  assertinternal(id == "ps");
  if (firstdesc == 0)
    zero(score, fam->numiv());
  else
    firstdesc->calcspairs_ps(0, 0, score, w_mm, w_mf, w_ff);
}

ADD Calcparentspecificscore::calc(Family */*fam*/, Cudd &mgr) {
  assertinternal(id == "ps");
  if (firstdesc == 0) return mgr.addZero();
  else
    return ADD(&mgr, firstdesc->calcspairs_ps(0, w_mm, w_mf, w_ff,
                                              mgr.getManager()));
}

Calcparentspecificscore *Calcparentspecificscore::
getcalcparentspecificscore(const string &sc, Double wmm, Double wmf,
                           Double wff) {
  Calc *clc = findcalc(description(sc, wmm, wmf, wff));
  if (clc != 0) return (Calcparentspecificscore *)clc;
  else return new Calcparentspecificscore(sc, wmm, wmf, wff);
}

///////////////////////////////////////////////////////////////////////////
// Calcgenpairs
Calcgenpairs::Calcgenpairs(const string &sc) : Calcscore(sc) {}

string Calcgenpairs::pair2string(const string &a, const string &b) const {
  return a + " " + b;
}

void Calcgenpairs::setupscorefamily(Family *fam) {
  Uint index = 0;
  first = new Genpairsperson(fam->first, 0, pair2weight1, pair2weight2, index,
                             fam->num - 1, informative[fam->first->id]);
  for (Person *p = fam->first->next; p != 0; p = p->next)
    new Genpairsperson(p, first, pair2weight1, pair2weight2, index,
                       fam->num - 1, informative[p->id]);
}

void Calcgenpairs::calc(DoubleVec score, Family *) {
  assertinternal(first != 0);
  first->calcgenspairs(0, 0.0, score);
}

ADD Calcgenpairs::calc(Family *, Cudd &mgr) {
  assertinternal(first != 0);
  return ADD(&mgr, first->calcgenspairs(.0, mgr.getManager()));
}

void Calcgenpairs::printpairscores(Family *fam) {
  if (!pairscores.assigned()) {
    pairscores.setname(describe() + ".sc");
    assertcond(pairscores.fileok(), string("Cannot open pairscores file ") +
               pairscores.name);
    pairscores.open();
  }
  for (Person *p = fam->first; p != 0; p = p->next)
    for (Person *q = p->next; q != 0; q = q->next) {
      string key = pair2string(p->id, q->id);
      if (pair2weight1[key] != 0 || pair2weight2[key] != 0) {
        pairscores << fam->id << "\t" << p->id << "\t" << q->id << "\t";
        fmtout(pairscores, 9, 7, pair2weight1[key]);
        fmtout(pairscores, 9, 7, pair2weight2[key]);
        pairscores << "\n";
      }
    }
}

void Calcgenpairs::calcweights(Family *fam) {
  pair2weight1.clear();
  pair2weight2.clear();
  for (Person *p = fam->first; p != 0; p = p->next)
    informative[p->id] = false;

  calcweights(fam);
}

void Calcgenpairs::operator()(Family *fam) {
  Calcgenpairs::calcweights(fam);
  Calcscore::operator()(fam);
}

void Calcgenpairs::operator()(Family *fam, Cudd &mgr) {
  Calcgenpairs::calcweights(fam);
  Calcscore::operator()(fam, mgr);
}

///////////////////////////////////////////////////////////////////////////
// Calcgenpairsfile
Calcgenpairsfile::Calcgenpairsfile(const string &sc, const string &fn) :
    Calcgenpairs(sc), filename(fn) {
  Infile weightfile;
  weightfile.setname(filename);
  weightfile.optcheck("GENPAIRS weightfile");
  weightfile.open();
  const Uint MAXLINE = 10000;
  char buf[MAXLINE];
  Uint linenum = 0;
  weightfile >> ws;
  while (!weightfile.eof() && !weightfile.fail()) {
    linenum++;
    weightfile >> buf;
    string per1 = buf;
    weightfile >> buf;
    string pair1 = pair2string(per1, buf);
    string pair2 = pair2string(buf, per1);
    Double weight;
    weightfile >> weight;
    pair2weight1[pair1] = pair2weight1[pair2] = weight;
    pair2weight2[pair1] = pair2weight2[pair2] = 2*weight;
    weightfile >> ws;
  }
  weightfile.close();
}

Calcgenpairsfile *Calcgenpairsfile::getcalcgenpairsfile(const string &sc,
                                                        const string &fn) {
  Calc *clc = findcalc(sc + " " + fn);
  if (clc != 0) return (Calcgenpairsfile *)clc;
  else return new Calcgenpairsfile(sc, fn);
}

void Calcgenpairsfile::calcweights(Family *fam) {
  fam->calckinship();
  for (Person *p = fam->first; p != 0; p = p->next)
    for (Person *q = p->next; q != 0; q = q->next) {
      Float ks = fam->kinship->getkinship(p->nmrk, q->nmrk);
      if (ks > 0) {
        const string key = pair2string(p->id, q->id);
        if (pair2weight1[key] != 0 || pair2weight2[key] != 0)
          informative[p->id] = informative[q->id] = true;
      }
    }
}

///////////////////////////////////////////////////////////////////////////
// Calcgenpairsfile_ps
Calcgenpairsfile_ps::Calcgenpairsfile_ps(const string &sc, const string &fn) :
    Calcscore(sc), filename(fn) {
  Infile weightfile;
  weightfile.setname(filename);
  weightfile.optcheck("GENPAIRS_PS weightfile");
  weightfile.open();
  const Uint MAXLINE = 10000;
  char buf[MAXLINE];
  Uint linenum = 0;
  weightfile >> ws;
  while (!weightfile.eof() && !weightfile.fail()) {
    linenum++;
    weightfile >> buf;
    string per1 = buf;
    weightfile >> buf;
    const string pair1 = per1 + " " + buf;
    const string pair2 = string(buf) + " " + per1;
    Double wmm, wmf, wff;
    weightfile >> wmm >> wmf >> wff;
    pair2wmm[pair1] = pair2wmm[pair2] = wmm;
    pair2wmf[pair1] = pair2wmf[pair2] = wmf;
    pair2wff[pair1] = pair2wff[pair2] = wff;
    weightfile >> ws;
  }
  weightfile.close();
}

void Calcgenpairsfile_ps::setupscorefamily(Family *fam) {
  Uint index = 0;
  first = new Genpairsperson_ps(fam->first, 0, pair2wmm, pair2wmf, pair2wff,
                                index, fam->num - 1,
                                informative[fam->first->id]);
  for (Person *p = fam->first->next; p != 0; p = p->next)
    new Genpairsperson_ps(p, first, pair2wmm, pair2wmf, pair2wff, index,
                          fam->num - 1, informative[p->id]);
}

void Calcgenpairsfile_ps::calc(DoubleVec score, Family *) {
  assertinternal(first != 0);
  first->calcgenspairs_ps(0, 0.0, score);
}

ADD Calcgenpairsfile_ps::calc(Family *, Cudd &mgr) {
  assertinternal(first != 0);
  return ADD(&mgr, first->calcgenspairs_ps(.0, mgr.getManager()));
}

Calcgenpairsfile_ps *Calcgenpairsfile_ps::
getcalcgenpairsfile_ps(const string &sc, const string &fn) {
  Calc *clc = findcalc(sc + " " + fn);
  if (clc != 0) return (Calcgenpairsfile_ps *)clc;
  else return new Calcgenpairsfile_ps(sc, fn);
}

void Calcgenpairsfile_ps::calcweights(Family *fam) {
  fam->calckinship();
  for (Person *p = fam->first; p != 0; p = p->next)
    for (Person *q = p->next; q != 0; q = q->next) {
      Float ks = fam->kinship->getkinship(p->nmrk, q->nmrk);
      if (ks > 0) {
        const string key = p->id + " " + q->id;
        if (pair2wmm[key] != 0 || pair2wmf[key] != 0 || pair2wff[key] != 0)
          informative[p->id] = informative[q->id] = true;
      }
    }
}

///////////////////////////////////////////////////////////////////////////
// Calcgenpairsregress
Calcgenpairsregress *Calcgenpairsregress::
getcalcgenpairsregress(const string &sc, Double het, const string &tr) {
  Calc *clc = findcalc(description(sc, het, tr));
  if (clc != 0) return (Calcgenpairsregress *)clc;
  else return new Calcgenpairsregress(sc, het, tr);
}

static void choleskysolve(vector<Double> &x, const DoubleMat &A,
                          const vector<double> &b) {
  const Uint n = b.size();
  DoubleMat L = newsymmetricmatrix<Double>(n);

  for (Uint i = 0; i < n; i++) {
    L[i][i] = sqrt(A[i][i] - dotprod(L[i], L[i], i));

    for (Uint j = i + 1; j < n; j++)
      L[j][i] = (A[j][i] - dotprod(L[j], L[i], i))/L[i][i];
  }

  vector<Double> y(n);
  for (Uint i = 0; i < n; i++)
    y[i] = (b[i] - dotprod(&*y.begin(), L[i], i))/L[i][i];

  for (int i = n - 1; i >= 0; i--) {
    Double c = .0;
    for (Uint j = i + 1; j < n; j++)
      c += L[j][i]*x[j];
    x[i] = (y[i] - c)/L[i][i];
  }
}

Double Calcgenpairsregress::kccor(Uint p1, Uint p2, Kinship *kinship) {
  return p1 == p2 ? 1. : kinship->getkinship(p1, p2)*heritability;
}

void Calcgenpairsregress::calcweights(Family *fam) {
  fam->calckinship();

  Uint num_phenotyped = 0;
  vector<Float> sum2;
  vector<Float> diff2;
  vector<pair<Uint, Uint> > pairs;
  for (Person *p = fam->first; p != 0; p = p->next) {
    if (traitdata->hastraitvalue(p->id, trait)) {
      const Float x_p = traitdata->gettraitvalue(p->id, trait);
      num_phenotyped++;
      for (Person *q = p->next; q != 0; q = q->next) {
        if (traitdata->hastraitvalue(q->id, trait)) {
          const Float ks = fam->kinship->getkinship(p->nmrk, q->nmrk);
          informative[p->id] = informative[q->id] = true;

          const Float x_q = traitdata->gettraitvalue(q->id, trait);
          const Float r = ks*heritability;

          sum2.push_back(square(x_p + x_q) - 2.*(1. + r));
          diff2.push_back(square(x_p - x_q) - 2.*(1. - r));

          pairs.push_back(make_pair(p->nmrk, q->nmrk));
        }
      }
    }
  }

  if (!sum2.empty()) {
    const Uint nd = num_phenotyped == 2 ? 1 : num_phenotyped;

    vector<Float> y(sum2);
    y.insert(y.end(), diff2.begin(), diff2.begin() + nd);

    DoubleMat sigma = newsymmetricmatrix<Double>(y.size());

    for (Uint i = 0; i < sum2.size(); i++) {
      for (Uint j = 0; j <= i; j++)
        sigma[i][j] =
          2.*square(kccor(pairs[i].first, pairs[j].first, fam->kinship) +
                    kccor(pairs[i].first, pairs[j].second, fam->kinship) +
                    kccor(pairs[i].second, pairs[j].first, fam->kinship) +
                    kccor(pairs[i].second, pairs[j].second, fam->kinship));

      for (Uint j = 0; j < nd; j++)
        sigma[sum2.size() + j][i] =
          2.*square(kccor(pairs[i].first, pairs[j].first, fam->kinship) -
                    kccor(pairs[i].first, pairs[j].second, fam->kinship) +
                    kccor(pairs[i].second, pairs[j].first, fam->kinship) -
                    kccor(pairs[i].second, pairs[j].second, fam->kinship));
    }

    for (Uint i = 0; i < nd; i++) {
      for (Uint j = 0; j <= i; j++)
        sigma[sum2.size() + i][sum2.size() + j] =
          2.*square(kccor(pairs[i].first, pairs[j].first, fam->kinship) -
                    kccor(pairs[i].first, pairs[j].second, fam->kinship) -
                    kccor(pairs[i].second, pairs[j].first, fam->kinship) +
                    kccor(pairs[i].second, pairs[j].second, fam->kinship));
    }

    vector<Double> u(y.size());
    choleskysolve(u, sigma, y);

    vector<Double> B(sum2.size());
    for (Uint i = 0; i < sum2.size(); i++) {
      B[i] = 4.*u[i];
      if (i < nd)
        B[i] -= 4.*u[sum2.size() + i];
    }

    Uint i = 0;
    for (Person *p = fam->first; p != 0; p = p->next) {
      if (traitdata->hastraitvalue(p->id, trait)) {
        for (Person *q = p->next; q != 0; q = q->next) {
          if (traitdata->hastraitvalue(q->id, trait)) {
            const string key = pair2string(p->id, q->id);
            pair2weight1[key] = B[i];
            pair2weight2[key] = 2.*B[i];
            i++;
          }
        }
      }
    }
  }
}

///////////////////////////////////////////////////////////////////////////
// Calcgenpairsshared
Float Calcgenpairsshared::calcweight(Float ks, Float x1, Float x2) {
  if (id == "qtlscore") {
    Float G = ks*shared;
    Float G2 = G*G;
    Float d = 1 - G2;
    return .5*G/d + (-(x1*x1 + x2*x2)*G + x1*x2*(1 + G2))/(2.0*d*d);
  }
  else if (id == "qtlhe") {
    Float d = x1 - x2;
    return -d*d + 2*(variance - ks*shared);
  }
  else if (id == "qtlnhe" || id == "qtlwpc")
    return x1*x2 - ks*shared;
  else assertinternal(false);
}

void Calcgenpairsshared::calcweights(Family *fam) {
  // Find all pairs that potentially share and calculate the weights of
  // the pairs
  fam->calckinship();
  for (Person *p = fam->first; p != 0; p = p->next)
    if (traitdata->hastraitvalue(p->id, trait)) {
      const Float x_p = traitdata->gettraitvalue(p->id, trait);
      for (Person *q = p->next; q != 0; q = q->next) {
        if (traitdata->hastraitvalue(q->id, trait)) {
          Float ks = fam->kinship->getkinship(p->nmrk, q->nmrk);
          if (ks > 0) {
            const Float x_q = traitdata->gettraitvalue(q->id, trait);
            const string key = pair2string(p->id, q->id);
            informative[p->id] = informative[q->id] = true;
            pair2weight1[key] = calcweight(ks, x_p, x_q);
            pair2weight2[key] = 2*pair2weight1[key];
          }
        }
      }
    }
}

Calcgenpairsshared *Calcgenpairsshared::
getcalcgenpairsshared(const string &sc, Double shr, Double var,
                      const string &tr) {
  Calc *clc = findcalc(description(sc, shr, var, tr));
  if (clc != 0) return (Calcgenpairsshared *)clc;
  else return new Calcgenpairsshared(sc, shr, var, tr);
}

///////////////////////////////////////////////////////////////////////////
// Calcgenpairsvc
FindIBD *Calcgenpairsvc::findIBD = 0;
Calcgenpairsvc::Calcgenpairsvc(const string &sc, Double s, Double a, Double d,
                               const string &tr) :
    Calcgenpairs(sc), shared(s), sigma2_g(a), sigma2_d(d), trait(tr) {
  if (findIBD == 0) {
    findIBD = FindIBD::getFindIBD("qtl");
  }
}

Float Calcgenpairsvc::probpair(Float ks, Float x1, Float x2, Float pi) {
  Float rho = ks*shared + pi*sigma2_g + (pi > .95 ? 1 : 0)*sigma2_d;
  Float u = x1 - x2;
  Float v = x1 + x2;

  return exp(-.25*(u*u/(1 - rho) + v*v/(1 + rho)))/sqrt((1 - rho)*(1 + rho));
}

void Calcgenpairsvc::calcweight(Float p1, Float p2, Float x1, Float x2,
                                Float &weight1, Float &weight2) {
  Float ks = .5*p1 + p2;
  Float px0 = probpair(ks, x1, x2, 0);
  Float px1 = probpair(ks, x1, x2, .5);
  Float px2 = probpair(ks, x1, x2, 1);
  Float px = (1 - p1 - p2)*px0 + p1*px1 + p2*px2;
  if (id == "qtlgenpairsncp") {
    Float mu_0 = .5*p1 + p2;
    Float o2_0 = .25*p1 + p2 - mu_0*mu_0;
    Float mu_A = (.5*px1*p1 + px2*p2)/px;
    Float w = (mu_A - mu_0)/o2_0;
    weight1 = .5*w;
    weight2 = w;
  }
  if (id == "qtlpairs" || id == "qtlpairsncp") {
    Float w0 = px0/px;
    Float w1 = px1/px;
    Float w2 = px2/px;
    if (id == "qtlpairs") {
      weight1 = log(w1) - log(w0);
      weight2 = log(w2) - log(w0);
    }
    else if (id == "qtlpairsncp") {
      weight1 = w1 - w0;
      weight2 = w2 - w0;
    }
  }
}

void Calcgenpairsvc::calcweights(Family *fam) {
  findIBD->findprior(0, 0);

  // Find all pairs that potentially share and calculate the weights of
  // the pairs
  const Double tolerance = 1e-6;
  for (Person *p = fam->first; p != 0; p = p->next)
    if (traitdata->hastraitvalue(p->id, trait)) {
      const Float x_p = traitdata->gettraitvalue(p->id, trait);
      for (Person *q = p->next; q != 0; q = q->next) {
        if (traitdata->hastraitvalue(q->id, trait)) {
          Float p1, p2;
          findIBD->priorresult(p, q, p1, p2);
          if (fabs(p1 + p2) > tolerance || fabs(p1 - 1) > tolerance ||
              fabs(p2 - 1) > tolerance) {
            const Float x_q = traitdata->gettraitvalue(q->id, trait);
            string key = pair2string(p->id, q->id);
            informative[p->id] = informative[q->id] = true;
            calcweight(p1, p2, x_p, x_q, pair2weight1[key], pair2weight2[key]);
          }
        }
      }
    }
}

Calcgenpairsvc *Calcgenpairsvc::getcalcgenpairsvc(const string &sc,
                                                  Double /*s2*/, Double s,
                                                  Double a, Double d,
                                                  const string &tr) {
  Calc *clc = findcalc(description(sc, s, a, d, tr));
  if (clc != 0) return (Calcgenpairsvc *)clc;
  else return new Calcgenpairsvc(sc, s, a, d, tr);
}
