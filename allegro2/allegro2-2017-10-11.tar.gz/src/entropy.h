#ifndef _ENTROPY
#define _ENTROPY
#include "basic.h"

class Entropy : public Distribution {
public:
  Entropy(const string &pt);
  virtual ~Entropy();
  virtual string describe() const {return "entropy";}
  static Entropy *getentropy(const string &pt);

  Float faminfo(Uint ifa, Uint pos) const {return familydata[ifa]->info[pos];}
  Float info(Uint pos) const;

protected:
  class Familydata {
  protected:
    Entropy *owner;
  public:
    Familydata(Entropy *own) : owner(own) {
      info = new Double[owner->npos];
    }
    Familydata(const Familydata &fd) : owner(fd.owner) {
      info = new Double[owner->npos];
    }
    ~Familydata() {delete [] info;}
    DoubleVec info;
  };
  friend class Entropy::Familydata;
  typedef vector<Familydata *> Familydatavector;
  Familydatavector familydata;

  virtual void reset(Uint np);
  virtual void nextfam(bool mtbdd, Uint pos = 0, DoubleVec p0 = 0);
  virtual void set(FloatVec pv, Uint pos);
  virtual void set(ADD &/*pv*/, double /*sum_pv*/, Uint /*pos*/) {
    fatal("Entropy calculations not implemented for MTBDDs");
  }
  virtual void skipfam();

  virtual void getuninteresting(::set<Unreduced> &/*uninteresting*/) {}

};

#endif // _ENTROPY
