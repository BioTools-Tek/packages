#include "rgamma.cc"
#include <iostream>
#include <stdlib.h>

Double runif() {
  return drand48();
}

using namespace std;

double var(const vector<double> &x) {
  double ss = .0;
  double s = .0;
  for (unsigned int i = 0; i < x.size(); i++) {
    s += x[i];
    ss += x[i]*x[i];
  }
  double n = x.size();
  return (ss - s*s/n)/(n - 1);
}

double mean(const vector<double> &x) {
  double sum = 0;
  for (unsigned int i = 0; i < x.size(); i++) sum += x[i];
  return sum/double(x.size());
}

int main() {
  srand48(1310912309);
  const unsigned int N = 10000;
  vector<double> rge;
  vector<double> rgw;
  const double v = 1.5;
  for (unsigned int i = 0; i < N; i++) {
    double y = -200.;
    double y_1;
    while (y < .0) {
      y_1 = y;
      y += rgammamix(v);
    }

    Double r;
    do {
      r = rgammamix(v) - y;
    } while (r < 0);

    rge.push_back(r);
    rgw.push_back(y_1);
  }

  cout << mean(rge) << "\t" << var(rge) << endl;
  cout << mean(rgw) << "\t" << var(rgw) << endl;
}
