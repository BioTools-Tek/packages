#include "family.h"
#include "findibd.h"
#include "pairibd.h"
#include "vecutil.h"
#include "cuddutil.h"
#include "findscore.h"
#include "traitdata.h"
#include "options.h"

bool hasinformativedescendants(Person *p) {
  return true;
  if (p->origdstat != UNKNOWN) return true;
  for (Plist *c = p->children; c != 0; c = c->next)
    if (hasinformativedescendants(c->p)) return true;
  return false;
}

FindIBD::FindIBD(const string &pairs) :
    Calc(pairs), firstibdperson(0), numiv(0), mtbdd(false),
    pairtype(pairs.substr(3)) {}

FindIBD::~FindIBD() {
  delete firstibdperson;
}

FindIBD *FindIBD::getFindIBD(const string &pairtype) {
  const string id("IBD" + pairtype);
  Calc *clc = findcalc(id);
  if (clc != 0) return (FindIBD *)clc;
  else return new FindIBD(id);
}

void FindIBD::findprior(DoubleVec results1, DoubleVec results2) {
  if (mtbdd) {
    if (S.count() > 0)
      findposterior(S[0].manager()->addOne(),
                    IV(1) << S[0].manager()->ReadSize(), results1, results2);
  }
  else {
    firstibdperson->reset();
    firstibdperson->calcpairibd(0, mask);
    for (Uint i = 0; i < foundercoupleindices.size(); i++)
      firstibdperson->correctfoundercouple(foundercoupleindices[i].first,
                                         foundercoupleindices[i].second);
    if (results1 != 0 && results2 != 0)
      firstibdperson->collectresults(firstibdperson, results1, results2,
                                     numiv/(IV(1) <<
                                            POPCOUNT(mask)));
  }
}

void FindIBD::findposterior(FloatVec prob,
                            DoubleVec results1, DoubleVec results2) {
  assertinternal(!mtbdd);
  firstibdperson->reset();
  firstibdperson->calcpairibd(0, mask, prob);
  for (Uint i = 0; i < foundercoupleindices.size(); i++)
    firstibdperson->correctfoundercouple(foundercoupleindices[i].first,
                                         foundercoupleindices[i].second);
  const Double nc = sum<Double>(prob, numiv);
  firstibdperson->collectresults(firstibdperson, results1, results2, nc);
}

void FindIBD::findposterior(ADD prob, double sum_prob,
                            DoubleVec results1, DoubleVec results2) {
  assertinternal(mtbdd);

  vector<int *> support(2*pairs.size(), 0);
  Cudd &mgr = *prob.manager();
  ADD one(mgr.addOne());
  ADD zero(mgr.addZero());

  for (unsigned int p = 0; p < pairs.size(); p++) {
    ADD &S1 = S[2*p];
    ADD &S2 = S[2*p + 1];
    if (S1 == one) {
      results1[p] = 1.;
      results2[p] = .0;
    } else if (S2 == one) {
      results1[p] = .0;
      results2[p] = 1.;
    } else if (S1 == zero && S2 == zero)
      results1[p] = results2[p] = .0;
    else {
      if (S1 != zero)
        support[2*p] = Cudd_SupportIndex(mgr.getManager(), S1.getNode());
      if (S2 != zero)
        support[2*p + 1] = Cudd_SupportIndex(mgr.getManager(), S2.getNode());
    }
  }

  int *supp = new int[mgr.ReadSize()];
  for (Uint i = 0; i < Uint(mgr.ReadSize()); i++)
    supp[i] = 1;

  vector<double> results(2*pairs.size(), .0);
  while (true) {
    unsigned int first_unhandled = 0;
    while (first_unhandled < support.size() && support[first_unhandled] == 0)
      first_unhandled++;
    if (first_unhandled < support.size())
      findPosterior(prob, sum_prob, support, first_unhandled, supp, results);
    else
      break;
  }

  for (unsigned int p = 0; p < pairs.size(); p++) {
    results1[p] = results[2*p];
    results2[p] = results[2*p + 1];
  }
}

void FindIBD::findPosterior(ADD &prob, double sum_prob,
                            vector<int *> &support, unsigned int target,
                            int *cur_supp, vector<double> &results) {
  const unsigned int n = prob.manager()->ReadSize();
  int *target_supp = support[target];
  unsigned int i = 0;
  while (i < n && target_supp[i] == cur_supp[i]) i++;
  if (i == n) {
    results[target] = sum(prob*S[target])/sum_prob;
    free(support[target]);
    support[target] = 0;
  } else {
    assertinternal(!target_supp[i] && cur_supp[i]);
    Cudd &mgr = *prob.manager();
    ADD bv(mgr.addVar(i));
    ADD p = prob.Cofactor(~bv) + prob.Cofactor(bv);
    cur_supp[i] = 0;
    findPosterior(p, sum_prob, support, target, cur_supp, results);
    cur_supp[i] = 1;
  }

  while (true) {
    unsigned int new_target = 0;
    while (new_target < support.size() &&
           (support[new_target] == 0 ||
            memcmp(support[new_target], cur_supp, i*sizeof(int)) != 0))
      new_target++;

    if (new_target < support.size())
      findPosterior(prob, sum_prob, support, new_target, cur_supp, results);
    else
      break;
  }
}

void FindIBD::collectpairs(StringVec person1, StringVec person2) const {
  if (mtbdd)
    for (unsigned int i = 0; i < pairs.size(); i++) {
      person1[i] = pairs[i].first;
      person2[i] = pairs[i].second;
    }
  else
    firstibdperson->collectpairs(firstibdperson, person1, person2);
}

bool FindIBD::isinformative(Person *p) {
  if (pairtype == "all") return true;
  else if (pairtype == "genotyped") return p->genotyped();
  else if (pairtype == "affected") return p->dstat == AFFECTED;
  else if (pairtype == "qtl") return traitdata->hastraitvalue(p->id);
  else if (pairtype == "informative") return p->dstat != UNKNOWN;
  else assertinternal(false);
}

Uint FindIBD::countpairs() {
  if (mtbdd)
    return pairs.size();
  else
    return firstibdperson->countpairs(firstibdperson);
}

void FindIBD::priorresult(Person *a, Person *b, Float &p1, Float &p2) const {
  assertinternal(!mtbdd);
  assertinternal(a != b);
  IBDperson *ap = firstibdperson->findperson(a);
  IBDperson *bp = firstibdperson->findperson(b);
  assertinternal(ap != 0 && bp != 0);
  ap->getsharing(bp, p1, p2);
  p1 /= numiv/(IV(1) << POPCOUNT(mask));
  p2 /= numiv/(IV(1) << POPCOUNT(mask));
}

void FindIBD::operator()(Family *fam) {
  mtbdd = false;
  numiv = fam->numiv();
  foundercoupleindices.clear();
  delete firstibdperson;
  firstibdperson = 0;
  Uint idx = 0;
  mask = 0;
  for (Person *p = fam->first; p != 0; p = p->next) {
    if (hasinformativedescendants(p)) {
      IBDperson *pibd = new IBDperson(p, firstibdperson, fam->num - 1,
                                      idx, isinformative(p));
      if (firstibdperson == 0) firstibdperson = pibd;
    }
    else mask |= p->patmask | p->matmask;
  }
  for (Foundercouple *fc = fam->firstfoundercouple; fc != 0; fc = fc->next) {
    Uint gfidx = firstibdperson->findperson(fc->husband)->get_index();
    Uint gmidx = firstibdperson->findperson(fc->wife)->get_index();
    foundercoupleindices.push_back(Intpair(gfidx, gmidx));
  }
}

void FindIBD::calcsharing(ADD &S1, ADD &S2, Person *p, Person *q, Family *fam,
                          Cudd &mgr) {
  Scoreperson *firstperson = 0;
  Scoreperson *firstdesc = 0;
  for (Person *a = fam->first; a != 0; a = a->next)
    if (a->isancestorof(p) && a->isrelatedto(q) ||
        a->isancestorof(q) && a->isrelatedto(p)) {
      Scoreperson *pibd = new Scoreperson(a, firstperson);
      if (pibd->nod[0] != 0) pibd->nod[0]->setinitcount(.0);
      if (pibd->nod[1] != 0) pibd->nod[1]->setinitcount(.0);
      if (a->founder() && (a == p || a == q)) {
        if (!options->sexlinked || a->sex == FEMALE)
          pibd->nod[0]->addspairs();
        pibd->nod[1]->addspairs();
//           pibd->nod[0]->addibd(a == p, true);
//        pibd->nod[1]->addibd(a == p, false);
      }
      if (!a->founder() && firstdesc == 0) firstdesc = pibd;
      if (firstperson == 0) firstperson = pibd;
    }

  DdNode *S1n = mgr.getManager()->zero;
  DdNode *S2n = mgr.getManager()->zero;
  firstdesc->calcsharing(.0, S1n, S2n, p, q, mgr.getManager());
  cuddRef(S2n);
  S1 = ADD(&mgr, S1n);
  S2 = ADD(&mgr, S2n);
  cuddDeref(S2n);
}

void FindIBD::operator()(Family *fam, Cudd &mgr) {
  mtbdd = true;
  pairs.clear();
  for (Person *p = fam->first; p != 0; p = p->next)
    if (isinformative(p))
      for (Person *q = p->next; q != 0; q = q->next)
        if (isinformative(q) && p->isrelatedto(q)) {
          ADD S1, S2;
          calcsharing(S1, S2, p, q, fam, mgr);
          if (p->fc != 0 && p->founder() || q->fc != 0 && q->founder()) {
            assertinternal(!(p->fc != 0 && p->founder() &&
                             q->fc != 0 && q->founder()));
            Person *non_fc, *fc_mate;
            if (p->fc != 0 && p->founder()) {
              non_fc = q;
              fc_mate = p->sex == FEMALE ? p->fc->husband : p->fc->wife;
              assert(fc_mate != p);
            }
            else {
              non_fc = p;
              fc_mate = q->sex == FEMALE ? q->fc->husband : q->fc->wife;
              assert(fc_mate != q);
            }
            ADD S1m, S2m;
            calcsharing(S1m, S2m, non_fc, fc_mate, fam, mgr);
            S1 = mgr.constant(.5)*(S1 + S1m);
            S2 = mgr.constant(.5)*(S2 + S2m);
          }
          S.push_back(S1);
          S.push_back(S2);
          pairs.push_back(make_pair(p->id, q->id));
        }
}
