#ifndef _CONDLIKMODEL
#define _CONDLIKMODEL
#include "qtlmodel.h"

class Condlikmodel : public QTLmodel {
protected:
  virtual Double calculate(DoubleVec fl,
                           Double S, Double G, Double A, Double D, Uint gam);

public:
  Condlikmodel(const string &p, const string &tr, bool maxG, bool maxA,
               bool maxD, Double shr, const string &of, const string &fof);

  virtual void print() const;
};

#endif // _CONDLIKMODEL
