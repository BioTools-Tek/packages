#ifndef _FOUNDERHAPLODIST
#define _FOUNDERHAPLODIST
#include "basic.h"
#include "distribution.h"

class Founderhaplodist : public Distribution {
public:
  static Founderhaplodist *getfounderhaplodist(const string &outfile);
  virtual ~Founderhaplodist() {}

  virtual string describe() const {return "Founderhaplodist";}

  void print() const;

  virtual bool usefamily(Family */*fam*/, bool) const {return true;}
  virtual bool useuninformative() const {return true;}
protected:
  Outfile fhfile;

  Founderhaplodist(const string &outfile);

  virtual void reset(Uint /*np*/) {}
  virtual void nextfam(bool /*mtbdd*/, Uint /*pos*/ = 0, DoubleVec /*p0*/ = 0);
  virtual void set(FloatVec /*pv*/, Uint /*pos*/) {}
  virtual void set(ADD &/*pv*/, double /*sum_pv*/, Uint /*pos*/) {}
  virtual void skipfam() {}

  virtual void getuninteresting(::set<Unreduced> &/*uninteresting*/) {
    assertinternal(false);
  }

};

class Orderedfounderhaplodist : public Distribution {
public:
  static Orderedfounderhaplodist *
  getorderedfounderhaplodist(const string &outfile);
  virtual ~Orderedfounderhaplodist() {}

  virtual string describe() const {return "Orderedfounderhaplodist";}

  void print() const;

  virtual bool usefamily(Family */*fam*/, bool /*mtbdd*/) const {return true;}
  virtual bool useuninformative() const {return true;}
protected:
  Outfile fhfile;

  Orderedfounderhaplodist(const string &outfile);

  virtual void reset(Uint /*np*/) {}
  virtual void nextfam(bool /*mtbdd*/, Uint /*pos*/ = 0, DoubleVec /*p0*/ = 0);
  virtual void set(FloatVec /*pv*/, Uint /*pos*/) {}
  virtual void set(ADD &/*pv*/, double /*sum_pv*/, Uint /*pos*/) {}
  virtual void skipfam() {}

  virtual void getuninteresting(::set<Unreduced> &/*uninteresting*/) {
    assertinternal(false);
  }

};

#endif // _FOUNDERHAPLODIST
