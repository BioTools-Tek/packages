#ifndef _ALLHAPLOMODEL
#define _ALLHAPLOMODEL
#include "basic.h"
#include "model.h"
#include "allhaplodist.h"

class Allhaplomodel : public Model {
public:
  Allhaplomodel(const string &of) : Model("mpt") {
    distribution = Allhaplodist::getallhaplodist(of);
  }
  
  virtual ~Allhaplomodel() {delete distribution;}

  virtual void output() {}
  
  // prints description
  virtual void print() const {((Allhaplodist *)distribution)->print();}

protected:
  virtual void totline(ostream &/*f*/, Uint /*pos*/) {}
  virtual void famline(ostream &/*f*/, Uint /*ifa*/, Uint /*pos*/) {}
  virtual void totheader(ostream &/*f*/) {}
  virtual void famheader(ostream &/*f*/) {}

};

#endif // _ALLHAPLOMODEL
