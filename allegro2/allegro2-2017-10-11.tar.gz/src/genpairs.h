#ifndef _GENPAIRS
#define _GENPAIRS
#include "basic.h"
#include "pairwise.h"

class Genpairsperson : public Pairwiseperson<Indexfounderallele> {
protected:
  DoubleVec w1;
  DoubleVec w2;
  Uint index;
  bool informative;

  Double addgenpairs();
public:
  Genpairsperson(Person *p, Genpairsperson *first, String2Double &pair2weight1,
                 String2Double &pair2weight2, Uint &idx, Uint maxnum,
                 bool infm);
  void calcgenspairs(IV v, Double B, DoubleVec S);
  DdNode *calcgenspairs(double B, DdManager *mgr);
};

class PSfounderallele {
public:
  UintVec pat_descendants;
  UintVec mat_descendants;
  Uint num_pat_descendants;
  Uint num_mat_descendants;

  PSfounderallele() : num_pat_descendants(0), num_mat_descendants(0) {}
  void setmaxnum(Uint maxnum) {
    if (maxnum > 0) {
      pat_descendants = new Uint[maxnum];
      mat_descendants = new Uint[maxnum];
    }
    else {
      pat_descendants = 0;
      mat_descendants = 0;
    }
  }
  ~PSfounderallele() {
    delete [] pat_descendants;
    delete [] mat_descendants;
  }

  void pushpatdescendant(Uint idx) {
    pat_descendants[num_pat_descendants++] = idx;
  }
  void pushmatdescendant(Uint idx) {
    mat_descendants[num_mat_descendants++] = idx;
  }
  void poppatdescendant() {num_pat_descendants--;}
  void popmatdescendant() {num_mat_descendants--;}
};

class Genpairsperson_ps : public Pairwiseperson<PSfounderallele> {
protected:
  DoubleVec wmm;
  DoubleVec wmf;
  DoubleVec wff;

  Uint index;
  bool informative;

  Double addgenpairs_ps();
  Double addgenpairs_ps(PSfounderallele *n, bool pattrans);
  Double addgenpairs_ps(UintVec desc, Uint num, DoubleVec w);

public:
  Genpairsperson_ps(Person *p, Genpairsperson_ps *first,
                    String2Double &pair2wmm, String2Double &pair2wmf,
                    String2Double &pair2wff, Uint &idx, Uint maxnum,
                    bool infm);
  void calcgenspairs_ps(IV v, Double B, DoubleVec S);
  DdNode *calcgenspairs_ps(Double B, DdManager *mgr);
};

#endif // _GENPAIRS
