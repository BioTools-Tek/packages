#ifndef _UTILS
#define _UTILS

// General utility functions
#include "files.h"

template<class T>
void deletelist(T* first) {
  for (T* p = first; p != 0;) {
    T* tmp = p->next;
    delete p;
    p = tmp;
  }
}

// IO utils

// Read a numeric variable of type T from dat. If read fails,
// msg is printed and a fatal error occurs
template<class T>
void readnumeric(T &target, ISTRINGSTREAM &dat, const string &msg) {
  target = T(-1);
  dat >> target >> ws;
  assertcond(dat.good() || (dat.eof() && target != T(-1)), msg);
}

// Get the next line from dat. If dat is allready at eof, then
// a message is printed and a fatarl error occurs
inline void getnextline(Infile &dat, Uint &curline, ISTRINGSTREAM *&line,
                        const string &filetype) {
  curline++;
  assertcond(!dat.eof(), filetype + string(" input ") + curline +
             ": Unable to read line");
  string linebuffer;
  getline(dat, linebuffer);
  delete line;
  line = new ISTRINGSTREAM(linebuffer);
}

#endif
