#ifndef _BFUNCTION
#define _BFUNCTION

#include "cuddObj.hh"
#include "cuddInt.h"

#include "SW.hh"

#include "basic.h"

#include <map>

class Unreduced;

class BFunction {
protected:
  Cudd *m_manager;

  string m_swap_file;
  bool m_own_swap_file;

public:
  enum Type{ADD_FUN, VECTOR_FUN};
  virtual Type type() const = 0;

  BFunction(Cudd *manager, const string &swap_file = "") :
      m_manager(manager), m_swap_file(swap_file), m_own_swap_file(false) {}
  virtual ~BFunction();

  bool inMemory() const {return m_swap_file == "";}
  virtual Uint memoryInUse() = 0;

  Cudd &manager() {return *m_manager;}

  virtual void transfer(Cudd &mgr) = 0;

  const string &swapFile() const {return m_swap_file;}

  virtual void writeToFile(const string &fn, bool swap) = 0;

  virtual bool isConstant() = 0;
  virtual bool isZero() = 0;
  virtual bool isPositive() = 0;

  virtual void inplaceMult(ADD &x) = 0;
  virtual void inplaceMultBF(BFunction &x) = 0;

  virtual int *getInvperm() const = 0;
  virtual int *getPerm() const = 0;
  virtual void shuffle(int *invperm) = 0;

  virtual int *support() = 0;

  virtual void asStraightVector(double *res) = 0;

  virtual void integrateOut(const set<Unreduced> &bits) = 0;

  virtual double dotProduct(BFunction &x) = 0;
  virtual double dotProductRec(BFunction &x, const Unreduced &bit) = 0;

  virtual void print(int print_level) = 0;

//  virtual ADD getADD(ADD *zo = 0) = 0;
//  virtual double *getVector() = 0;

};

class ADDFunction : public BFunction {
private:
  ADD m_add;

public:
  virtual Type type() const {return ADD_FUN;}

  ADDFunction(ADDFunction &f, const string &f_swap_file = "");
  ADDFunction(ADD &add) :
      BFunction(add.manager()), m_add(add) {}
  ADDFunction(const string &file, Cudd &mgr) : BFunction(&mgr, file) {}
  virtual ~ADDFunction() {}

  virtual Uint memoryInUse() {
    return inMemory() ? m_add.nodeCount()*sizeof(DdNode) : 0;
  }

  virtual void transfer(Cudd &mgr);

  virtual void writeToFile(const string &fn, bool swap);

  virtual bool isConstant() {
    if (!inMemory()) getADD();
    return cuddIsConstant(m_add.getNode());
  }
  virtual bool isZero() {
    if (!inMemory()) getADD();
    return m_add == m_add.manager()->addZero();
  }
  virtual bool isPositive() {
    if (!inMemory()) getADD();
    return cuddV(m_add.FindMin().getNode()) >= .0;
  }

  virtual void inplaceMult(ADD &x);
  virtual void inplaceMultBF(BFunction &x);

  virtual int *getInvperm() const {return m_manager->getManager()->invperm;}
  virtual int *getPerm() const {return m_manager->getManager()->perm;}
  virtual void shuffle(int *invperm) {
    m_manager->ShuffleHeap(invperm);
  }

  virtual int *support() {
    if (!inMemory()) getADD();
    return Cudd_SupportIndex(m_manager->getManager(), m_add.getNode());
  }

  ADD &getADD();
  void setADD(ADD x) {
    if (!inMemory()) {
      if (m_own_swap_file)
        remove(m_swap_file.c_str());
      m_swap_file = "";
    }
    m_add = x;
    m_manager = x.manager();
  }
  void transferTo(Cudd &mgr);

  virtual void asStraightVector(double *res) {assertinternal(false && res);}

  virtual void integrateOut(const set<Unreduced> &bits);

  virtual double dotProduct(BFunction &x);
  virtual double dotProductRec(BFunction &x, const Unreduced &bit);

  virtual void print(int print_level) {
    getADD().print(m_manager->ReadSize(), print_level);
  }

};

class VectorFunction : public BFunction {
private:
  Float *m_vector;
  int *m_invperm;
  int *m_perm;

  Uint m_num_bits;
  Uint m_num_informative_bits;

  IV expandMask(Uint begin, Uint end);
  void buildXNodesUtil(vector<IV> &ivs, IV v, IV mi, IV uninformative_mask);
  void buildXNodes(map<DdNode *, vector<IV> > &x_nodes, DdNode *x, IV v,
                   int target_lvl,
 IV uninformative_mask);

  bool orderMatches(int *invperm) const;
  bool orderMatchesManager(Cudd &mgr) const {
    return orderMatches(mgr.getManager()->invperm);
  }
  void fixManagerOrder();
  void shuffle(IV v, char *tb);

  void expand(const vector<int> &expand_bits);

  void resetInvperm();

  double multiply(ADD &x, bool dp);

public:
  virtual Type type() const {return VECTOR_FUN;}

  VectorFunction(VectorFunction &f, const string &f_swap_file = "");
  VectorFunction(const string &file_name, Cudd &mgr);
  VectorFunction(ADD &add);
  virtual ~VectorFunction() {
    delete [] m_vector;
    delete [] m_invperm;
    delete [] m_perm;
  }

  virtual Uint memoryInUse() {
    return inMemory() ? (IV(1) << m_num_bits)*sizeof(double)/(IV(1) << 20) : 0;
  }

  virtual void transfer(Cudd &mgr);

  virtual void writeToFile(const string &fn, bool swap);

  virtual bool isConstant() {
    if (!inMemory()) getVector();
    const IV numiv = IV(1) << m_num_informative_bits;
    for (IV v = 1; v < numiv; v++)
      if (m_vector[v] != m_vector[0])
        return false;
    return true;
  }
  virtual bool isZero() {
    if (!inMemory()) getVector();
    const IV numiv = IV(1) << m_num_informative_bits;
    for (IV v = 0; v < numiv; v++)
      if (m_vector[v] != .0)
        return false;
    return true;
  }
  virtual bool isPositive() {
    if (!inMemory()) getVector();
    const IV numiv = IV(1) << m_num_informative_bits;
    for (IV v = 0; v < numiv; v++)
      if (m_vector[v] < .0)
        return false;
    return true;
  }

  virtual void inplaceMult(ADD &x) {multiply(x, false);}
  virtual void inplaceMultBF(BFunction &x);

  virtual int *getInvperm() const {return m_invperm;}
  virtual int *getPerm() const {return m_perm;}
  virtual void shuffle(int *invperm);

  virtual int *support();

  virtual ADD asADD(ADD &zo);
  virtual double *getVector();

  virtual void asStraightVector(double *res);

  virtual void integrateOut(const set<Unreduced> &bits);

  virtual void expand();

  virtual double dotProduct(BFunction &x);
  virtual double dotProductRec(BFunction &x, const Unreduced &bit);

  virtual void print(int /*print_level*/) {
    if (!inMemory()) getVector();
    const IV numiv(IV(1) << m_num_informative_bits);
    for (IV v = 0; v < numiv; v++)
      cout << v << "\t" << m_vector[v] << endl;
  }

};

#endif // _BFUNCTION
