#ifndef _CACHEMANAGER
#define _CACHEMANAGER

#include "cuddInt.h"

#include "basic.h"

#include <map>

extern "C" {
  extern int cleanCache(DdManager *man, const char *, void *);
}

typedef map<DdNode *, double> CuddCacheN_D;
typedef map<pair<DdNode * ,DdNode *>, DdNode *> CuddCacheNN_N;
typedef map<pair<DdNode * ,DdNode *>, double> CuddCacheNN_D;

class CuddCacheManager {
private:
  static map<pair<string, DdManager *>, CuddCacheN_D> m_cachesN_D;
  static map<pair<string, DdManager *>, CuddCacheNN_N> m_cachesNN_N;
  static map<pair<string, DdManager *>, CuddCacheNN_D> m_cachesNN_D;
public:
  static CuddCacheN_D &getCacheN_D(const string &desc, DdManager *man) {
    if (!Cudd_IsInHook(man, cleanCache, CUDD_PRE_GC_HOOK))
      Cudd_AddHook(man, cleanCache, CUDD_PRE_GC_HOOK);

    CuddCacheN_D &cache = m_cachesN_D[make_pair(desc, man)];
    return cache;
  }
  static CuddCacheNN_N &getCacheNN_N(const string &desc, DdManager *man) {
    if (!Cudd_IsInHook(man, cleanCache, CUDD_PRE_GC_HOOK))
      Cudd_AddHook(man, cleanCache, CUDD_PRE_GC_HOOK);

    CuddCacheNN_N &cache = m_cachesNN_N[make_pair(desc, man)];
    return cache;
  }
  static CuddCacheNN_D &getCacheNN_D(const string &desc, DdManager *man) {
    if (!Cudd_IsInHook(man, cleanCache, CUDD_PRE_GC_HOOK))
      Cudd_AddHook(man, cleanCache, CUDD_PRE_GC_HOOK);

    CuddCacheNN_D &cache = m_cachesNN_D[make_pair(desc, man)];
    return cache;
  }

  static void removeCache(const string &desc, DdManager *man) {
    m_cachesN_D.erase(make_pair(desc, man));
    m_cachesNN_N.erase(make_pair(desc, man));
    m_cachesNN_D.erase(make_pair(desc, man));
  }

  static void flush() {
    m_cachesN_D.clear();
    m_cachesNN_N.clear();
    m_cachesNN_D.clear();
  }

};

#endif // _CACHEMANAGER
