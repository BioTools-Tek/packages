#include "files.h"
#include "linkagedist.h"
#include "paramdist.h"
#include "family.h"

///////////////////////////////////////////////////////////////////////
// Paramdist

Paramdist *Paramdist::getparamdist(const string &pt, Trait *tr) {
  Calcparametric *calcparametric = Calcparametric::getcalcparametric(tr);
  Distribution *dist =
    Distribution::finddistribution(calcparametric->describe(), pt);
  if (dist != 0) return (Paramdist *)dist;
  else return new Paramdist(pt, calcparametric);
}
