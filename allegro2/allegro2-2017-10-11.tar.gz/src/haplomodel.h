#ifndef _HAPLOMODEL
#define _HAPLOMODEL
#include "basic.h"
#include "model.h"

class Haplomodel : public Model {
public:
  Haplomodel(const string &hapf, const string &inhf, const string &ihapf,
             const string &fndrf);
  
  virtual void output() {}
  // prints description
  virtual void print() const;
protected:
  virtual void totline(ostream &/*f*/, Uint /*pos*/) {}
  virtual void famline(ostream &/*f*/, Uint /*ifa*/, Uint /*pos*/) {}
  virtual void totheader(ostream &/*f*/) {}
  virtual void famheader(ostream &/*f*/) {}
};

#endif // _HAPLOMODEL
