#ifndef _KINSHIP
#define _KINSHIP
#include "basic.h"

class Family;

class Kinship {
protected:
  FloatMat kinship;
  Uint curdim;
public:
  Kinship(Family *fam);
  ~Kinship();
  Float getkinship(Uint i, Uint j);
  Float operator()(Uint i, Uint j) {return getkinship(i, j);}
};

#endif // _KINSHIP
