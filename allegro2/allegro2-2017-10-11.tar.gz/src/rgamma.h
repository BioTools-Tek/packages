#ifndef _RGAMMA
#define _RGAMMA
#include "basic.h"

Double rgamma(Double alpha, Double beta);
Double rgammamix(Double v);
Double rgammamix_end(Double v);

#endif // _RGAMMA
