#include "files.h"
#include "ibddist.h"
#include "Unreduced.hh"

//////////////////////////////////////////////////////////////////////
// IBDdist
IBDdist::IBDdist(const string &p, const string &type) :
    Distribution(p), pairtype(type), findIBD(FindIBD::getFindIBD(type)) {}

void IBDdist::nextfam(bool /*mtbdd*/, Uint /*pos*/, DoubleVec /*p0*/) {
  familydata.push_back(new Familydata());
  Familydata *famdat = familydata.back();
  // Set things up for calculations

  famdat->initialize(findIBD->countpairs(), npos);
  // Calculate prior
  findIBD->collectpairs(famdat->person1, famdat->person2);
  findIBD->findprior(famdat->prioribd1, famdat->prioribd2);
}

void IBDdist::set(FloatVec pv, Uint pos) {
  // Calculate posterior
  Familydata *famdat = familydata.back();
  if (famdat->npairs > 0)
    findIBD->findposterior(pv, famdat->posterioribd1[pos],
                           famdat->posterioribd2[pos]);
}

void IBDdist::set(ADD &pv, double sum_pv, Uint pos) {
  // Calculate posterior
  Familydata *famdat = familydata.back();
  if (famdat->npairs > 0)
    findIBD->findposterior(pv, sum_pv, famdat->posterioribd1[pos],
                           famdat->posterioribd2[pos]);
}

void IBDdist::skipfam() {
  if (!familydata.empty()) {
    delete familydata.back();
    familydata.pop_back();
  }
}

void IBDdist::reset(Uint np) {
  while (!familydata.empty()) {
    delete familydata.back();
    familydata.pop_back();
  }
  npos = np;
}

IBDdist *IBDdist::getibddist(const string &pt, const string &type) {
  Distribution *dist = Distribution::finddistribution("IBD" + type, pt);
  if (dist != 0) return (IBDdist *)dist;
  else return new IBDdist(pt, type);
}

IBDdist::Familydata::~Familydata() {
  delete [] person1;
  delete [] person2;
  delete [] prioribd1;
  delete [] prioribd2;
  deletematrix(posterioribd1);
  deletematrix(posterioribd2);
}

void IBDdist::getuninteresting(::set<Unreduced> &uninteresting) {
  findIBD->getuninteresting(uninteresting);
}
