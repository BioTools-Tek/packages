#ifndef _VARCOMPMODEL
#define _VARCOMPMODEL
#include "qtlmodel.h"

class Varcompmodel : public QTLmodel {
protected:
  bool pihat;

  virtual Double calculate(DoubleVec fl,
                           Double S, Double G, Double A, Double D, Uint gam);
public:
  Varcompmodel(const string &p, const string &tr, bool maxG, bool maxA,
               bool maxD, Double shr, bool pih, const string &of,
               const string &fof);

  virtual void print() const;
};

#endif // _VARCOMPMODEL
