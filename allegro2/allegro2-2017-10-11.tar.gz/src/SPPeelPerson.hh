#ifndef _SPPEELPERSON_HH
#define _SPPEELPERSON_HH

#include "basic.h"

#include "cuddObj.hh"

#include <map>
#include <set>

typedef pair<uint64_t, uint64_t> PhasedGT;
typedef pair<PhasedGT, PhasedGT> ParentalAssignment;

inline PhasedGT intersection(const PhasedGT &a, const PhasedGT &b) {
  return PhasedGT(a.first & b.first, a.second & b.second);
}

inline ParentalAssignment intersection(const ParentalAssignment &a,
                                       const ParentalAssignment &b) {
  return ParentalAssignment(intersection(a.first, b.first),
                            intersection(a.second, b.second));
}

inline PhasedGT subtract(const PhasedGT &a, const PhasedGT &b) {
  return PhasedGT(a.first & (~b.first), a.second & (~b.second));
}

inline ParentalAssignment subtract(const ParentalAssignment &a,
                                const ParentalAssignment &b) {
  return ParentalAssignment(subtract(a.first, b.first),
                            subtract(a.second, b.second));
}

inline bool overlap(const PhasedGT &a, const PhasedGT &b) {
  return (a.first & b.first) && (a.second & b.second);
}
inline bool overlap(const ParentalAssignment &a,
                    const ParentalAssignment &b) {
  return overlap(a.first, b.first) && overlap(a.second, b.second);
}

inline void insertExtra(set<PhasedGT> &assignments, const PhasedGT &a,
                        const PhasedGT &b, const PhasedGT &u) {
  PhasedGT x(u);
  if (b.first != 0) {
    x.first = b.first;
    assignments.insert(x);
  }
  x.first = a.first;

  if (b.second != 0) {
    x.second = b.second;
    assignments.insert(x);
  }
}

inline void insertExtra(set<ParentalAssignment> &assignments,
                        const ParentalAssignment &a,
                        const ParentalAssignment &b,
                        const ParentalAssignment &u) {
  ParentalAssignment x(u);
  if (b.first.first != 0) {
    x.first.first = b.first.first;
    assignments.insert(x);
  }
  x.first.first = a.first.first;

  if (b.first.second != 0) {
    x.first.second = b.first.second;
    assignments.insert(x);
  }
  x.first.second = a.first.second;

  if (b.second.first != 0) {
    x.second.first = b.second.first;
    assignments.insert(x);
  }
  x.second.second = a.second.second;

  if (b.second.second != 0) {
    x.second.second = b.second.second;
    assignments.insert(x);
  }
//    x.second.second = a.second.second;
}

static const uint64_t UNINFORMATIVE = ~uint64_t(0);

class SPPeelMarriage;

class SPPeelPerson {
  friend class SPPeelMarriage;
public:
  SPPeelPerson(const string &id, const string &father, const string &mother,
               unsigned int patbitlevel, unsigned int matbitlevel, bool founder,
               Cudd &mgr, Allele a1, Allele a2);
  SPPeelPerson(const string &id, const string &father, const string &mother,
               unsigned int patbitlevel, unsigned int matbitlevel,
               bool founder) :
      m_id(id), m_father(father), m_mother(mother), m_patbitlevel(patbitlevel),
      m_matbitlevel(matbitlevel), m_founder(founder) {}

  bool isLeaf(const vector<SPPeelMarriage> &fam) const;
  bool isFounder() const {return m_founder;}

  bool isFiner(const SPPeelPerson &p) const;
  void makeFinerThan(const SPPeelPerson &p);

  ADD sumProb(Cudd &mgr) const;

  void print();
  void printShort() const;

  unsigned int numPhasedGTs() const;

  void mergeIdentical();

  map<PhasedGT, ADD> m_phases;

  const string m_id;
  const string m_father;
  const string m_mother;

  unsigned int m_patbitlevel;
  unsigned int m_matbitlevel;

  void hideUninformativeBit();

protected:
  const bool m_founder;

  static bool finer(uint64_t a, uint64_t b) {
    return (a & b) == 0 || (a & (~b)) == 0;
  }
  void splitPhase(uint64_t h, uint64_t s, ADD x, bool pattrans, uint64_t o);

};

#endif // _SPPEELPERSON_HH
