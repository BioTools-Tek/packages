#ifndef _MTBDDPEEL
#define _MTBDDPEEL

#include "basic.h"
#include "cuddObj.hh"

#include <algorithm>
#include <set>

class Trait;

class ActiveFunction {
private:
  void findDropBits(vector<Uint> &drop_bits,
                    const ActiveFunction &smaller) const {
    Uint li = 0, si = 0;
    for (set<Person *>::const_iterator a = active.begin(); a != active.end();
         a++) {
      if (smaller.active.count(*a))
        si += 2;
      else {
        drop_bits.push_back(li);
        drop_bits.push_back(li + 1);
      }
      li += 2;
    }
    assertinternal(li == 2*active.size() && si == 2*smaller.active.size());
  }

  static Uint dropBits(const vector<Uint> &drop_bits, Uint i) {
    for (vector<Uint>::const_reverse_iterator di = drop_bits.rbegin();
         di != drop_bits.rend(); di++) {
      const Uint d = *di;
      const Uint bit = Uint(1) << d;

      i = (i % bit) + ((i >> (d + 1)) << d);
    }
    return i;
  }

public:
  set<Person *> active;
  ADDvector x;

  ActiveFunction(const set<Person *> &a = set<Person *>()) :
      active(a), x(IV(1) << 2*active.size()) {}

  ADD &sub(ActiveFunction &larger, Uint i);
  void reduceTo(ActiveFunction &smaller);

};

class PStep {
public:
  set<Person *> active_after;
  set<Person *> remaining_after;
  set<Person *> peeled;

  PStep() {}

  Uint numBitsPeeled(const set<Person *> &remaining) const;
  void getPeeledBits(vector<IV> &peeled_bits, const set<Person *> &remaining);

  double cost(IV prob_size, Uint num_bits_remaining,
              const set<Person *> &active_before,
              const set<Person *> &remaining_before) const;

  void insertToPeel(Person *p);
  void insertToPeelRecursive(Person *p, const set<Person *> &active);

  void setAfter(const set<Person *> &active, const set<Person *> &remaining);

  void print() const;

  ActiveFunction L;

  void calcPeelProb(const set<Person *> &active_before,
                    const set<Person *> &remaining_before, Cudd &mgr,
                    Trait *trait, const set<Person *> &non_founders);

};

class PPeeler {
private:
  static PStep peelUp(Person *p, const set<Person *> &active,
                      const set<Person *> &remaining);
  static PStep peelDown(Person *p, const set<Person *> &active,
                        const set<Person *> &remaining, bool inclusive = false);
  static PStep peelChildren(Person *p, Person *spouse,
                            const set<Person *> &active,
                            const set<Person *> &remaining);
  static PStep peelSingle(Person *p, const set<Person *> &active,
                          const set<Person *> &remaining);

  static void tryStep(PStep &best_step, double &lowest_cost, const PStep &step,
                      IV prob_size, Uint num_bits_remaining,
                      const set<Person *> &active,
                      const set<Person *> &remaining);
  static ADD sumProd(ADD &p, ADD &L, const vector<IV> &peeled_bits);


  set<Person *> initial_remaining;
  vector<PStep> peel_order;

public:
  PPeeler() {}

  void setup(Family *fam, Cudd &mgr, Trait *trait);

  Double peel(ADD &p);

};

#endif // _MTBDDPEEL
