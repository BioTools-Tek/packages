#include "files.h"
#include "forcedmodel.h"
#include "forceddist.h"

Forcedmodel::Forcedmodel(const string &forced, const string &famforced) :
    Model("fpt") {
  distribution = Forceddist::getforceddist(forced, famforced);
}

void Forcedmodel::print() const {
  ((Forceddist *)distribution)->print();
}

void Forcedmodel::output() {
  ((Forceddist *)distribution)->overallforcedrecombout();
}
