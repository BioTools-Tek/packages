#ifndef _DISTRIBUTION
#define _DISTRIBUTION
#include <map>
#include <set>
#include "basic.h"

typedef vector<Family *> Familyvector;

class Infile;
class Outfile;
class Probability;
class ADD;
class ADDvector;
class Cudd;
class Graph;
class Unreduced;

class Distribution {
public:
  virtual ~Distribution();
  static void reset(const Map &mp);
  static void set(FloatVec pv, Uint pos, const string &p);
  static void set(ADD &prob, Uint pos, const string &p);
  static void setSPT(ADDvector &sp);
  static void setGraph(Graph *g) {graph = g;}
  static bool nextfam(Probability &prob, Family *fam, DoubleVec p0);
  static bool nextfam(Family *fam, Cudd &mgr);
  // Called if the family currently under investigation has no
  // informative markers
  static void curfamuninformative();
  const string &getpt();
  virtual string describe() const = 0;
  virtual const string &getfamid(Uint ifam) const;
  virtual Uint nfam() const {return families.size();}

  /// Returns true if the family will be used by the distribution.
  /// The default is to to return true if the family is more than 0 bits.
  virtual bool usefamily(Family *fam, bool mtbdd) const;
  /// Returns true if families that have no uninformative markers are to be
  /// used
  virtual bool useuninformative() const {return true;}
  Familyvector families;

  static bool isnullconstant() {return nullconstant;}
  static void setnullconstant(bool nc) {nullconstant = nc;}
  Uint nnulldist() {return isnullconstant() ? 1 : npos;}
  static void cleanup();

  static void getuninteresting(Family *fame, ::set<Unreduced> &uninteresting);

protected:
  static bool nullconstant;
  bool skipcurrentfamily;
  static Graph *graph;

  Distribution(const string &p);
  virtual void reset(Uint np) = 0;
  virtual void nextfam(bool mtbbd, Uint pos = 0, DoubleVec p0 = 0) = 0;
  virtual void set(FloatVec pv, Uint pos) = 0;
  virtual void set(ADD &pv, double sum_pv, Uint pos) = 0;
  virtual void SPT(ADDvector &/*sp*/) {}
  virtual void skipfam() = 0;
  virtual void getuninteresting(::set<Unreduced> &uninteresting) = 0;

  typedef vector<Distribution *> Distributionvector;
  static Distributionvector distributions;

  Uint npos;
  Family *curfamily() {return families.back();}
  static Distribution *finddistribution(const string &desc, const string &pt);

  static bool famuseful(Family *fam, bool mtbdd);

  string pt;

  static Map const *map;
};

#endif // _DISTRIBUTION
