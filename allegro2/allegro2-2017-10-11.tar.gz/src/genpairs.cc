#include "family.h"
#include "genpairs.h"
#include "files.h"
#include "options.h"
#include "vecutil.h"

Genpairsperson::Genpairsperson(Person *p, Genpairsperson *first,
                               String2Double &pair2weight1,
                               String2Double &pair2weight2, Uint &idx,
                               Uint maxnum, bool infm) :
    Pairwiseperson<Indexfounderallele>(p, first), w1(0), w2(0), index(idx),
    informative(infm) {
  if (per->founder()) {
    nod[0]->setmaxnum(maxnum);
    nod[1]->setmaxnum(maxnum);
  }
  if (informative) {
    idx++;
    for (Genpairsperson *q = first; q != 0 && q->per != p;
         q = (Genpairsperson *)q->next) {
      if (q->informative) {
        const Double weight1 = pair2weight1[q->per->id + " " + per->id];
        const Double weight2 = pair2weight2[q->per->id + " " + per->id];
        if ((weight1 != 0.0 || weight2 != 0.0) && index > 0) {
          if (w1 == 0) {
            assertinternal(w2 == 0);
            w1 = new Double[index];
            w2 = new Double[index];
            zero(w1, index);
            zero(w2, index);
          }
          assertinternal(index > q->index);
          w1[q->index] = weight1;
          w2[q->index] = weight2;
        }
      }
    }
  }
}

Double Genpairsperson::addgenpairs() {
  Uint i0 = 0, i1 = 0;
  Double sc = 0.0;
  if (!options->sexlinked || per->sex == FEMALE) {
    if (nod[0] != nod[1]) {
      while (i0 < nod[0]->numdescendants && i1 < nod[1]->numdescendants) {
        const Uint d0 = nod[0]->descendants[i0];
        const Uint d1 = nod[1]->descendants[i1];
        if (d0 < d1) {
          sc += w1[d0];
          i0++;
        }
        else if (d1 < d0) {
          sc += w1[d1];
          i1++;
        }
        else {
          sc += w2[d0];
          i0++;
          i1++;
        }
      }
      while (i0 < nod[0]->numdescendants) {
        const Uint d0 = nod[0]->descendants[i0];
        sc += w1[d0];
        i0++;
      }
    }
    else {
      while (i1 < nod[1]->numdescendants) {
        const Uint d1 = nod[1]->descendants[i1];
        if (nod[1]->descendanthomozygous[i1])
          sc += w2[d1];
        else
          sc += w1[d1];
        i1++;
      }
    }
  }
  while (i1 < nod[1]->numdescendants) {
    const Uint d1 = nod[1]->descendants[i1];
    sc += w1[d1];
    i1++;
  }
  return sc;
}

void Genpairsperson::calcgenspairs(IV v, Double B, DoubleVec S) {
  int Kf = per->patmask ? 1 : 0;
  int Km = per->matmask ? 1 : 0;

  for (int K1 = 0; K1 <= Km; K1++) {
    if (K1) v += per->matmask;
    if (per->mother != 0) nod[1] = mother->nod[K1];
    for (int K0 = 0; K0 <= Kf; K0++) {
      if (K0) v += per->patmask;
      if (per->father != 0) nod[0] = father->nod[K0];
      Double Bnew = B;
      if (informative) {
        if (next != 0) {
          const bool homozygote = nod[0] == nod[1];
          if (w1 != 0) Bnew += addgenpairs();
          nod[0]->pushdescendant(index, homozygote);
          if ((!options->sexlinked || per->sex == FEMALE) && !homozygote)
            nod[1]->pushdescendant(index, false);
          if (next != 0) ((Genpairsperson *)next)->calcgenspairs(v, Bnew, S);
          nod[0]->popdescendant();
          if ((!options->sexlinked || per->sex == FEMALE) && !homozygote)
            nod[1]->popdescendant();
        }
        else {
          if (w1 != 0) Bnew += addgenpairs();
          S[v] = Bnew;
        }
      }
      else {
        if (next != 0) ((Genpairsperson *)next)->calcgenspairs(v, Bnew, S);
        else S[v] += Bnew;
      }
    }
    v &= ~per->patmask;
  }
}

DdNode *Genpairsperson::calcgenspairs(double B, DdManager *mgr) {
  int Kf = per->patmask ? 1 : 0;
  int Km = per->matmask ? 1 : 0;

  DdNode *qdd_00 = 0, *qdd_01 = 0, *qdd_10 = 0, *qdd_11 = 0;

  for (int K1 = 0; K1 <= Km; K1++) {
    if (per->mother != 0) nod[1] = mother->nod[K1];
    for (int K0 = 0; K0 <= Kf; K0++) {
      if (per->father != 0) nod[0] = father->nod[K0];
      DdNode *&cur_qdd = (K0 == 0 ? (K1 == 0 ? qdd_00 : qdd_10) :
                          (K1 == 0 ? qdd_01 : qdd_11));
      double Bnew = B;
      if (informative) {
        if (next != 0) {
          bool homozygote = nod[0] == nod[1];
          if (w1 != 0) Bnew += addgenpairs();
          nod[0]->pushdescendant(index, homozygote);
          if ((!options->sexlinked || per->sex == FEMALE) && !homozygote)
            nod[1]->pushdescendant(index, false);
          if (next != 0)
            cur_qdd = ((Genpairsperson *)next)->calcgenspairs(Bnew, mgr);
          nod[0]->popdescendant();
          if ((!options->sexlinked || per->sex == FEMALE) && !homozygote)
            nod[1]->popdescendant();
        }
        else {
          if (w1 != 0) Bnew += addgenpairs();
          cur_qdd = cuddUniqueConst(mgr, Bnew);
        }
      }
      else {
        if (next != 0)
          cur_qdd = ((Genpairsperson *)next)->calcgenspairs(Bnew, mgr);
        else
          cur_qdd = cuddUniqueConst(mgr, Bnew);
      }
    }
  }

  return collectresults(mgr, qdd_00, qdd_01, qdd_10, qdd_11, Kf, Km);
}

Genpairsperson_ps::Genpairsperson_ps(Person *p, Genpairsperson_ps *first,
                                     String2Double &pair2wmm,
                                     String2Double &pair2wmf,
                                     String2Double &pair2wff, Uint &idx,
                                     Uint maxnum, bool infm) :
    Pairwiseperson<PSfounderallele>(p, first),
    wmm(0), wmf(0), wff(0), index(idx), informative(infm) {
  if (per->founder()) {
    nod[0]->setmaxnum(maxnum);
    nod[1]->setmaxnum(maxnum);
  }
  if (informative) {
    idx++;
    for (Genpairsperson_ps *q = first; q != 0 && q->per != p;
         q = (Genpairsperson_ps *)q->next) {
      if (q->informative) {
        const Double weight_mm = pair2wmm[q->per->id + " " + per->id];
        const Double weight_mf = pair2wmf[q->per->id + " " + per->id];
        const Double weight_ff = pair2wff[q->per->id + " " + per->id];
        if ((weight_mm != 0.0 || weight_mf != 0.0 || weight_ff != 0.0) &&
            index > 0) {
          if (wmm == 0) {
            assertinternal(wmf == 0 && wff == 0);
            wmm = new Double[index];
            wmf = new Double[index];
            wff = new Double[index];
            zero(wmm, index);
            zero(wmf, index);
            zero(wff, index);
          }
          assertinternal(index > q->index);
          wmm[q->index] = weight_mm;
          wmf[q->index] = weight_mf;
          wff[q->index] = weight_ff;
        }
      }
    }
  }
}

Double Genpairsperson_ps::addgenpairs_ps() {
  return addgenpairs_ps(nod[0], true) + addgenpairs_ps(nod[1], false);
}

Double Genpairsperson_ps::addgenpairs_ps(PSfounderallele *n, bool pattrans) {
  return (addgenpairs_ps(n->pat_descendants, n->num_pat_descendants,
                         pattrans ? wff : wmf) +
          addgenpairs_ps(n->mat_descendants, n->num_mat_descendants,
                         pattrans ? wmf : wmm));
}

Double Genpairsperson_ps::addgenpairs_ps(UintVec desc, Uint num, DoubleVec w) {
  Double sc = .0;
  for (Uint i = 0; i < num; i++)
    sc += w[desc[i]];
  return sc;
}

void Genpairsperson_ps::calcgenspairs_ps(IV v, Double B, DoubleVec S) {
  int Kf = per->patmask ? 1 : 0;
  int Km = per->matmask ? 1 : 0;

  for (int K1 = 0; K1 <= Km; K1++) {
    if (K1) v += per->matmask;
    if (per->mother != 0) nod[1] = mother->nod[K1];
    for (int K0 = 0; K0 <= Kf; K0++) {
      if (K0) v += per->patmask;
      if (per->father != 0) nod[0] = father->nod[K0];
      Double Bnew = B;
      if (informative) {
        if (next != 0) {
          if (wff != 0) Bnew += addgenpairs_ps();
          nod[1]->pushmatdescendant(index);
          if (!options->sexlinked || per->sex == FEMALE)
            nod[0]->pushpatdescendant(index);
          if (next != 0)
            ((Genpairsperson_ps *)next)->calcgenspairs_ps(v, Bnew, S);
          nod[1]->popmatdescendant();
          if (!options->sexlinked || per->sex == FEMALE)
            nod[0]->poppatdescendant();
        }
        else {
          if (wff != 0) Bnew += addgenpairs_ps();
          S[v] = Bnew;
        }
      }
      else {
        if (next != 0)
          ((Genpairsperson_ps *)next)->calcgenspairs_ps(v, Bnew, S);
        else S[v] += Bnew;
      }
    }
    v &= ~per->patmask;
  }
}

DdNode *Genpairsperson_ps::calcgenspairs_ps(Double B, DdManager *mgr) {
  int Kf = per->patmask ? 1 : 0;
  int Km = per->matmask ? 1 : 0;

  DdNode *qdd_00 = 0, *qdd_01 = 0, *qdd_10 = 0, *qdd_11 = 0;

  for (int K1 = 0; K1 <= Km; K1++) {
    if (per->mother != 0) nod[1] = mother->nod[K1];
    for (int K0 = 0; K0 <= Kf; K0++) {
      if (per->father != 0) nod[0] = father->nod[K0];
      DdNode *&cur_qdd = (K0 == 0 ? (K1 == 0 ? qdd_00 : qdd_10) :
                          (K1 == 0 ? qdd_01 : qdd_11));
      Double Bnew = B;
      if (informative) {
        if (next != 0) {
          if (wff != 0) Bnew += addgenpairs_ps();
          nod[1]->pushmatdescendant(index);
          if (!options->sexlinked || per->sex == FEMALE)
            nod[0]->pushpatdescendant(index);
          if (next != 0)
            ((Genpairsperson_ps *)next)->calcgenspairs_ps(Bnew, mgr);
          nod[1]->popmatdescendant();
          if (!options->sexlinked || per->sex == FEMALE)
            nod[0]->poppatdescendant();
        }
        else {
          if (wff != 0) Bnew += addgenpairs_ps();
          cur_qdd = cuddUniqueConst(mgr, Bnew);
        }
      }
      else {
        if (next != 0)
          ((Genpairsperson_ps *)next)->calcgenspairs_ps(Bnew, mgr);
        else
           cur_qdd = cuddUniqueConst(mgr, Bnew);
     }
    }
  }

  return collectresults(mgr, qdd_00, qdd_01, qdd_10, qdd_11, Kf, Km);
}
