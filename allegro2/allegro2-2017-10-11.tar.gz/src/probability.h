#ifndef _PROBABILITY
#define _PROBABILITY
#include "basic.h"
#include "matrix.h"

class Graph;
class Foundercouple;
class Plist;
class FamilyMap;

class Probability {
public:
  Probability(Floatmatrix *qp, Floatmatrix *lqp, Floatmatrix *lqhatp,
              FloatVec rqhatp, Family *f, Map *mp);
  ~Probability();
  Floatmatrix *q;
  Floatmatrix *lq;
  Floatmatrix *lqhat;   // hat(l . q), previously hat(M_{gamma,L}^+)
  FloatVec rqhat;
  FloatVec l_nc; // Normalizing constant for l at each marker
  IV numiv;         // number of inheritance vectors, N (N = 2^n)

  void findp(const FamilyMap &fm, Uint pos, FloatVec p);
  Float fromhere(FamilyMap *fm, Uint gam, FloatVec q);
  // calculate q
  static Float fromhere(Uint gam, FloatVec q, FloatVec freq, Family *fam);
  void createfoundergraph();
  void deletefoundergraph();
  void check(const string &s, int gam, FloatVec d, Float *L = 0);
  void lqfromlqhat(int gam, FloatVec lq);
  void findlq(FloatVec lqhatlast, FloatVec lqhat, FloatVec lq, FloatVec q,
              Float &L, Float theta, Float theta_female, Uint gam);
//  void finddpt(Uint pos, FloatVec r);
  Uint numbits;       // length of inheritance vector, n (n = 2*m-f)
  static Graph *graph; // graph used for M_gamma calculation
  // Fouriertransform of T
  void Ttrans(FloatVec D, FloatVec S, Float tht_male, Float tht_female);
private:
  static void outputvec(ostream& str, int gam, FloatVec x, IV N);
  void createweight();   // also used by Fouriert. of T
  void startright(int gam);
  void calculatefctrans(FloatVec D, FloatVec S, Float tht);
  void fcinnerprod(FloatVec D, FloatVec S, Float tht, IV a, IV b,
                   Foundercouple* fc);
  bool checkq(Uint gam); // Checks if marker is all 0 or
                         // noninformative
  void flattenq(int gam, Float r);
  void mrktopos(FloatVec posdist, FloatVec mrkhat, Uint gam, Uint pos);
  static void findq(Plist* p, FloatVec M, int gam, IV v, Graph *graph);

  IV mask;    // mask for nonfounder meioses
  Float factors[2*MAXBITS];
  Float factors_female[2*MAXBITS];
  // weights for Fourier transform of T
  unsigned char *wtstar; // weights for male meioses in sex-specific case
  unsigned char *wtstar_female; // weights for female meioses in sex-spec case
  Family *fam;          // associated family
  Map *map;             // family map
};

#endif // _PROBABILITY
