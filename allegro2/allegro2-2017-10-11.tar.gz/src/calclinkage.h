#ifndef _CALCLINKAGE
#define _CALCLINKAGE
#include "calc.h"
#include "cuddInt.h"
#include "family.h"

class Calclinkage : public Calc {
public:
  Calclinkage(const string &cid) : Calc(cid) {}

  virtual bool getsexlinked() const = 0;
  virtual Double sumLp(ADD &pv, Double sum_pv) = 0;

  virtual bool use(Family *fam, bool mtbdd) const {
    if (mtbdd)
      return !cuddIsConstant(S[0].getNode());
    else {
      const IV numiv = fam->numiv();
      double last_val = vec[0];
      bool useful = false;
      for (IV v = 0; v < numiv; v++)
        if (last_val != vec[v]) {
          useful = true;
          break;
        }
      return useful;
    }
  }
};

#endif // _CALCLINKAGE
