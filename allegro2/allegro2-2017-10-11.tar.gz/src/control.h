#ifndef _CONTROL
#define _CONTROL
#include "basic.h"
#include "matrix.h"
#include "map.h"
#include "genotypes.h"

#include "cuddObj.hh"

class Probability;

typedef hash_map<string, Marker, stringhash> String2Marker;
typedef hash_map<string, Chromosome, stringhash> String2Chromosome;
typedef hash_map<string, PN, stringhash> String2PN;

class FamilyMap {
public:
  static const int NOLEFTMARKER = -1;
  static const int NORIGHTMARKER = -1;

  const string famid;
  vector<string> markernames;

  vector<bool> informative;  // true if marker is informative

  vector<int> leftmarker; // The next informative marker to the left of pos
  vector<int> rightmarker; // The next informative marker to the right of pos
  vector<bool> shouldfindp; // Should things be calculated for this position

  vector<Float> theta; // The recomb fraction between each informative marker
                       // and the next one
  vector<Float> theta_female; // same for females in sex-specific case

  FamilyMap(const string &id, Map *map) :
      famid(id), informative(map->loci.size()),
      leftmarker(map->positions.size()), rightmarker(map->positions.size()),
      shouldfindp(map->positions.size()),
      markernames(map->loci.size()), theta(map->loci.size() - 1, .0),
      theta_female(map->loci.size() - 1, .0) {
    for (unsigned int g = 0; g < map->loci.size(); g++) {
      markernames[g] = map->loci[g].name;
      if (g + 1 < map->loci.size()) {
        if (options->sexspecific) {
          theta[g] = map->loci[g].thetaMale();
          theta_female[g] = map->loci[g].thetaFemale();
        } else
          theta[g] = theta_female[g] = map->loci[g].thetaMale();
      }
    }
  }

  void setinformative(Uint gam, bool informat);

  // setup assumes informative has been filled in appropriately
  void setup(Map *map);

};

class Control {
public:
  Control();
  ~Control();
  void probs();
  void initscore();

  Map map;
protected:
  Family *first;
  Family *firstorig;
  Uint numfam;
  int maxbits;
  IV maxnumiv;
  IV vector_maxnumiv;
  bool swapdircreated;
  void initializechromosome(const string &id,
                            String2Chromosome &string2chromosome,
                            String2Marker &string2marker, String2PN &string2pn);
  void analyzechromosome();
  void mtbddpass();
  void vectorpass(bool lowmem);
  void initdist();
  void findnums();
  void inputld();
  void inputdecode();
  void getdat(Infile& dat, UintVec &usemarkers, Uint &totuse, Uint &totnum,
              Uint popidx = 0);
  void getpre(Infile& pre, const UintVec usemarkers, const Uint totuse,
              const Uint totnum, Uint popidx = 0,
              String2Marker *string2marker = 0, String2PN *string2pn = 0,
              Chromosome *ch = 0);
  int markerused(Uint i, const UintVec usemarkers, Uint totuse);
  Float countvecsneeded();

  bool fromleft(Family *f, Probability &prob, FamilyMap &fm, Floatmatrix *q,
                Floatmatrix *lq, Floatmatrix *lqhat, FloatVec tmpq);
  void fromright(Probability &prob, const FamilyMap &fm, Floatmatrix *lq,
                 Floatmatrix *q, Family *fam);
  void setupfamilies();

  void createswapdir();
  void cleanupswapdir();

  // MTBDD specific functions
  bool dospt(FamilyMap &fm, ADDvector &sp, Cudd &mgr, Family *fam) const;
  void dompt(FamilyMap &fm, ADDvector &sp, Cudd &mgr, Family *fam);

};

extern Control *control;

#endif // _CONTROL
