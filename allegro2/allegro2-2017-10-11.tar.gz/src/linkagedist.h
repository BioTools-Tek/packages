#ifndef _LINKAGEDIST
#define _LINKAGEDIST
#include "distribution.h"
#include "calclinkage.h"

class Linkagedist : public Distribution {
public:
  virtual ~Linkagedist();

  // Function for extracting result
  void getresult(DoubleMat LR)
    {for (Uint i = 0; i < familydata.size(); i++) LR[i] = familydata[i]->LR;}
  bool getsexlinked() const {return calclinkage->getsexlinked();}

  virtual string describe() const {return calclinkage->describe();}

  /// Returns true if families that have no uninformative markers are to be
  /// used
  virtual bool useuninformative() const {return false;}

  // Family if used if it is more than 0 bits and has more than two or more
  // people that are affected or unaffected
  virtual bool usefamily(Family *fam, bool mtbdd) const;
protected:
  Calclinkage *calclinkage;
  DoubleVec Lnull;

  Linkagedist(const string &p, Calclinkage *clc) :
      Distribution(p), calclinkage(clc), Lnull(0) {}
  class Familydata {
  protected:
    Linkagedist *owner;
  public:
    Familydata(Linkagedist *own) : owner(own) {
      LR = new Double[owner->npos];
    }
    Familydata(const Familydata &fd) : owner(fd.owner) {
      LR = new Double[owner->npos];
    }

    ~Familydata() {delete [] LR;}
    DoubleVec LR;
  };
  friend class Linkagedist::Familydata;
  typedef vector<Familydata *> Familydatavector;
  Familydatavector familydata;

  virtual void reset(Uint np);
  virtual void nextfam(bool mtbdd, Uint pos = 0, DoubleVec p0 = 0);
  virtual void set(FloatVec pv, Uint pos);
  virtual void set(ADD &pv, double sum_pv, Uint pos);

  virtual void skipfam();

  virtual void getuninteresting(::set<Unreduced> &uninteresting);

};

#endif // _LINKAGEDIST
